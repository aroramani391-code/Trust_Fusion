"""The prepare scripts on tiny SYNTHETIC stand-ins for the raw dataset files (layout only; no real data)."""
import json
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from PIL import Image

from trustfusion.data.datasets import load_corpus, synthetic_pe_bytes

ROOT = Path(__file__).resolve().parents[1]


def run(script: str, *args: str) -> None:
    subprocess.run([sys.executable, str(ROOT / "scripts" / script), *args], check=True, cwd=ROOT, capture_output=True)


def test_prepare_bodmas(tmp_path):
    rng = np.random.default_rng(0)
    n = 12
    y = np.array([1] * 8 + [0] * 4)
    shas = [f"{i:064x}" for i in range(n)]
    np.savez(tmp_path / "bodmas.npz", X=rng.random((n, 2381)).astype(np.float32), y=y)
    pd.DataFrame({"sha": shas, "timestamp": ["2019-09-01 10:00:00 UTC"] * n,
                  "family": ["fa"] * 4 + ["fb"] * 4 + [None] * 4}).to_csv(tmp_path / "meta.csv", index=False)
    (tmp_path / "bin").mkdir()
    (tmp_path / "bin" / shas[0]).write_bytes(synthetic_pe_bytes(rng, 4000, 0, 2))
    ben = pd.DataFrame({"sha256": [f"b{i:063x}" for i in range(3)], "source": ["win10", "win11", "repo"],
                        "path": [str(tmp_path / f"nope{i}.exe") for i in range(3)]})
    ben.to_csv(tmp_path / "manifest.csv", index=False)
    np.save(tmp_path / "benign.npy", rng.random((3, 2381)).astype(np.float32))
    out = tmp_path / "processed"
    run("prepare_bodmas.py", "--bodmas-npz", str(tmp_path / "bodmas.npz"), "--bodmas-metadata", str(tmp_path / "meta.csv"),
        "--binaries-dir", str(tmp_path / "bin"), "--benign-manifest", str(tmp_path / "manifest.csv"),
        "--benign-features", str(tmp_path / "benign.npy"), "--out", str(out))
    c = load_corpus(out)
    assert len(c.meta) == 11 and c.static.shape == (11, 2381)
    assert (c.meta["is_malicious"] == 1).sum() == 8 and (c.meta["image_kind"] == "bytes").sum() == 1
    assert c.info["counts"]["benign_sources"] == {"win10": 1, "win11": 1, "repo": 1}


def test_prepare_ember2024_vectorized_alignment(tmp_path):
    recs = {"2024-01-01_Win32_train.jsonl": 3, "2024-02-01_APK_train.jsonl": 2, "2024-10-01_Win64_test.jsonl": 2}
    X = {"train": [], "test": []}
    i = 0
    for name in sorted(recs):
        subset = "train" if "train" in name else "test"
        with open(tmp_path / name, "w") as f:
            for _ in range(recs[name]):
                f.write(json.dumps({"sha256": f"{i:064x}", "first_submission_date": 1700000000 + i, "label": i % 2,
                                    "file_type": name.split("_")[1], "family": "fam" if i % 2 else None}) + "\n")
                X[subset].append(np.full(2568, i, np.float32))
                i += 1
    for subset in ("train", "test"):
        np.asarray(X[subset], np.float32).tofile(tmp_path / f"X_{subset}.dat")
    out = tmp_path / "processed"
    run("prepare_ember2024.py", "--data-dir", str(tmp_path), "--vectorized-dir", str(tmp_path), "--out", str(out))
    c = load_corpus(out)
    assert c.static.shape == (7, 2568)
    # rows of static.npy follow the metadata order: the i-th record carries the constant vector i
    ids = c.meta["sample_id"].map(lambda s: int(s, 16)).to_numpy()
    np.testing.assert_array_equal(c.static[:, 0], ids)
    assert c.info["counts"]["train"] == 5 and c.info["counts"]["test"] == 2


def test_prepare_malnet(tmp_path):
    rng = np.random.default_rng(0)
    img_root, graph_root = tmp_path / "images", tmp_path / "graphs"
    k = 0
    for split, n in (("train", 3), ("val", 2), ("test", 2)):
        for _ in range(n):
            t = f"type{k % 2}"
            d = img_root / split / t / "famx"
            d.mkdir(parents=True, exist_ok=True)
            Image.fromarray(rng.integers(0, 256, (16, 16, 3), dtype=np.uint8)).save(d / f"sha{k}.png")
            if k != 4:
                g = graph_root / t / "famx"
                g.mkdir(parents=True, exist_ok=True)
                (g / f"sha{k}.edgelist").write_text("# graph\n0 1\n1 2\n2 0\n")
            k += 1
    out = tmp_path / "processed"
    run("prepare_malnet.py", "--images-dir", str(img_root), "--graphs-dir", str(graph_root), "--out", str(out))
    c = load_corpus(out)
    assert len(c.meta) == 7 and c.static.shape == (7, 48)
    assert c.info["counts"]["graph_unmatched"] == 1 and c.info["counts"]["released"] == {"train": 3, "val": 2, "test": 2}
    assert np.all(c.static[c.meta["has_static"].to_numpy() == 0] == 0)
    assert len(pd.read_csv(out / "sha256_index.csv")) == 7
