#!/usr/bin/env python
"""Build ``results/tables/table{4..9}.csv`` and rewrite ``paper_figures/data/*.csv`` from per-sample predictions.

Every value is recomputed from ``runs/`` (prediction files) and ``results/`` (faithfulness, ablation, provenance
outputs). A table or figure file is written only when all of its inputs exist; otherwise it is skipped with a
warning, so a partial re-run never overwrites the manuscript's figure data with incomplete values.

Example::

    python scripts/aggregate_results.py --runs runs --results results --figures-out paper_figures/data
"""
from __future__ import annotations

import argparse
import sys
import warnings
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from trustfusion.aggregate import (paired_comparisons, per_seed_table, reliability_figure, risk_coverage_figure,  # noqa: E402
                                   roc_figure, summarize, temporal_figure)
from trustfusion.data.byte_image import REGION_CATEGORIES  # noqa: E402
from trustfusion.models import ALL_METHODS  # noqa: E402
from trustfusion.stats import mean_sd  # noqa: E402
from trustfusion.utils import CONFIG_ROOT, get_logger, load_config  # noqa: E402

log = get_logger("aggregate_results")
FAMILY = {"bodmas": "pr_family", "ember2024": "family_subset", "malnet_tiny": "tiny_type"}
DETECTION = {"bodmas": "pr_detection", "ember2024": "detection_subset", "malnet_tiny": "tiny_detection"}


def wide(summary: pd.DataFrame, index: list[str]) -> pd.DataFrame:
    if summary.empty:
        return summary
    return summary.pivot_table(index=index, columns="metric", values="formatted", aggfunc="first", sort=False).reset_index()


def write(df: pd.DataFrame | None, path: Path, what: str) -> None:
    if df is None or df.empty:
        warnings.warn(f"{what}: no inputs found, {path} not written")
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(path, index=False)
    log.info("wrote %s (%d rows)", path, len(df))


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--results", default="results")
    ap.add_argument("--figures-out", default="paper_figures/data")
    ap.add_argument("--seeds", type=int, nargs="+", default=None)
    ap.add_argument("--n-boot", type=int, default=None)
    ap.add_argument("--skip-table5", action="store_true")
    args = ap.parse_args()
    base = load_config(CONFIG_ROOT / "base.yaml")
    figs, mcfg = base["figures"], base["metrics"]
    runs, results, fig_out = Path(args.runs), Path(args.results), Path(args.figures_out)
    tables = results / "tables"
    methods = list(ALL_METHODS)

    # ---- Table 4: accuracy / macro-F1 (family) and detection AUC, TPR@FPR --------------------------------------------
    fam = pd.concat([per_seed_table(runs, c, p, methods, ["accuracy", "macro_f1"], args.seeds) for c, p in FAMILY.items()])
    det = pd.concat([per_seed_table(runs, c, p, methods, ["roc_auc", "tpr@fpr=0.001", "tpr@fpr=0.01"], args.seeds)
                     for c, p in DETECTION.items()])
    t4 = summarize(pd.concat([fam, det]))
    if not t4.empty:
        write(t4, tables / "table4_long.csv", "Table 4")
        write(wide(t4.drop(columns="protocol"), ["corpus", "method"]), tables / "table4.csv", "Table 4")

    # ---- Table 5: paired comparisons -----------------------------------------------------------------------------------
    if not args.skip_table5:
        t5 = paired_comparisons(runs, base["stats"]["table5_comparisons"], args.seeds,
                                int(args.n_boot or base["stats"]["bootstrap_resamples"]), float(base["stats"]["confidence"]))
        write(t5 if "mean_diff" in t5 else None, tables / "table5.csv", "Table 5")

    # ---- Table 6: calibration --------------------------------------------------------------------------------------------
    cal_methods = methods + ["cross_attention__ts"]
    t6 = summarize(pd.concat([per_seed_table(runs, c, p, cal_methods, ["ece", "coverage", "mean_set_size", "acceptance"], args.seeds)
                              for c, p in FAMILY.items()]))
    if not t6.empty:
        write(wide(t6.drop(columns="protocol"), ["corpus", "method"]), tables / "table6.csv", "Table 6")

    # ---- Table 7: component ablation --------------------------------------------------------------------------------------
    comp = load_config(CONFIG_ROOT / "ablation" / "component.yaml")
    names = [v["name"] for v in comp["variants"]]
    t7_seed = per_seed_table(runs, comp["corpus"], comp["protocol"], names, comp["metrics"], args.seeds)
    t7 = summarize(t7_seed)
    if not t7.empty:
        label = {v["name"]: v["label"] for v in comp["variants"]}
        t7 = t7.assign(variant=t7["method"].map(label))
        write(wide(t7.drop(columns=["protocol", "corpus"]), ["method", "variant"]), tables / "table7.csv", "Table 7")
        if set(t7["method"]) >= set(names):
            abl = t7[t7["metric"] == "macro_f1"].set_index("method").loc[names]
            write(pd.DataFrame({"variant": abl["variant"].to_numpy(), "macro_f1": np.round(abl["mean"].to_numpy(), 2)}),
                  fig_out / "fig_ablation_bodmas.csv", "Fig. ablation")
        else:
            warnings.warn("component ablation incomplete: fig_ablation_bodmas.csv not rewritten")

    # ---- Table 8: reliability factorial ------------------------------------------------------------------------------------
    fpath = results / "ablation" / "factorial_per_seed.csv"
    if fpath.exists():
        f = pd.read_csv(fpath)
        rows = []
        for cell, g in f.groupby("cell", sort=False):
            row = {"cell": cell, "lcal": g["lcal"].iloc[0], "head": g["head"].iloc[0], "n_seeds": len(g)}
            for col in [c for c in f.columns if c not in ("cell", "lcal", "head", "seed")]:
                scale = 1.0 if col == "mean_set_size" else 100.0
                m, s = mean_sd(scale * g[col].to_numpy())
                row[col] = f"{m:.2f} ± {s:.2f}"
            rows.append(row)
        write(pd.DataFrame(rows), tables / "table8.csv", "Table 8")
    else:
        warnings.warn(f"{fpath} missing: Table 8 not written")

    # ---- Table 9: faithfulness -------------------------------------------------------------------------------------------
    rows = []
    for corpus_dir in sorted((results / "faithfulness").glob("*")) if (results / "faithfulness").exists() else []:
        per_seed = [pd.read_csv(p).groupby(["variant", "protocol"])[["deletion_auc", "insertion_auc"]].mean().reset_index().assign(seed=p.parent.name)
                    for p in sorted(corpus_dir.glob("seed*/per_sample.csv"))]
        if not per_seed:
            continue
        df = pd.concat(per_seed)
        for (variant, protocol), g in df.groupby(["variant", "protocol"], sort=False):
            dm, ds = mean_sd(g["deletion_auc"].to_numpy())
            im, is_ = mean_sd(g["insertion_auc"].to_numpy())
            rows.append({"corpus": corpus_dir.name, "variant": variant, "protocol": protocol, "n_seeds": len(g),
                         "deletion_auc": f"{dm:.3f} ± {ds:.3f}", "insertion_auc": f"{im:.3f} ± {is_:.3f}"})
    write(pd.DataFrame(rows) if rows else None, tables / "table9.csv", "Table 9")

    # ---- figures ---------------------------------------------------------------------------------------------------------
    g = mcfg["roc_grid"]
    grid = np.logspace(g["log10_min"], g["log10_max"], int(g["points"]))
    write(roc_figure(runs, figs["roc"], figs["labels"], figs["corpus_labels"], grid), fig_out / "fig_roc_curves.csv", "Fig. 3")
    write(reliability_figure(runs, "bodmas", figs["reliability"], int(mcfg["ece_bins"])), fig_out / "fig_reliability_bodmas.csv", "Fig. 4")
    write(risk_coverage_figure(runs, figs["risk_coverage"], figs["corpus_labels"], mcfg["selective_coverages"]),
          fig_out / "fig_risk_coverage.csv", "Fig. 5")
    write(temporal_figure(runs, "bodmas", figs["temporal"], figs["labels"]), fig_out / "fig_temporal_drift.csv", "Fig. 6")

    mass_files = sorted((results / "faithfulness" / "bodmas").glob("seed*/region_mass.csv"))
    if mass_files:
        mass = pd.concat([pd.read_csv(p) for p in mass_files])
        regions = [r for r in REGION_CATEGORIES if r != "other"]
        fams = figs["attribution"]["families"]
        if all((mass["family"] == fam_name).any() for fam_name in fams):
            table = pd.DataFrame({"region": regions})
            for fam_name in fams:
                table[fam_name] = [round(float(mass.loc[mass["family"] == fam_name, r].mean()), 2) for r in regions]
            write(table, fig_out / "fig_attribution_mass.csv", "Fig. 2 (mass)")
        else:
            warnings.warn("attribution families missing from region_mass.csv: fig_attribution_mass.csv not rewritten")
        strip = mass_files[0].parent / "strip.csv"
        if strip.exists():
            fig_out.mkdir(parents=True, exist_ok=True)
            vals = np.loadtxt(strip)
            np.savetxt(fig_out / "fig_attribution_strip.csv", vals, fmt="%.3f",
                       header="normalised attribution along file offset (0..1), example BODMAS sample")
            log.info("wrote %s", fig_out / "fig_attribution_strip.csv")
    else:
        warnings.warn("no BODMAS faithfulness outputs: Fig. 2 data not rewritten")


if __name__ == "__main__":
    main()
