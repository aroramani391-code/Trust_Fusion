"""Bidirectional cross-modal co-attention (SPEC §2).

Modality-type embeddings are added once; each of the 2 layers (4 heads, width 512) lets image tokens attend to
static tokens and static tokens attend to image tokens (both from the layer input), followed by residual +
LayerNorm and a position-wise FFN with residual + LayerNorm. Outputs are mean-pooled to ``z~_v`` and ``z~_s``.
"""
from __future__ import annotations

import torch
import torch.nn as nn


class CoAttentionLayer(nn.Module):
    def __init__(self, d: int = 512, heads: int = 4, ffn_mult: int = 4, dropout: float = 0.0):
        super().__init__()
        self.v_from_s = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.s_from_v = nn.MultiheadAttention(d, heads, dropout=dropout, batch_first=True)
        self.norm_v1, self.norm_s1 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.norm_v2, self.norm_s2 = nn.LayerNorm(d), nn.LayerNorm(d)
        self.ffn_v = nn.Sequential(nn.Linear(d, ffn_mult * d), nn.GELU(), nn.Linear(ffn_mult * d, d))
        self.ffn_s = nn.Sequential(nn.Linear(d, ffn_mult * d), nn.GELU(), nn.Linear(ffn_mult * d, d))

    def forward(self, v: torch.Tensor, s: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        v_att, _ = self.v_from_s(v, s, s, need_weights=False)
        s_att, _ = self.s_from_v(s, v, v, need_weights=False)
        v = self.norm_v1(v + v_att)
        s = self.norm_s1(s + s_att)
        v = self.norm_v2(v + self.ffn_v(v))
        s = self.norm_s2(s + self.ffn_s(s))
        return v, s


class CoAttention(nn.Module):
    def __init__(self, d: int = 512, layers: int = 2, heads: int = 4, ffn_mult: int = 4):
        super().__init__()
        self.modality_type = nn.Parameter(torch.zeros(2, d))
        nn.init.trunc_normal_(self.modality_type, std=0.02)
        self.layers = nn.ModuleList([CoAttentionLayer(d, heads, ffn_mult) for _ in range(layers)])

    def forward(self, v_tokens: torch.Tensor, s_tokens: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        v = v_tokens + self.modality_type[0]
        s = s_tokens + self.modality_type[1]
        for layer in self.layers:
            v, s = layer(v, s)
        return v.mean(1), s.mean(1)
