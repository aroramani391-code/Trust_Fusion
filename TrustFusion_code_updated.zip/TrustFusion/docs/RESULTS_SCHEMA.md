# Output schema

All outputs are produced by the scripts; the repository ships `runs/` and `results/` empty.

## Run directories

```
runs/<corpus>/<protocol>/<method>/seed<k>/
    config.yaml                  fully merged configuration used for the run
    best.pt                      torch checkpoint (best validation macro-F1)            [torch methods]
    model.txt, model_meta.json   LightGBM booster (best iteration)                       [lgbm_static, conformal_lgbm]
    stacker.pkl                  fitted logistic-regression stacker                      [late_fusion]
    history.csv, train_info.json per-epoch validation macro-F1 / losses; best epoch, wall time, #parameters
    inference/{val,cal,test}.npz raw model outputs (below)
    calibration.json             split-conformal threshold fitted on the calibration split
    predictions.parquet          per-sample predictions (predictions.csv.gz when pyarrow is unavailable)
    probs.npz                    full probability matrix aligned with the prediction file
    metrics.json                 summary metrics of this run
    temporal_{sliding,static}.csv, predictions_static.parquet, calibration_windows_*.json     [pt_family runs]
runs/<corpus>/<protocol>/_image_stats_<channels>_<size>.json   training-split channel statistics (shared by seeds)
runs/tuning/<corpus>/<protocol>/<method>/{trial<kk>/, trials.csv, best.json, best_overrides.yaml}
```

`<protocol>` ∈ `pr_family`, `pr_detection`, `pt_family`, `pr_crosssource` (BODMAS); `family_subset`,
`detection_subset` (EMBER2024); `tiny_type`, `tiny_detection` (MalNet-Tiny). `<method>` is a method name
(`trustfusion`, `byte_cnn`, `msvit`, `lgbm_static`, `feature_graph`, `gin_callgraph`, `late_fusion`,
`cross_attention`, `mcdropout_cnn`, `conformal_lgbm`) or an evaluation variant `<method>__<variant>`
(e.g. `trustfusion__no_lcal`, `trustfusion__factorial__lcal_on__mc_off`, `cross_attention__ts`).

## `predictions.parquet`

One row per evaluated sample.

| column | type | meaning |
|---|---|---|
| `sample_id` | string | sha256 of the file |
| `corpus` | string | `bodmas`, `ember2024`, `malnet_tiny` |
| `task` | string | `family` (multi-class) or `detection` (0 = benign, 1 = malicious) |
| `protocol` | string | protocol name (see above) |
| `split` | string | evaluated split (`test`) |
| `window` | string | `W1`..`W7` for P-T, empty otherwise |
| `seed` | int | model seed |
| `method` | string | method / variant name |
| `y_true` | int | label index (`splits/<corpus>_<protocol>_classes.json`) |
| `y_pred` | int | `argmax p` |
| `p_max` | float | maximum class probability |
| `p_true` | float | probability of the true class |
| `entropy` | float | predictive entropy `H[p_bar]` (nats) |
| `mutual_info` | float | MC-dropout mutual information (0 for deterministic heads) |
| `gate` | float | TrustFusion gate `g` (NaN for other methods) |
| `set_size` | int | conformal prediction-set size (number of classes when the gate is disabled) |
| `in_set` | bool | true label ∈ prediction set |
| `accepted` | bool | `set_size == 1` (the model predicts; otherwise it abstains) |
| `benign_source` | string | `win10` / `win11` / `repo` for BODMAS benign files, benign source name for MalNet detection |
| `timestamp` | string | first-seen time (BODMAS, EMBER2024) |

`p` is `p_bar` (head-only MC mean) for `--head mc` and the dropout-free head for `--head det`; with temperature
scaling it is the temperature-scaled distribution.

## `probs.npz`

`p_bar`: float32 `[N, C]` probability matrix (rows in the order of the prediction file); `sample_id`: `[N]`.

## `inference/<split>.npz`

`sample_id`, `row` (row of `static.npy`), `label`, `window`, `benign_source`, `timestamp`, `p_bar` `[N, C]`,
`p_det` `[N, C]`, `entropy`, `mutual_info`, `gate` `[N]`, scalars `T` and `mc`.

## `calibration.json`

`{"head": "mc", "split": "cal", "qhat": <float or "inf">, "n": <|cal|>, "alpha": 0.05, "k": ceil((n+1)(1-alpha)),
"n_eff": null, "temperature": <optional>}`.

## `metrics.json`

`accuracy`, `macro_f1`, `ece`, `selective_error@<c>` for c ∈ {1, 0.95, …, 0.7}; with a conformal layer
`coverage`, `mean_set_size`, `acceptance`, `accepted_error`, `accepted_macro_f1`, `qhat`; detection tasks add
`roc_auc`, `tpr@fpr=0.001`, `tpr@fpr=0.01`.

## `temporal_<mode>.csv` (P-T)

One row per window: `window`, `tau`, `mode` (`sliding` | `static`), `calibration_pool`, `label_delay_months`, `n_cal`
(= |D_k|), `n_eff`, `qhat`, `n_test`, `accuracy`, `macro_f1`, `ece`, `coverage`, `mean_set_size`, `acceptance`,
`accepted_error`, `method`, `seed`, `head`.

## `results/`

```
results/tables/table4.csv, table4_long.csv   accuracy, macro-F1 (family protocols); ROC-AUC, TPR@FPR (detection) — mean ± SD
results/tables/table5.csv                    paired comparisons: means, mean difference, t-interval, t-test p, bootstrap CI/p, Holm p,
                                             manuscript columns t_ci ("[low, high]") and p_holm_formatted ("< 0.001" below 0.001)
results/tables/table6.csv                    ECE, coverage, mean set size, acceptance — mean ± SD
results/tables/table7.csv                    component ablation — mean ± SD
results/tables/table8.csv                    reliability factorial — mean ± SD
results/tables/table9.csv                    deletion / insertion AUC per corpus, variant, protocol — mean ± SD over seeds
results/tables/seed_stats_*.csv (+ *_per_seed.csv)   scripts/seed_stats.py outputs
results/ablation/component_per_seed.csv, factorial_per_seed.csv
results/faithfulness/<corpus>/seed<k>/per_sample.csv, summary.csv, region_mass.csv, strip.csv
results/provenance/per_source_fpr.csv, per_source_tpr.csv, consistency.csv, cross_source.csv, source_probe.json, summary.csv
```

`per_sample.csv` (faithfulness): `sample_id, variant, protocol, target, n_bytes, deletion_auc, insertion_auc, method,
seed`. `region_mass.csv`: `sample_id, family` and the attribution mass of `header, .text, .rdata, .data, .rsrc,
imports, overlay, other` (Grad-CAM++ through fusion).

## Splits

`splits/<corpus>_<protocol>.csv`: `row, sample_id, split, window, label, timestamp` (`sample_id` = sha256, `timestamp` =
first-seen time, empty for MalNet); `splits/<corpus>_<protocol>_classes.json`:
class names in label order; `splits/summary.json`: `{corpus: {protocol: {counts, ...}}}` with, among others,
`bodmas.pr_family.{n_classes, counts}`, `bodmas.pr_detection.{counts, benign_sources, benign_sources_per_split}`,
`bodmas.benign_pool.benign_sources`, `bodmas.pt_family.{n_named_families, K, windows, counts}` (`K` includes
`residual`), `bodmas.pr_crosssource.counts`, `ember2024.family_subset.{n_families, train_official, test_official,
malicious_train_official, malicious_test_official, counts, formats_per_split}`,
`ember2024.detection_subset.{train_official, test_official, counts}`, `malnet_tiny.tiny_type.{counts,
graph_unmatched}`, `malnet_tiny.tiny_detection.{benign_source, benign_per_split}`.

`results/provenance/per_source_fpr.csv`: `source, n_benign, fpr, threshold, tpr_at_threshold, seed`;
`per_source_tpr.csv`: `source, n_benign, n_malicious, tpr@fpr=0.01, roc_auc, seed`; `consistency.csv`: `source,
fpr_at_global_threshold, tpr_at_global_threshold, tpr@fpr=0.01, expected_vs_global (>= | <= | any), consistent, seed`.

## Processed corpora

`data/processed/<corpus>/meta.csv.gz` columns: `sample_id, sha256, family, is_malicious, timestamp, benign_source,
file_format, released_split, image_path, image_kind (bytes | png | empty), has_static, graph_path`;
`static.npy` float32 `[N, D]`; `corpus.json` with the layout, view kinds and preparation counts.
