"""TrustFusion model (SPEC §2).

image bytes -> ImageEncoder -> 49 image tokens ┐
                                                ├─ modality dropout (learned mask tokens) -> co-attention (2 layers)
static vector -> SetEncoder -> 8 group tokens  ┘      -> mean-pool z~_v, z~_s -> gate g -> z_f = g z~_v + (1-g) z~_s
z_f -> Dropout(0.2) -> Linear(512, C)          (the head dropout is the only stochastic layer at inference)

Ablation switches (``model`` config): ``fusion: concat`` (no co-attention: concatenation + linear projection, no
gate), ``use_image: false`` / ``use_static: false`` (single-stream; the missing view is the mask token),
``modality_dropout: 0``.
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn

from .base import ClassifierBase
from .coattention import CoAttention
from .image_encoder import BACKBONE_STRIDE, ImageEncoder
from .set_encoder import SetEncoder


def _as_bool(x: Any, n: int, device: torch.device) -> torch.Tensor:
    if isinstance(x, torch.Tensor):
        return x.to(device=device, dtype=torch.bool).reshape(-1)
    return torch.as_tensor(np.asarray(x, dtype=bool).reshape(-1) if x is not None else np.ones(n, bool), device=device)


class TrustFusion(ClassifierBase):
    def __init__(self, num_classes: int, group_indices: Sequence[np.ndarray], model_cfg: Mapping[str, Any],
                 image_size: int = 224):
        super().__init__()
        d = int(model_cfg.get("d_model", 512))
        self.d_model = d
        self.use_image = bool(model_cfg.get("use_image", True))
        self.use_static = bool(model_cfg.get("use_static", True))
        backbone = str(model_cfg.get("backbone", "resnet50"))
        if self.use_image:
            self.image_encoder = ImageEncoder(backbone, bool(model_cfg.get("pretrained", False)), d)
            self.n_image_tokens = self.image_encoder.n_tokens(image_size)
        else:
            self.image_encoder = None
            side = max(1, -(-image_size // BACKBONE_STRIDE.get(backbone, 32)))
            self.n_image_tokens = side * side
        self.n_static_tokens = len(group_indices)
        self.set_encoder = SetEncoder(group_indices, d, int(model_cfg.get("static_trunk_blocks", 2))) if self.use_static else None
        self.mask_token_v = nn.Parameter(torch.zeros(1, 1, d))
        self.mask_token_s = nn.Parameter(torch.zeros(1, 1, d))
        nn.init.trunc_normal_(self.mask_token_v, std=0.02)
        nn.init.trunc_normal_(self.mask_token_s, std=0.02)
        self.fusion = str(model_cfg.get("fusion", "coattention_gate"))
        co = dict(model_cfg.get("coattention", {}))
        if self.fusion == "coattention_gate":
            self.coattention = CoAttention(d, int(co.get("layers", 2)), int(co.get("heads", 4)), int(co.get("ffn_mult", 4)))
            self.gate = nn.Linear(2 * d, 1)
        elif self.fusion == "concat":
            self.concat = nn.Linear(2 * d, d)
        else:
            raise ValueError(f"unknown fusion {self.fusion!r}")
        self.modality_dropout = float(model_cfg.get("modality_dropout", 0.15))
        self.head_dropout_p = float(model_cfg.get("head_dropout", 0.2))
        self.head = nn.Linear(d, num_classes)
        self.align_proj = nn.Linear(d, d)

    # ----------------------------------------------------------------------------------------- stages
    def encode(self, batch: Mapping[str, Any], modality_dropout: bool = False) -> dict[str, torch.Tensor]:
        device = self.mask_token_v.device
        image: torch.Tensor = batch["image"]
        static: torch.Tensor = batch["static"]
        B = int(batch["label"].shape[0]) if isinstance(batch.get("label"), torch.Tensor) else int(max(image.shape[0], static.shape[0]))
        has_image = _as_bool(batch.get("has_image"), B, device)
        has_static = _as_bool(batch.get("has_static"), B, device)
        A = None
        if self.image_encoder is not None and image.numel() > 0 and bool(has_image.any()):
            A, v_tok = self.image_encoder(image.to(device))
            keep_v = has_image.clone()
        else:
            v_tok = self.mask_token_v.expand(B, self.n_image_tokens, -1)
            keep_v = torch.zeros(B, dtype=torch.bool, device=device)
        if self.set_encoder is not None and static.numel() > 0 and bool(has_static.any()):
            s_tok = self.set_encoder(static.to(device))
            keep_s = has_static.clone()
        else:
            s_tok = self.mask_token_s.expand(B, self.n_static_tokens, -1)
            keep_s = torch.zeros(B, dtype=torch.bool, device=device)
        z_v, z_s = v_tok.mean(1), s_tok.mean(1)  # pre-fusion encoder summaries (alignment loss, image branch)
        if modality_dropout and self.modality_dropout > 0:
            u = torch.rand(B, device=device)
            both = keep_v & keep_s
            p = self.modality_dropout
            keep_v = keep_v & ~(both & (u < p))
            keep_s = keep_s & ~(both & (u >= p) & (u < 2 * p))
        v_tok = torch.where(keep_v[:, None, None], v_tok, self.mask_token_v.expand_as(v_tok))
        s_tok = torch.where(keep_s[:, None, None], s_tok, self.mask_token_s.expand_as(s_tok))
        return {"A": A, "v_tokens": v_tok, "s_tokens": s_tok, "keep_v": keep_v, "keep_s": keep_s, "z_v": z_v, "z_s": z_s}

    def fuse(self, enc: Mapping[str, torch.Tensor]) -> dict[str, torch.Tensor | None]:
        if self.fusion == "concat":
            zt_v, zt_s = enc["v_tokens"].mean(1), enc["s_tokens"].mean(1)
            return {"zt_v": zt_v, "zt_s": zt_s, "gate": None, "z_f": self.concat(torch.cat([zt_v, zt_s], dim=-1))}
        zt_v, zt_s = self.coattention(enc["v_tokens"], enc["s_tokens"])
        g = torch.sigmoid(self.gate(torch.cat([zt_v, zt_s], dim=-1)))
        return {"zt_v": zt_v, "zt_s": zt_s, "gate": g, "z_f": g * zt_v + (1 - g) * zt_s}

    def features(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:
        enc = self.encode(batch, modality_dropout=self.training)
        fused = self.fuse(enc)
        out: dict[str, Any] = {**enc, **fused}
        out["z"] = fused["z_f"]
        return out

    def image_branch_logits(self, enc: Mapping[str, torch.Tensor]) -> torch.Tensor:
        """Class scores from the image branch alone (classifier head on the pooled image tokens, no fusion)."""
        return self.head(enc["z_v"])

    def compute_loss(self, batch: Mapping[str, Any], out: Mapping[str, torch.Tensor], criterion: nn.Module
                     ) -> tuple[torch.Tensor, dict[str, float]]:
        pair = out["keep_v"] & out["keep_s"]
        return criterion(out["logits"], batch["label"], z_v=self.align_proj(out["z_v"]),
                         z_s=self.align_proj(out["z_s"]), pair_mask=pair)
