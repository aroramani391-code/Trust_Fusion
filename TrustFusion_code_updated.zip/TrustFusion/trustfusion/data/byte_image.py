"""Byte-to-image conversion, augmentation, PE region parsing and pixel -> byte-offset inversion (SPEC §2).

Rendering
---------
* width ``w`` from the file size (Nataraj et al., 2011): <10 KB: 32; 10-30 KB: 64; 30-60 KB: 128;
  60-100 KB: 256; 100-200 KB: 384; 200-500 KB: 512; 500 KB-1 MB: 768; >=1 MB: 1024 (1 KB = 1024 bytes;
  each interval is closed on the left).
* ``h = ceil(|b| / w)``; the raster is zero padded.
* channels: (1) grey ``b/255``; (2) entropy: windows of ``L=256`` bytes with stride 128 (starts at
  0, 128, ... < |b|, truncated at the end of the file), Shannon entropy / 8 of each window averaged over all
  windows that contain the byte; (3) bigram: ``log(1+count[b_{t-1}, b_t]) / log(1+max count)`` with the
  file-level bigram count matrix (the first byte has no predecessor and gets 0).
* resize to 224 x 224 (bilinear, antialias, ``align_corners=False``).

Inverse mapping (Eq. 3)
-----------------------
Byte ``t`` sits at raster cell ``(r, c) = divmod(t, w)``. Its centre maps to resized pixel coordinates
``y = (r + 0.5) * S / h - 0.5`` and ``x = (c + 0.5) * S / w - 0.5`` (the inverse of the
``align_corners=False`` resize), where attribution maps are sampled bilinearly. :func:`byte_to_pixel` and
:func:`pixel_to_byte_ranges` give the discrete correspondence between pixels and byte intervals.
"""
from __future__ import annotations

import math
import struct
from dataclasses import dataclass
from typing import Iterable, Sequence

import numpy as np
import torch
import torch.nn.functional as F

KB = 1024
#: (exclusive upper size bound in bytes, width)
WIDTH_TABLE: tuple[tuple[int, int], ...] = (
    (10 * KB, 32),
    (30 * KB, 64),
    (60 * KB, 128),
    (100 * KB, 256),
    (200 * KB, 384),
    (500 * KB, 512),
    (1024 * KB, 768),
)
MAX_WIDTH = 1024
CHANNELS = ("grey", "entropy", "bigram")
REGION_CATEGORIES = ("header", ".text", ".rdata", ".data", ".rsrc", "imports", "overlay", "other")


# --------------------------------------------------------------------------------------------- geometry
def image_width(n_bytes: int) -> int:
    for bound, width in WIDTH_TABLE:
        if n_bytes < bound:
            return width
    return MAX_WIDTH


def raster_shape(n_bytes: int) -> tuple[int, int]:
    w = image_width(n_bytes)
    h = max(1, math.ceil(n_bytes / w))
    return h, w


def as_uint8(data: bytes | bytearray | memoryview | np.ndarray) -> np.ndarray:
    if isinstance(data, np.ndarray):
        return data.astype(np.uint8, copy=False).reshape(-1)
    return np.frombuffer(bytes(data), dtype=np.uint8)


# --------------------------------------------------------------------------------------------- channels
def grey_channel(arr: np.ndarray) -> np.ndarray:
    return arr.astype(np.float32) / 255.0


def entropy_channel(arr: np.ndarray, window: int = 256, stride: int = 128, chunk_blocks: int = 2048) -> np.ndarray:
    """Per-byte average of windowed Shannon entropy / 8 (memory-bounded, vectorised)."""
    if window % stride != 0:
        raise ValueError("window must be a multiple of stride")
    n = int(arr.size)
    if n == 0:
        return np.zeros(0, dtype=np.float32)
    m = window // stride  # blocks per window
    nb = -(-n // stride)  # number of blocks == number of window starts (< n)
    win_entropy = np.empty(nb, dtype=np.float64)
    a = arr.astype(np.int64, copy=False)
    for b0 in range(0, nb, chunk_blocks):
        b1 = min(nb, b0 + chunk_blocks)
        e = min(nb, b1 + m - 1)
        seg = a[b0 * stride: min(n, e * stride)]
        idx = (np.arange(seg.size, dtype=np.int64) // stride) * 256 + seg
        block_hist = np.bincount(idx, minlength=(e - b0) * 256).reshape(e - b0, 256)
        cum = np.zeros((e - b0 + 1, 256), dtype=np.int64)
        np.cumsum(block_hist, axis=0, out=cum[1:])
        starts = np.arange(b0, b1) - b0
        ends = np.minimum(starts + m, e - b0)
        hist = (cum[ends] - cum[starts]).astype(np.float64)
        p = hist / hist.sum(axis=1, keepdims=True)
        plogp = np.zeros_like(p)
        nz = p > 0
        plogp[nz] = p[nz] * np.log2(p[nz])
        win_entropy[b0:b1] = -plogp.sum(axis=1) / 8.0
    # block b is covered by windows starting at blocks max(0, b-m+1) .. b
    cs = np.concatenate([[0.0], np.cumsum(win_entropy)])
    b = np.arange(nb)
    lo = np.maximum(0, b - m + 1)
    block_val = (cs[b + 1] - cs[lo]) / (b + 1 - lo)
    lengths = np.full(nb, stride, dtype=np.int64)
    lengths[-1] = n - (nb - 1) * stride
    return np.repeat(block_val, lengths).astype(np.float32)


def bigram_channel(arr: np.ndarray) -> np.ndarray:
    n = int(arr.size)
    out = np.zeros(n, dtype=np.float32)
    if n < 2:
        return out
    pair = arr[:-1].astype(np.int64) * 256 + arr[1:].astype(np.int64)
    counts = np.bincount(pair, minlength=65536)
    denom = np.log1p(counts.max())
    out[1:] = (np.log1p(counts[pair]) / denom).astype(np.float32)
    return out


def render_channels(
    data: bytes | np.ndarray,
    channels: Sequence[str] = CHANNELS,
    entropy_window: int = 256,
    entropy_stride: int = 128,
) -> np.ndarray:
    """Render the un-resized raster ``[C, h, w]`` (float32). ``grey3`` replicates the grey channel 3x."""
    arr = as_uint8(data)
    n = int(arr.size)
    h, w = raster_shape(n)
    if list(channels) == ["grey3"]:
        channels = ["grey", "grey", "grey"]
    cache: dict[str, np.ndarray] = {}
    out = np.zeros((len(channels), h * w), dtype=np.float32)
    for ci, name in enumerate(channels):
        if name not in cache:
            if name == "grey":
                cache[name] = grey_channel(arr)
            elif name == "entropy":
                cache[name] = entropy_channel(arr, entropy_window, entropy_stride)
            elif name == "bigram":
                cache[name] = bigram_channel(arr)
            else:
                raise ValueError(f"unknown channel {name!r}")
        out[ci, :n] = cache[name]
    return out.reshape(len(channels), h, w)


def resize_image(img: np.ndarray | torch.Tensor, size: int = 224, antialias: bool = True) -> torch.Tensor:
    t = torch.as_tensor(img, dtype=torch.float32)
    if t.dim() != 3:
        raise ValueError("expected [C, h, w]")
    return F.interpolate(t[None], size=(size, size), mode="bilinear", align_corners=False,
                         antialias=antialias)[0]


def render_byte_image(
    data: bytes | np.ndarray,
    size: int = 224,
    channels: Sequence[str] = CHANNELS,
    entropy_window: int = 256,
    entropy_stride: int = 128,
    antialias: bool = True,
) -> torch.Tensor:
    """Full rendering pipeline (without normalisation): bytes -> ``[C, size, size]`` in [0, 1]."""
    return resize_image(render_channels(data, channels, entropy_window, entropy_stride), size, antialias)


def load_png_image(path: str, size: int = 224, antialias: bool = True) -> torch.Tensor:
    """Load a pre-rendered image (MalNet-Image PNG) as 3-channel float in [0, 1], resized to ``size``."""
    from PIL import Image

    with Image.open(path) as im:
        arr = np.asarray(im.convert("RGB"), dtype=np.float32) / 255.0
    return resize_image(np.transpose(arr, (2, 0, 1)), size, antialias)


# --------------------------------------------------------------------------------------------- normalisation
@dataclass
class ChannelStats:
    mean: list[float]
    std: list[float]

    def normalise(self, img: torch.Tensor) -> torch.Tensor:
        mean = torch.tensor(self.mean, dtype=img.dtype).view(-1, 1, 1)
        std = torch.tensor(self.std, dtype=img.dtype).view(-1, 1, 1)
        return (img - mean) / std

    @staticmethod
    def identity(n_channels: int = 3) -> "ChannelStats":
        return ChannelStats([0.0] * n_channels, [1.0] * n_channels)


def compute_channel_stats(images: Iterable[torch.Tensor], eps: float = 1e-6) -> ChannelStats:
    """Per-channel mean / std over all pixels of the given (training-split) images."""
    total = None
    total_sq = None
    count = 0
    for img in images:
        img = img.double()
        s = img.sum(dim=(-2, -1))
        sq = (img ** 2).sum(dim=(-2, -1))
        total = s if total is None else total + s
        total_sq = sq if total_sq is None else total_sq + sq
        count += img.shape[-1] * img.shape[-2]
    if total is None or count == 0:
        raise ValueError("no images to compute statistics from")
    mean = total / count
    var = (total_sq / count - mean ** 2).clamp_min(0)
    std = var.sqrt().clamp_min(eps)
    return ChannelStats(mean.tolist(), std.tolist())


# --------------------------------------------------------------------------------------------- PE parsing
@dataclass(frozen=True)
class Region:
    name: str
    start: int
    end: int  # exclusive


@dataclass
class PEInfo:
    size_of_headers: int
    sections: list[Region]
    imports: Region | None
    overlay_start: int
    n_bytes: int

    def regions(self) -> list[Region]:
        out = [Region("header", 0, min(self.size_of_headers, self.n_bytes))]
        out += self.sections
        if self.imports is not None:
            out.append(self.imports)
        if self.overlay_start < self.n_bytes:
            out.append(Region("overlay", self.overlay_start, self.n_bytes))
        return out


def parse_pe(data: bytes | np.ndarray) -> PEInfo | None:
    """Minimal, dependency-free PE header / section-table parser. Returns ``None`` for non-PE input."""
    buf = bytes(as_uint8(data)) if isinstance(data, np.ndarray) else bytes(data)
    n = len(buf)
    try:
        if n < 0x40 or buf[:2] != b"MZ":
            return None
        e_lfanew = struct.unpack_from("<I", buf, 0x3C)[0]
        if e_lfanew + 24 > n or buf[e_lfanew:e_lfanew + 4] != b"PE\x00\x00":
            return None
        coff = e_lfanew + 4
        _machine, n_sections, _ts, _sym, _nsym, size_opt, _chars = struct.unpack_from("<HHIIIHH", buf, coff)
        opt = coff + 20
        magic = struct.unpack_from("<H", buf, opt)[0]
        size_of_headers = struct.unpack_from("<I", buf, opt + 60)[0]
        dd_offset = opt + (96 if magic == 0x10B else 112)
        n_rva = struct.unpack_from("<I", buf, dd_offset - 4)[0]
        sec_table = opt + size_opt
        raw_secs = []
        for i in range(n_sections):
            off = sec_table + 40 * i
            if off + 40 > n:
                break
            name = buf[off:off + 8].split(b"\x00", 1)[0].decode("latin-1")
            vsize, va, raw_size, raw_ptr = struct.unpack_from("<IIII", buf, off + 8)
            raw_secs.append((name, vsize, va, raw_size, raw_ptr))
    except struct.error:
        return None
    sections = []
    end_of_image = min(size_of_headers, n)
    for name, _vsize, _va, raw_size, raw_ptr in raw_secs:
        if raw_size == 0 or raw_ptr >= n:
            continue
        s, e = raw_ptr, min(n, raw_ptr + raw_size)
        sections.append(Region(name, s, e))
        end_of_image = max(end_of_image, raw_ptr + raw_size)
    imports = None
    if n_rva > 1 and dd_offset + 16 <= n:
        imp_rva, imp_size = struct.unpack_from("<II", buf, dd_offset + 8)
        if imp_rva and imp_size:
            for _name, vsize, va, raw_size, raw_ptr in raw_secs:
                if va <= imp_rva < va + max(vsize, raw_size):
                    s = imp_rva - va + raw_ptr
                    if s < n:
                        imports = Region("imports", s, min(n, s + imp_size))
                    break
    return PEInfo(size_of_headers=size_of_headers, sections=sections, imports=imports,
                  overlay_start=min(end_of_image, n), n_bytes=n)


def region_labels(n_bytes: int, info: PEInfo | None) -> np.ndarray:
    """Assign every byte to one of :data:`REGION_CATEGORIES` (imports override their host section)."""
    codes = np.full(n_bytes, REGION_CATEGORIES.index("other"), dtype=np.uint8)
    if info is None:
        return codes
    codes[: min(info.size_of_headers, n_bytes)] = REGION_CATEGORIES.index("header")
    for sec in info.sections:
        name = sec.name if sec.name in REGION_CATEGORIES else ("imports" if sec.name == ".idata" else "other")
        codes[sec.start:sec.end] = REGION_CATEGORIES.index(name)
    if info.imports is not None:
        codes[info.imports.start:info.imports.end] = REGION_CATEGORIES.index("imports")
    if info.overlay_start < n_bytes:
        codes[info.overlay_start:] = REGION_CATEGORIES.index("overlay")
    return codes


def region_mass(byte_scores: np.ndarray, info: PEInfo | None) -> dict[str, float]:
    """Normalised attribution mass per PE region (sums to 1 when any score is positive)."""
    scores = np.clip(np.asarray(byte_scores, dtype=np.float64), 0, None)
    codes = region_labels(scores.size, info)
    mass = np.bincount(codes, weights=scores, minlength=len(REGION_CATEGORIES))
    total = mass.sum()
    if total > 0:
        mass = mass / total
    return {name: float(m) for name, m in zip(REGION_CATEGORIES, mass)}


# --------------------------------------------------------------------------------------------- augmentation
def truncate_overlay(data: bytes | np.ndarray, rng: np.random.Generator, p: float = 0.3,
                     max_fraction: float = 0.5, info: PEInfo | None = None) -> np.ndarray:
    """With probability ``p`` drop a U(0, max_fraction) fraction of the bytes after the last section (PE only)."""
    arr = as_uint8(data)
    if info is None:
        info = parse_pe(arr)
    if info is None or rng.random() >= p:
        return arr
    overlay_len = arr.size - info.overlay_start
    if overlay_len <= 0:
        return arr
    cut = int(round(rng.uniform(0.0, max_fraction) * overlay_len))
    return arr[: arr.size - cut] if cut > 0 else arr


def entropy_jitter(img: torch.Tensor, rng: np.random.Generator, channel: int = 1,
                   low: float = 0.95, high: float = 1.05) -> torch.Tensor:
    """Multiply the entropy channel by U(low, high)."""
    out = img.clone()
    out[channel] = out[channel] * float(rng.uniform(low, high))
    return out


# --------------------------------------------------------------------------------------------- inversion
def byte_to_pixel(offsets: np.ndarray | int, n_bytes: int, size: int = 224) -> tuple[np.ndarray, np.ndarray]:
    """Resized pixel ``(i, j)`` containing the start of raster cell of each byte offset."""
    h, w = raster_shape(n_bytes)
    offsets = np.asarray(offsets, dtype=np.int64)
    r, c = np.divmod(offsets, w)
    i = np.minimum((r * size) // h, size - 1)
    j = np.minimum((c * size) // w, size - 1)
    return i, j


def pixel_to_byte_ranges(i: int, j: int, n_bytes: int, size: int = 224) -> list[tuple[int, int]]:
    """Byte intervals ``[start, end)`` whose raster cells overlap resized pixel ``(i, j)``."""
    h, w = raster_shape(n_bytes)
    r0, r1 = (i * h) // size, -(-((i + 1) * h) // size)
    c0, c1 = (j * w) // size, -(-((j + 1) * w) // size)
    ranges = []
    for r in range(r0, min(r1, h)):
        s = r * w + c0
        e = min(r * w + min(c1, w), n_bytes)
        if s < e:
            ranges.append((s, e))
    return ranges


def upsample_cam(cam: np.ndarray | torch.Tensor, size: int = 224) -> np.ndarray:
    t = torch.as_tensor(cam, dtype=torch.float32)
    if t.dim() == 2:
        t = t[None, None]
    return F.interpolate(t, size=(size, size), mode="bilinear", align_corners=False)[0, 0].numpy()


def project_to_bytes(cam: np.ndarray | torch.Tensor, n_bytes: int, size: int = 224,
                     chunk: int = 1 << 22) -> np.ndarray:
    """Project an attribution map (any spatial size) to per-byte scores by inverting resize and raster."""
    cam224 = upsample_cam(cam, size) if tuple(np.shape(cam)) != (size, size) else np.asarray(cam, np.float32)
    h, w = raster_shape(n_bytes)
    out = np.empty(n_bytes, dtype=np.float32)
    for s in range(0, n_bytes, chunk):
        t = np.arange(s, min(n_bytes, s + chunk), dtype=np.int64)
        r, c = np.divmod(t, w)
        y = np.clip((r + 0.5) * size / h - 0.5, 0, size - 1)
        x = np.clip((c + 0.5) * size / w - 0.5, 0, size - 1)
        y0 = np.floor(y).astype(np.int64)
        x0 = np.floor(x).astype(np.int64)
        y1 = np.minimum(y0 + 1, size - 1)
        x1 = np.minimum(x0 + 1, size - 1)
        wy = (y - y0).astype(np.float32)
        wx = (x - x0).astype(np.float32)
        top = cam224[y0, x0] * (1 - wx) + cam224[y0, x1] * wx
        bot = cam224[y1, x0] * (1 - wx) + cam224[y1, x1] * wx
        out[s:s + t.size] = top * (1 - wy) + bot * wy
    return out
