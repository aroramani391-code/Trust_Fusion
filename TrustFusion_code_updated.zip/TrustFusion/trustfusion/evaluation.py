"""Method-agnostic calibration and evaluation of a run directory (used by the scripts).

Both steps read ``inference/<split>.npz`` so torch models, LightGBM and the stacker share one code path.
``head='mc'`` uses ``p_bar`` (head-only MC dropout when the method enables it), ``head='det'`` uses ``p_det``
(dropout disabled at test; the "MC head off" cell of the reliability factorial).
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Mapping

import numpy as np
import yaml

from .conformal import apply_temperature, calibrate_split, fit_temperature, prediction_sets
from .io import json_float, prediction_frame, read_json, write_json, write_predictions, write_probs
from .metrics import classification_metrics, conformal_metrics, detection_metrics
from .training import load_inference


def run_config(run: str | Path) -> dict[str, Any]:
    with open(Path(run) / "config.yaml", "r", encoding="utf8") as f:
        return yaml.safe_load(f)


def select_probs(inf: Mapping[str, np.ndarray], head: str, temperature: float | None = None) -> np.ndarray:
    if head not in ("mc", "det"):
        raise ValueError(head)
    p = np.asarray(inf["p_bar"] if head == "mc" else inf["p_det"], dtype=np.float64)
    if temperature is not None:
        p = apply_temperature(np.log(np.clip(p, 1e-45, None)), temperature)
    return p


def calibrate_run(run: str | Path, alpha: float = 0.05, head: str = "mc", temperature: bool = False,
                  name: str = "calibration") -> dict[str, Any]:
    run = Path(run)
    cal = load_inference(run, "cal")
    out: dict[str, Any] = {"head": head, "split": "cal"}
    T = None
    if temperature:
        T = fit_temperature(np.log(np.clip(np.asarray(cal["p_det"], np.float64), 1e-45, None)), cal["label"])
        out["temperature"] = T
    p = select_probs(cal, head if T is None else "det", T)
    out.update(calibrate_split(p, cal["label"], alpha).to_dict())
    write_json(run / f"{name}.json", out)
    return out


def require_detection_benign_source(cfg: Mapping[str, Any], benign_source: str | None = None) -> None:
    """MalNet-Tiny has no benign class: detection metrics need an explicit, consistent benign source."""
    if cfg.get("corpus") != "malnet_tiny" or cfg.get("task") != "detection":
        return
    trained = cfg.get("data", {}).get("benign_source")
    if not benign_source:
        raise RuntimeError("MalNet-Tiny detection metrics need an explicit --benign-source; refusing to compute them")
    if trained and trained != benign_source:
        raise RuntimeError(f"--benign-source {benign_source!r} differs from the training run's benign source {trained!r}")


def evaluate_run(run: str | Path, head: str = "mc", out_dir: str | Path | None = None, method_name: str | None = None,
                 conformal: bool = True, calibration_name: str = "calibration", split: str = "test",
                 benign_source: str | None = None,
                 n_bins: int = 15, coverages: tuple[float, ...] = (1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7),
                 fpr_targets: tuple[float, ...] = (1e-3, 1e-2)) -> dict[str, Any]:
    """Apply the stored conformal threshold to ``split`` and write predictions, probabilities and metrics."""
    run = Path(run)
    cfg = run_config(run)
    out_dir = Path(out_dir) if out_dir is not None else run
    method = method_name or run.parent.name
    seed = int(run.name.replace("seed", ""))
    inf = load_inference(run, split)
    calib = read_json(run / f"{calibration_name}.json") if conformal and (run / f"{calibration_name}.json").exists() else None
    T = calib.get("temperature") if calib else None
    p = select_probs(inf, head if T is None else "det", T)
    y = np.asarray(inf["label"], dtype=np.int64)
    n, C = p.shape
    y_pred = p.argmax(1)
    task = str(cfg.get("task", "family"))
    metrics: dict[str, Any] = {"method": method, "seed": seed, "corpus": cfg.get("corpus"), "protocol": cfg.get("protocol"),
                               "task": task, "head": head, "split": split}
    metrics.update(classification_metrics(p, y, n_bins, coverages))
    if conformal and calib is not None:
        qhat = json_float(calib["qhat"])
        sets = prediction_sets(p, qhat)
        metrics.update(conformal_metrics(sets, y, y_pred))
        metrics["qhat"] = qhat
        set_size = sets.sum(1)
        in_set = sets[np.arange(n), y]
        accepted = set_size == 1
    else:
        set_size = np.full(n, C)
        in_set = np.ones(n, bool)
        accepted = np.ones(n, bool)  # no conformal gate: predict on every sample
        metrics["conformal"] = False
    if task == "detection":
        require_detection_benign_source(cfg, benign_source)
        metrics["benign_source"] = benign_source
        metrics.update(detection_metrics(p[:, 1], y, fpr_targets))
    ent = -(p * np.log(np.clip(p, 1e-12, None))).sum(1)
    df = prediction_frame(
        n, sample_id=inf["sample_id"], corpus=cfg.get("corpus"), task=task, protocol=cfg.get("protocol"), split=split,
        window=inf["window"], seed=seed, method=method, y_true=y, y_pred=y_pred, p_max=p.max(1), p_true=p[np.arange(n), y],
        entropy=ent if head == "det" or T is not None else inf["entropy"],
        mutual_info=np.zeros(n) if head == "det" or T is not None else inf["mutual_info"], gate=inf["gate"],
        set_size=set_size, in_set=in_set, accepted=accepted, benign_source=inf["benign_source"], timestamp=inf["timestamp"])
    write_predictions(df, out_dir)
    write_probs(out_dir, p, inf["sample_id"])
    write_json(out_dir / "metrics.json", metrics)
    return metrics
