# Experimental protocol

This document describes exactly what the code does; `SPEC.md` is the normative list of values. All splits use
split seed **2024** and are identical for every method and every model seed {0, 1, 2, 3, 4}.

## 1. Split sizes (Table 2)

| corpus / protocol | train | val | cal | test | produced by |
|---|---:|---:|---:|---:|---|
| BODMAS P-R family (97 classes) | 40,105 | 4,297 | 4,297 | 8,594 | `splits.bodmas_pr_family` |
| BODMAS P-R detection (24,180 malicious + 24,180 benign) | 33,852 | 3,627 | 3,627 | 7,254 | `splits.bodmas_pr_detection` |
| BODMAS P-T (68 families + residual; fit Aug–Nov 2019 / D1 = Dec 2019 / W1..W7 = Jan–Jul 2020) | fit − 10% | 10% of fit | D1 | W1..W7 | `splits.bodmas_pt` |
| EMBER2024 family subset (2,358 families; 1,101,898 official training / 254,284 test files) | rest − 10% | 10% of rest | last 4 training weeks | 254,284 | `splits.ember2024_family_subset` |
| EMBER2024 detection subset (Win32 + Win64 + .NET) | 2,106,000 | 234,000 | – | 540,000 | `splits.ember2024_detection_subset` |
| MalNet-Image Tiny (43 types) | 61,201 | 4,371 | 4,372 | 17,486 | `splits.malnet_tiny_type` |

`scripts/make_splits.py` prints every count and writes it to `splits/summary.json`; `--check-counts` asserts every
count the manuscript reports: the sizes above, the benign pool by source (11,368 / 9,527 / 3,285), the 68 P-T
families, the EMBER2024 family-subset totals, the 1,286 MalNet files without a call graph and the 5,000 MalNet
detection benign files. The per-window P-T sizes and the train/val/cal breakdown of the EMBER2024 family subset are
not reported in the manuscript and are only recorded. The EMBER2024 detection train/val sizes follow from the 10%
rule applied to the official 2,340,000 files.

Split files `splits/<corpus>_<protocol>.csv` list `row, sample_id, split, window, label, timestamp`: `sample_id` is the
sha256 and `timestamp` the first-seen time of the file (empty for MalNet, which has none).

## 2. BODMAS

**Data.** 57,293 malicious PE files (581 families, first seen Aug 2019 – Sep 2020) with 2,381-d EMBER v2 vectors and
disarmed binaries; metadata gives sha256, first-seen timestamp and family. Benign pool: 24,180 PE files with a
`source` column: 11,368 from clean Windows 10 installations (`win10`), 9,527 from clean Windows 11 installations
(`win11`) and 3,285 from open-source repositories (`repo`).

**Family label space (P-R).** Families with >= 25 samples become classes (96 named families, sorted alphabetically)
and every other family is mapped to `residual` (97 classes).

**Exact two-stage stratified procedure** (sklearn `train_test_split`, `random_state=2024`, stratified by class):

```python
rest,  test  = train_test_split(idx,    test_size=0.15,      stratify=y[idx],    random_state=2024)  # 8,594
train, vc    = train_test_split(rest,   test_size=len(test), stratify=y[rest],   random_state=2024)  # 40,105 / 8,594
val,   cal   = train_test_split(vc,     test_size=0.5,       stratify=y[vc],     random_state=2024)  # 4,297 / 4,297
```

sklearn computes the test size as `ceil(0.15 * 57,293) = 8,594`; the second stage takes an absolute val+cal size
equal to the test size; halving 8,594 gives 4,297 + 4,297 (the first returned part is `val`, the second `cal`).

**P-R detection subset.** 24,180 malicious files are sampled stratified by the 97-class family label
(`train_test_split(train_size=24180, stratify=family_label, random_state=2024)`) and joined with the 24,180 benign
files. Strata = detection class × benign source (`malicious`, `benign|win10`, `benign|win11`, `benign|repo`); the
same two-stage procedure gives 33,852 / 3,627 / 3,627 / 7,254 (`ceil(0.15 * 48,360) = 7,254`).

Strata with a single member cannot be stratified by sklearn; `splits.safe_strata` pools such strata into one
`__rare__` stratum. This never triggers for the manuscript's label spaces (every P-R class has >= 25 samples).

**Cross-source run (provenance control).** From the detection split, benign `repo` files are removed from
train/val/cal; the benign test files are all `repo` files of the detection subset (none is used for fitting in this
run); malicious test files are unchanged (`configs/data/bodmas.yaml: splits.cross_source`).

**Provenance control** (`scripts/run_provenance.py`, Section 5.2). On the detection test split: the threshold `t` that
gives 1% FPR on all benign test files, the FPR of each benign source at `t` and the TPR at `t`; the TPR at 1% FPR
with the benign test files restricted to one source; a LightGBM source probe (5-fold CV macro one-vs-rest AUC); and
the cross-source run. The malicious test files are the same for every source, so each source's ROC curve passes
through (FPR of the source at `t`, TPR at `t`). A monotone ROC then fixes the side on which the per-source TPR at 1%
FPR must lie: at least the TPR at `t` for a source whose FPR at `t` is below 1%, at most that TPR for a source above
1%. `provenance_consistency` checks this for every seed and `run_provenance.py` writes `consistency.csv` and warns on
any violation; reported per-source FPR/TPR pairs must satisfy it (for example, a source with 0.82% FPR at `t` cannot
have a lower TPR at 1% FPR than a source with 1.15%).

## 3. P-T chronological protocol (BODMAS)

Timestamps are first-seen times; intervals are half-open.

| period | interval | use |
|---|---|---|
| fit | 2019-08-01 <= t < 2019-12-01 | training; a stratified random 10% is held out for early stopping |
| D1 | 2019-12-01 <= t < 2020-01-01 | initial calibration pool (never used for fitting or early stopping) |
| W1 .. W7 | calendar months Jan 2020 .. Jul 2020 | test windows |
| unused | Aug – Sep 2020 | — |

Label space: families with >= 25 samples in the development period (2019-08-01 <= t < 2020-01-01) plus `residual`:
68 named families + residual. `splits/summary.json` records `bodmas.pt_family.n_named_families` (68, the manuscript's
*K*) and `bodmas.pt_family.K` (69, the number of classes including `residual`).

Deployment loop (`trustfusion.temporal.run_deployment`, `scripts/run_temporal.py`):

```
train once on fit (early stopping on the 10% validation part); freeze network, gate and head
p_bar(x) = frozen model's head-only MC-dropout mean for every sample in D1 and W1..W7
for k = 1..7:
    tau_k  = start of W_k
    pool   = D1                      if k = 1
             W_{k-1-d}               if k >= 2 and k-1-d >= 1   (d = label_delay_months, default 0)
             D1                      otherwise                   (the fit period is never used)
    assert pool ∩ W_k = ∅,  max t(pool) < tau_k,  end(pool) + d months <= tau_k,  no fit/val sample in pool
    w_i    = 2^(-(tau_k - t_i)/15 days)                          for i in pool
    q_k    = weighted conformal quantile of s_i = 1 - p_bar(y_i|x_i)   (computed once at tau_k)
    n_eff  = (Σ w_i)^2 / Σ w_i^2
    for x in W_k:  C(x) = {y : 1 - p_bar(y|x) <= q_k};  predict iff |C(x)| = 1   (q_k frozen during W_k)
    report macro-F1, accuracy, ECE, coverage, mean set size, acceptance, |D_k|, n_eff, q_k
```

The labels of `W_k` are only used after `W_k` has closed. The *static* variant (Table 8) uses the unweighted split
threshold of D1 for every window.

## 4. EMBER2024

Official split: 2,626,000 training files (first seen 2023-09-24 .. 2024-09-21) and 606,000 test files
(2024-09-22 .. 2024-12-14); 2,568-d vectors (thrember feature version 3); six formats (Win32, Win64, .NET, APK, ELF,
PDF). No binaries are released, so TrustFusion runs in single-stream mode: the image view is permanently replaced by
its mask token.

**Family subset** (Table 4 accuracy/macro-F1, Table 6, coverage, Fig. 5). Malicious files of all six formats whose
ClarAVy family occurs >= 10 times among the malicious training files (2,358 families; recomputed from the metadata
and asserted with `--check-counts`): 1,101,898 official training files and 254,284 official test files. Benign files
carry no family, so the subset is a subset of the malicious files of the official split; `splits/summary.json`
records `train_official` / `test_official` next to `malicious_train_official` / `malicious_test_official` and
`make_splits.py` asserts the bound.
* calibration = family-subset training files first seen in the last four training weeks, 2024-08-25 .. 2024-09-21;
* validation = stratified 10% (by family) of the remaining family-subset training files; training = the rest;
* test = official test files whose family belongs to the 2,358 families.

**Detection subset** (Table 4 AUC, Fig. 3). Win32 + Win64 + .NET files only: official training files (2,340,000;
stratified 10% validation by class) and official test files (540,000); benign and malicious files are balanced.

Feature layout: `configs/feature_layouts/ember2024.yaml` lists the twelve thrember blocks (general 7, histogram 256,
byte-entropy 256, strings 177, header 74, section 224, imports 1,282, exports 129, data directories 34, Rich header 33,
Authenticode 8, pefile warnings 88) and maps them onto the eight BODMAS group names (Rich header and pefile
warnings -> header; Authenticode -> general). If `thrember` is installed the block sizes are asserted against it.

## 5. MalNet-Image Tiny

Released split 61,201 / 8,743 / 17,486 over 43 types (the four largest types removed); 256 x 256 DEX images resized
to 224 x 224. The released validation split is halved with `train_test_split(test_size=0.5, stratify=type,
random_state=2024)`: `ceil(4371.5) = 4,372` files form the calibration split and 4,371 the validation split.

Second view: a 48-d function-call-graph descriptor computed with networkx from the MalNet-Graph edge list with the
same sha256 (4 groups × 12 features: size/connectivity, degree statistics, degree histogram, local structure; see
`configs/feature_layouts/malnet_callgraph.yaml`). Files without a matching graph keep the image view and the graph
view is replaced by its mask token; their number is `splits/summary.json: malnet_tiny.tiny_type.graph_unmatched`.

Files without a matching graph: 1,286 (asserted with `--check-counts`).

Detection needs a benign class that the Tiny partition does not contain. The manuscript uses 5,000 benign Android
APKs collected from the Google Play Store with zero VirusTotal detections, rendered as MalNet-style DEX images
(benign source `googleplay`; `prepare_malnet.py --benign-images-dir ... --benign-source googleplay`).
`make_splits.py --benign-source googleplay` builds `tiny_detection` from the Tiny malicious files plus these benign
files (randomly partitioned, seed 2024, in the Tiny split proportions; 5,000 asserted with `--check-counts`);
`evaluate.py` refuses to compute detection metrics without `--benign-source`.

## 6. Byte images

Width table (Nataraj et al., 2011; 1 KB = 1,024 bytes, intervals closed on the left): < 10 KB: 32; 10–30 KB: 64;
30–60 KB: 128; 60–100 KB: 256; 100–200 KB: 384; 200–500 KB: 512; 500 KB–1 MB: 768; >= 1 MB: 1,024. Height
`h = ceil(|b| / w)`, zero padding. Channels: grey `b/255`; entropy (windows of 256 bytes, stride 128, starts at
0, 128, ... < |b| truncated at the end of the file, Shannon entropy / 8 averaged over the windows covering each
byte); bigram `log(1 + count[b_{t-1}, b_t]) / log(1 + max count)` (first byte 0). Bilinear antialiased resize to
224 x 224; per-channel normalisation with training-split statistics. Training augmentation: entropy channel ×
U(0.95, 1.05); with probability 0.3, a U(0, 0.5) fraction of the bytes after the last section is removed (PE only).
No flips or crops.

**Pixel -> byte offsets (Eq. 3).** Byte `t` lies at raster cell `(r, c) = (floor(t / w), t mod w)`; its centre maps to
resized coordinates `y = (r + 0.5) · 224 / h − 0.5`, `x = (c + 0.5) · 224 / w − 0.5` (inverse of the
`align_corners=False` resize). The 7 × 7 Grad-CAM++ map is upsampled to 224 × 224 and sampled bilinearly at these
coordinates; byte scores are then summed per PE region (header, .text, .rdata, .data, .rsrc, imports, overlay) using
the section table (`byte_image.parse_pe`, dependency-free).

## 7. Conformal layer

Scores `s_i = 1 − p_bar(y_i | x_i)` on the calibration split; prediction set `C(x) = {y : 1 − p_bar(y|x) <= q}`;
predict iff `|C(x)| = 1`, abstain otherwise.

**Split conformal** (P-R, EMBER2024, MalNet): `q` is the k-th smallest calibration score with
`k = ceil((n + 1)(1 − α))`, `α = 0.05`; `q = +inf` if `k > n` (every label is then in the set). BODMAS:
`n = 4,297`, `k = ceil(4,298 × 0.95) = ceil(4,083.1) = 4,084`; MalNet: `n = 4,372`, `k = 4,155`.

**Weighted conformal** (P-T): with ages `a_i = τ_k − t_i` in days and half-life `h = 15`,
`w_i = 2^(−a_i / h)`, `p~_i = w_i / (Σ_j w_j + 1)`; the test point carries the remaining mass `1 / (Σ_j w_j + 1)` at
`+inf`, and

    q_k = inf{ q : Σ_i p~_i 1[s_i <= q] >= 1 − α }      (+inf if the calibration mass never reaches 1 − α).

With unit weights `Σ_{i<=j} p~_(i) = j / (n + 1) >= 1 − α` first holds at `j = ceil((n + 1)(1 − α))`, i.e. the weighted
rule reduces exactly to the split rule (tested for n = 1..400, 4,297 and 8,594).

**Effective sample size.** `n_eff = (Σ w_i)^2 / Σ w_i^2`. If the calibration samples of `D_k` arrive uniformly over
the month before `τ_k`, ages are `a ~ U(0, L)` with `L = 30` days. Writing `λ = ln 2 / h`,

    E[w]   = (1/L) ∫_0^L e^(−λa) da  = (1 − e^(−λL)) / (λL)
    E[w^2] = (1/L) ∫_0^L e^(−2λa) da = (1 − e^(−2λL)) / (2λL)

and by the law of large numbers

    n_eff / |D_k|  ->  E[w]^2 / E[w^2] = 2 (1 − e^(−λL)) / (λL (1 + e^(−λL))) = (2 / (λL)) tanh(λL / 2).

For `h = 15`, `L = 30`: `λL = 2 ln 2`, `e^(−λL) = 1/4`, so the ratio is `tanh(ln 2) / ln 2 = 0.6 / 0.6931 = 0.866`,
i.e. `n_eff ≈ 0.87 |D_k|` (0.880 for a 28-day and 0.858 for a 31-day month). The per-window `n_eff` is reported in
`temporal_sliding.csv`.

## 8. Training and evaluation

TrustFusion: AdamW (lr 3e-4, weight decay 0.05), cosine schedule over all steps, batch 128 (64 on EMBER2024), at most
80 epochs, early stopping on validation macro-F1 (deterministic head) with patience 12; the best-validation
checkpoint is used. Loss: class-balanced focal (β = 0.999, γ = 2) + 0.35 · L_cal (M = 15 bins, accuracy detached) +
0.10 · L_align. Inference: head-only MC dropout, `T = 12`.

Metrics (`trustfusion/metrics.py`): accuracy; macro-F1 over all classes present in the labels or predictions
(residual included); ROC-AUC; TPR at FPR ∈ {1e-3, 1e-2} by linear interpolation of the test ROC curve; ECE with 15
equal-width bins on the maximum probability; selective error at coverage `c` (error of the `ceil(cN)` most confident
predictions); empirical coverage, mean set size and acceptance rate of the conformal sets.

Statistics (`trustfusion/stats.py`): mean ± sample SD over seeds; paired differences over seeds with a 95%
t-interval (df = n − 1) and `scipy.stats.ttest_rel`; Holm correction over the six Table 5 comparisons; paired
bootstrap over test samples (10,000 resamples; the same resampled indices for both methods and all seeds, resampled
within windows for the P-T loss). `table5.csv` carries the manuscript columns `t_ci` (two decimals) and
`p_holm_formatted` ("< 0.001" below 0.001). Because the t-test and the t-interval use the same mean difference and
standard error, `stats.p_from_t_interval(mean, low, high, n)` recovers the t-test p from a reported interval; any p
quoted next to an interval must match it before Holm correction is applied.

## 9. Implementation choices not fixed by the specification

* Static descriptors are preprocessed with `sign(x) · log1p(|x|)` followed by per-feature standardisation fitted on
  the training split (`data.static.transform`); LightGBM uses the raw vectors.
* Co-attention FFN width is 4 × 512; the alignment projection is a shared `Linear(512, 512)` applied to the pooled
  pre-fusion encoder outputs; the alignment loss uses only samples in which both views are present.
* The image-branch Grad-CAM variants score the class with the classifier head applied to the pooled image tokens;
  the detached variant keeps the fused logit's value and back-propagates through `g · z_v` only.
* Random search draws `min(20, |grid|)` distinct configurations (the grids of SPEC §4 have at most 12 points, so the
  20-trial budget covers them completely).
* The provenance source probe uses LightGBM default parameters.
