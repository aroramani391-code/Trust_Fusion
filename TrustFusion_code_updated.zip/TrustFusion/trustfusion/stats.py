"""Seed statistics and significance testing (SPEC §5).

* mean +- SD over seeds (sample SD, ``ddof=1``)
* paired differences over seeds; 95% t-interval with ``df = n - 1``; paired t-test (``scipy.stats.ttest_rel``)
* Holm step-down correction over the six Table 5 comparisons
* paired bootstrap over test samples within each seed (10,000 resamples): the same resampled index set is used for
  both methods (and for every seed), and the resampled per-seed differences are averaged over seeds
* Table 5 formatting (``format_interval``, ``format_p``: ``"< 0.001"`` below 0.001, as in the manuscript) and
  ``p_from_t_interval``, which recovers the two-sided paired t-test p-value implied by a reported mean difference and
  95% t-interval. A paired t-test and its t-interval come from the same mean and standard error, so a reported p must
  agree with the reported interval: with five seeds, an interval that excludes zero by several half-widths implies
  p far below 0.001 (e.g. a difference of 4.0 with interval [3.5, 4.5] gives t = 22.2, p = 2e-5 before Holm
  correction), so such an interval cannot be reported with p-values of the order of 0.01.
"""
from __future__ import annotations

from typing import Callable, Mapping, Sequence

import numpy as np
from scipy import stats as sps


def mean_sd(values: Sequence[float]) -> tuple[float, float]:
    v = np.asarray(values, dtype=np.float64)
    if v.size == 0:
        return float("nan"), float("nan")
    return float(v.mean()), float(v.std(ddof=1)) if v.size > 1 else 0.0


def format_mean_sd(values: Sequence[float], scale: float = 100.0, digits: int = 2) -> str:
    m, s = mean_sd(np.asarray(values, dtype=np.float64) * scale)
    return f"{m:.{digits}f} ± {s:.{digits}f}"


def paired_ttest(a: Sequence[float], b: Sequence[float]) -> tuple[float, float]:
    res = sps.ttest_rel(np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64))
    return float(res.statistic), float(res.pvalue)


def t_interval(diffs: Sequence[float], confidence: float = 0.95) -> tuple[float, float, float]:
    d = np.asarray(diffs, dtype=np.float64)
    n = d.size
    m = float(d.mean())
    if n < 2:
        return m, float("nan"), float("nan")
    se = float(d.std(ddof=1) / np.sqrt(n))
    h = float(sps.t.ppf(0.5 + confidence / 2, df=n - 1) * se)
    return m, m - h, m + h


def p_from_t_interval(mean: float, low: float, high: float, n: int, confidence: float = 0.95) -> tuple[float, float]:
    """``(t, p)`` of the two-sided paired t-test implied by a mean difference and its t-interval over ``n`` seeds.

    ``se = half_width / t_{(1+confidence)/2, n-1}``, ``t = mean / se``; ``p = 2 (1 - F_t(|t|; n - 1))``. The result
    equals ``scipy.stats.ttest_rel`` on the underlying seed values (unadjusted; apply :func:`holm` across comparisons).
    """
    half = (float(high) - float(low)) / 2.0
    if n < 2 or half <= 0:
        return float("nan"), float("nan")
    se = half / float(sps.t.ppf(0.5 + confidence / 2, df=n - 1))
    t = float(mean) / se
    return t, float(2.0 * sps.t.sf(abs(t), df=n - 1))


def format_p(p: float, threshold: float = 0.001, digits: int = 3) -> str:
    """Manuscript style: ``"< 0.001"`` below ``threshold``, otherwise ``digits`` decimals."""
    if p is None or not np.isfinite(p):
        return ""
    return f"< {threshold:g}" if p < threshold else f"{p:.{digits}f}"


def format_interval(low: float, high: float, digits: int = 2) -> str:
    return f"[{low:.{digits}f}, {high:.{digits}f}]" if np.isfinite(low) and np.isfinite(high) else ""


def holm(pvalues: Sequence[float]) -> np.ndarray:
    """Holm–Bonferroni adjusted p-values (monotone step-down, capped at 1)."""
    p = np.asarray(pvalues, dtype=np.float64)
    m = p.size
    order = np.argsort(p, kind="stable")
    adj_sorted = np.minimum(1.0, np.maximum.accumulate((m - np.arange(m)) * p[order]))
    out = np.empty(m)
    out[order] = adj_sorted
    return out


MetricFn = Callable[[Mapping[str, np.ndarray], np.ndarray], float]


def paired_bootstrap(cols_a: Sequence[Mapping[str, np.ndarray]], cols_b: Sequence[Mapping[str, np.ndarray]],
                     metric: MetricFn, n_resamples: int = 10_000, seed: int = 2024, confidence: float = 0.95,
                     strata: np.ndarray | None = None) -> dict[str, float]:
    """Paired bootstrap of ``metric(A) - metric(B)`` averaged over seeds.

    ``cols_a[k]`` / ``cols_b[k]`` hold the per-sample arrays of seed ``k`` aligned on the same test samples;
    ``metric(cols, idx)`` evaluates a metric on the rows ``idx``. With ``strata`` (e.g. the P-T window) indices are
    resampled within each stratum.
    """
    if len(cols_a) != len(cols_b) or not cols_a:
        raise ValueError("need the same, non-zero number of seeds for both methods")
    n = len(next(iter(cols_a[0].values())))
    rng = np.random.default_rng(seed)
    full = np.arange(n)
    observed = float(np.mean([metric(a, full) - metric(b, full) for a, b in zip(cols_a, cols_b)]))
    groups = [full] if strata is None else [np.flatnonzero(strata == s) for s in np.unique(strata)]
    diffs = np.empty(n_resamples)
    for r in range(n_resamples):
        idx = np.concatenate([g[rng.integers(0, g.size, size=g.size)] for g in groups])
        diffs[r] = np.mean([metric(a, idx) - metric(b, idx) for a, b in zip(cols_a, cols_b)])
    lo, hi = np.quantile(diffs, [(1 - confidence) / 2, 1 - (1 - confidence) / 2])
    p = 2 * min((diffs <= 0).mean(), (diffs >= 0).mean())
    return {"diff": observed, "ci_low": float(lo), "ci_high": float(hi), "p_value": float(min(1.0, p)),
            "n_resamples": int(n_resamples)}
