"""Grad-CAM / Grad-CAM++ on the image encoder's layer-4 maps ``A^k`` and projection to bytes (SPEC §2, §6).

Variants (all explain the same target class, by default the deterministic fused prediction):

``gradcam_image``       Grad-CAM, class score from the image branch alone (classifier head on pooled image tokens)
``gradcampp_image``     Grad-CAM++, image branch alone
``gradcampp_detached``  Grad-CAM++ on the fused logit whose value is unchanged but whose gradient reaches ``A^k`` only
                        through the image branch: ``z_f' = z_f.detach() + g.detach() * (z_v - z_v.detach())``
                        (co-attention, gate and static stream detached)
``gradcampp_fusion``    Grad-CAM++ with the gradient of the class logit computed from ``z_f`` through co-attention
                        and gate (the manuscript's attribution)

Grad-CAM weights: ``w_k = mean_ij dY/dA^k_ij``. Grad-CAM++ (Chattopadhay et al., 2018):
``alpha^k_ij = g^2 / (2 g^2 + sum_ab A^k_ab g^3)``, ``w_k = sum_ij alpha^k_ij ReLU(g_ij)``; map ``ReLU(sum_k w_k A^k)``.
"""
from __future__ import annotations

from typing import Any, Mapping

import numpy as np
import torch
import torch.nn.functional as F

from .data.byte_image import PEInfo, project_to_bytes, region_mass

VARIANTS = ("gradcam_image", "gradcampp_image", "gradcampp_detached", "gradcampp_fusion")


def gradcam_weights(A: torch.Tensor, G: torch.Tensor) -> torch.Tensor:
    return G.mean(dim=(2, 3))


def gradcampp_weights(A: torch.Tensor, G: torch.Tensor) -> torch.Tensor:
    g2, g3 = G.pow(2), G.pow(3)
    sum_a = A.sum(dim=(2, 3), keepdim=True)
    denom = 2.0 * g2 + sum_a * g3
    denom = torch.where(denom != 0, denom, torch.ones_like(denom))
    alpha = g2 / denom
    return (alpha * F.relu(G)).sum(dim=(2, 3))


def _class_scores(model: Any, batch: Mapping[str, Any], variant: str, target: torch.Tensor | None
                  ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    enc = model.encode(batch, modality_dropout=False)
    A = enc["A"]
    if A is None:
        raise ValueError("attribution needs the image view (the image encoder produced no feature maps)")
    if variant in ("gradcam_image", "gradcampp_image"):
        logits = model.image_branch_logits(enc)
    elif variant in ("gradcampp_detached", "gradcampp_fusion"):
        fused = model.fuse(enc)
        z_f = fused["z_f"]
        if variant == "gradcampp_detached":
            g = fused["gate"] if fused["gate"] is not None else torch.ones_like(z_f[:, :1])
            z_f = z_f.detach() + g.detach() * (enc["z_v"] - enc["z_v"].detach())
        logits = model.head(z_f)
    else:
        raise ValueError(f"unknown attribution variant {variant!r}")
    if target is None:
        target = logits.argmax(dim=1)
    scores = logits.gather(1, target.view(-1, 1)).squeeze(1)
    return scores, A, logits


def compute_cam(model: Any, batch: Mapping[str, Any], variant: str = "gradcampp_fusion",
                target: torch.Tensor | None = None, normalise: bool = True) -> torch.Tensor:
    """Return ``[B, h, w]`` attribution maps (each scaled to max 1 when ``normalise``)."""
    was_training = model.training
    model.eval()
    try:
        with torch.enable_grad():
            scores, A, _ = _class_scores(model, batch, variant, target)
            (G,) = torch.autograd.grad(scores.sum(), A)
        A, G = A.detach(), G.detach()
        w = gradcam_weights(A, G) if variant == "gradcam_image" else gradcampp_weights(A, G)
        cam = F.relu((w[:, :, None, None] * A).sum(dim=1))
        if normalise:
            peak = cam.flatten(1).max(dim=1).values.clamp_min(1e-12)
            cam = cam / peak[:, None, None]
        return cam
    finally:
        model.train(was_training)


def cam_to_byte_scores(cam: torch.Tensor | np.ndarray, n_bytes: int, image_size: int = 224) -> np.ndarray:
    return project_to_bytes(np.asarray(cam.detach().cpu() if isinstance(cam, torch.Tensor) else cam, dtype=np.float32),
                            n_bytes, image_size)


def attribution_region_mass(cam: torch.Tensor | np.ndarray, n_bytes: int, info: PEInfo | None,
                            image_size: int = 224) -> dict[str, float]:
    return region_mass(cam_to_byte_scores(cam, n_bytes, image_size), info)
