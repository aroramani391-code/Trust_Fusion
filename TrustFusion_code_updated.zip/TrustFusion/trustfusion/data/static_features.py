"""Static feature layouts, preprocessing, EMBER extractor wrappers and the 48-d call-graph descriptor.

* :class:`FeatureLayout` slices a descriptor into named field groups (8 for EMBER v2 / v3, 4 for MalNet).
* :class:`StaticTransform` is fitted on the training split only (``log1p_standardize`` by default:
  ``sign(x) log1p|x|`` followed by per-feature standardisation).
* :class:`EmberFeatureExtractor` wraps the optional ``ember`` (feature version 2, requires ``lief``) and
  ``thrember`` (feature version 3, EMBER2024) packages; both are optional dependencies.
* :func:`callgraph_descriptor` computes the MalNet descriptor with ``networkx``.
"""
from __future__ import annotations

import math
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Mapping, Sequence

import numpy as np
import yaml

from ..utils import CONFIG_ROOT

LAYOUT_FILES = {
    "ember_v2": CONFIG_ROOT / "feature_layouts" / "bodmas_ember_v2.yaml",
    "bodmas_ember_v2": CONFIG_ROOT / "feature_layouts" / "bodmas_ember_v2.yaml",
    "ember_v3": CONFIG_ROOT / "feature_layouts" / "ember2024.yaml",
    "ember2024": CONFIG_ROOT / "feature_layouts" / "ember2024.yaml",
    "malnet_callgraph": CONFIG_ROOT / "feature_layouts" / "malnet_callgraph.yaml",
}


# --------------------------------------------------------------------------------------------- layouts
@dataclass
class FeatureLayout:
    name: str
    dim: int
    groups: dict[str, list[tuple[int, int]]]
    blocks: list[dict] = field(default_factory=list)

    @property
    def group_names(self) -> list[str]:
        return list(self.groups)

    def group_indices(self) -> list[np.ndarray]:
        return [np.concatenate([np.arange(s, e) for s, e in ranges]) for ranges in self.groups.values()]

    @property
    def group_dims(self) -> list[int]:
        return [int(sum(e - s for s, e in ranges)) for ranges in self.groups.values()]

    def slice_groups(self, x: np.ndarray) -> list[np.ndarray]:
        return [np.asarray(x)[..., idx] for idx in self.group_indices()]

    def validate(self) -> None:
        cover = np.zeros(self.dim, dtype=np.int64)
        for ranges in self.groups.values():
            for s, e in ranges:
                if not (0 <= s < e <= self.dim):
                    raise ValueError(f"invalid range [{s}, {e}) for dim {self.dim}")
                cover[s:e] += 1
        if not np.all(cover == 1):
            raise ValueError(f"layout {self.name}: groups must cover every column exactly once")
        if self.blocks:
            if sum(int(b["dim"]) for b in self.blocks) != self.dim:
                raise ValueError(f"layout {self.name}: block dims do not sum to {self.dim}")

    def to_dict(self) -> dict:
        return {"name": self.name, "dim": self.dim, "groups": {k: [list(r) for r in v] for k, v in self.groups.items()}}

    @staticmethod
    def from_dict(d: Mapping) -> "FeatureLayout":
        groups = {k: [tuple(int(x) for x in r) for r in v] for k, v in d["groups"].items()}
        layout = FeatureLayout(name=str(d["name"]), dim=int(d["dim"]), groups=groups, blocks=list(d.get("blocks", [])))
        layout.validate()
        return layout


def load_layout(path_or_name: str | os.PathLike) -> FeatureLayout:
    p = Path(path_or_name)
    if not p.exists():
        if str(path_or_name) in LAYOUT_FILES:
            p = LAYOUT_FILES[str(path_or_name)]
        elif (CONFIG_ROOT.parent / p).exists():
            p = CONFIG_ROOT.parent / p
        else:
            raise FileNotFoundError(f"feature layout {path_or_name!r} not found")
    with open(p, "r", encoding="utf8") as f:
        return FeatureLayout.from_dict(yaml.safe_load(f))


def ember2024_layout(path: str | os.PathLike | None = None) -> FeatureLayout:
    """EMBER2024 layout from YAML; if ``thrember`` is installed its block dimensions are asserted to match."""
    layout = load_layout(path or LAYOUT_FILES["ember2024"])
    try:
        import thrember  # type: ignore
    except ImportError:
        return layout
    extractor = thrember.PEFeatureExtractor()
    derived = [(fe.name, int(fe.dim)) for fe in extractor.features]
    listed = [(b["name"], int(b["dim"])) for b in layout.blocks]
    if derived != listed:
        raise AssertionError(f"thrember feature blocks {derived} differ from configs/feature_layouts/ember2024.yaml {listed}")
    return layout


def synthetic_layout(dim: int = 64, n_groups: int = 8) -> FeatureLayout:
    """Small contiguous layout for unit tests."""
    edges = np.linspace(0, dim, n_groups + 1).astype(int)
    groups = {f"group{i}": [(int(edges[i]), int(edges[i + 1]))] for i in range(n_groups)}
    return FeatureLayout(name=f"synthetic{dim}", dim=dim, groups=groups)


# --------------------------------------------------------------------------------------------- transform
@dataclass
class StaticTransform:
    """Column-wise preprocessing fitted on the training split only."""

    kind: str = "log1p_standardize"  # none | standardize | log1p_standardize
    mean: np.ndarray | None = None
    std: np.ndarray | None = None

    def _pre(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, dtype=np.float64)
        x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
        if self.kind == "log1p_standardize":
            x = np.sign(x) * np.log1p(np.abs(x))
        return x

    def fit(self, X: np.ndarray, rows: np.ndarray | None = None, chunk: int = 8192) -> "StaticTransform":
        if self.kind == "none":
            return self
        rows = np.arange(X.shape[0]) if rows is None else np.sort(np.asarray(rows))
        s = np.zeros(X.shape[1])
        sq = np.zeros(X.shape[1])
        for i in range(0, rows.size, chunk):
            xb = self._pre(X[rows[i:i + chunk]])
            s += xb.sum(0)
            sq += (xb ** 2).sum(0)
        n = max(rows.size, 1)
        self.mean = s / n
        self.std = np.sqrt(np.clip(sq / n - self.mean ** 2, 0, None))
        self.std[self.std < 1e-8] = 1.0
        return self

    def transform(self, x: np.ndarray) -> np.ndarray:
        if self.kind == "none":
            return np.nan_to_num(np.asarray(x, dtype=np.float32))
        if self.mean is None:
            raise RuntimeError("StaticTransform used before fit()")
        return ((self._pre(x) - self.mean) / self.std).astype(np.float32)

    def state(self) -> dict:
        return {"kind": self.kind,
                "mean": None if self.mean is None else self.mean.tolist(),
                "std": None if self.std is None else self.std.tolist()}

    @staticmethod
    def from_state(d: Mapping) -> "StaticTransform":
        return StaticTransform(kind=d["kind"],
                               mean=None if d.get("mean") is None else np.asarray(d["mean"], dtype=np.float64),
                               std=None if d.get("std") is None else np.asarray(d["std"], dtype=np.float64))


# --------------------------------------------------------------------------------------------- extractors
class EmberFeatureExtractor:
    """Wrapper around the optional EMBER extractors.

    ``version='ember_v2'`` uses ``ember.features.PEFeatureExtractor(feature_version=2)`` (2,381-d; needs the
    ``ember`` package and ``lief``), ``version='ember_v3'`` uses ``thrember.PEFeatureExtractor`` (2,568-d; needs
    ``thrember`` and ``pefile``). ``__call__`` returns ``None`` when extraction fails, which callers map to
    the static-view mask token.
    """

    def __init__(self, version: str = "ember_v2"):
        self.version = version
        if version == "ember_v2":
            try:
                import ember  # type: ignore
            except ImportError as exc:  # pragma: no cover - optional dependency
                raise ImportError("EMBER v2 extraction needs the optional `ember` package (github.com/elastic/ember) "
                                  "and `lief`; install them or supply precomputed vectors") from exc
            self._impl = ember.features.PEFeatureExtractor(feature_version=2)
            self.dim = 2381
        elif version == "ember_v3":
            try:
                import thrember  # type: ignore
            except ImportError as exc:  # pragma: no cover - optional dependency
                raise ImportError("EMBER2024 extraction needs the optional `thrember` package "
                                  "(pip install git+https://github.com/FutureComputing4AI/EMBER2024)") from exc
            self._impl = thrember.PEFeatureExtractor()
            self.dim = int(self._impl.dim)
        else:
            raise ValueError(f"unknown extractor version {version!r}")

    def __call__(self, data: bytes | np.ndarray) -> np.ndarray | None:
        raw = bytes(np.asarray(data, dtype=np.uint8)) if isinstance(data, np.ndarray) else bytes(data)
        try:
            return np.asarray(self._impl.feature_vector(raw), dtype=np.float32)
        except Exception:  # noqa: BLE001 - any parser failure -> masked static view
            return None


def histogram_extractor(layout: FeatureLayout) -> Callable[[bytes | np.ndarray], np.ndarray | None]:
    """TEST-ONLY extractor: fills the byte-histogram group with normalised byte counts and zeros elsewhere.

    It lets the ``coupled`` faithfulness protocol run on synthetic data without ``ember``/``lief``; it is not
    a substitute for the EMBER extractor on real corpora.
    """
    hist_idx = layout.group_indices()[0]

    def _extract(data: bytes | np.ndarray) -> np.ndarray | None:
        arr = np.frombuffer(bytes(data), dtype=np.uint8) if not isinstance(data, np.ndarray) else data.astype(np.uint8)
        vec = np.zeros(layout.dim, dtype=np.float32)
        if arr.size == 0:
            return None
        counts = np.bincount(arr, minlength=256).astype(np.float32) / arr.size
        k = min(hist_idx.size, 256)
        vec[hist_idx[:k]] = counts[:k]
        return vec

    return _extract


# --------------------------------------------------------------------------------------------- call graphs
def read_edgelist(path: str | os.PathLike):
    """Read a MalNet-Graph ``.edgelist`` file (``src dst`` per line, ``#`` comments) as a DiGraph."""
    import networkx as nx

    G = nx.DiGraph()
    with open(path, "r", encoding="utf8", errors="replace") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                G.add_edge(parts[0], parts[1])
    return G


def _gini(x: np.ndarray) -> float:
    x = np.sort(np.asarray(x, dtype=np.float64))
    if x.size == 0 or x.sum() == 0:
        return 0.0
    n = x.size
    cum = np.cumsum(x)
    return float((n + 1 - 2 * (cum / cum[-1]).sum()) / n)


def _safe(v: float) -> float:
    return float(v) if v is not None and np.isfinite(v) else 0.0


DEGREE_BINS = (0, 1, 2, 3, 4, 5, 7, 10, 15, 25, 50, 100)


def callgraph_descriptor(G) -> np.ndarray:
    """48-d descriptor: size/connectivity, degree statistics, degree histogram, local structure (12 each)."""
    import networkx as nx

    out = np.zeros(48, dtype=np.float32)
    n = G.number_of_nodes()
    if n == 0:
        return out
    if not G.is_directed():
        G = G.to_directed()
    m = G.number_of_edges()
    nodes = list(G.nodes())
    indeg = np.array([d for _, d in G.in_degree(nodes)], dtype=np.float64)
    outdeg = np.array([d for _, d in G.out_degree(nodes)], dtype=np.float64)
    U = nx.Graph(G)
    U.remove_edges_from(list(nx.selfloop_edges(U)))
    tot = np.array([d for _, d in U.degree(nodes)], dtype=np.float64)

    wcc = list(nx.weakly_connected_components(G))
    scc_sizes = [len(c) for c in nx.strongly_connected_components(G)]
    largest_wcc = max(wcc, key=len)
    try:
        diam = nx.approximation.diameter(U.subgraph(largest_wcc)) if len(largest_wcc) > 1 else 0
    except Exception:  # noqa: BLE001
        diam = 0
    size_conn = [
        math.log1p(n), math.log1p(m), nx.density(G), m / n,
        len(wcc) / n, len(largest_wcc) / n, len(scc_sizes) / n, max(scc_sizes) / n,
        nx.number_of_selfloops(G) / max(m, 1), sum(1 for d in tot if d == 0) / n,
        math.log1p(diam), float(len(wcc) == 1),
    ]

    def skew(x: np.ndarray) -> float:
        sd = x.std()
        return float(((x - x.mean()) ** 3).mean() / sd ** 3) if sd > 0 else 0.0

    deg_stats = [
        indeg.mean(), indeg.std(), math.log1p(indeg.max()), float(np.median(indeg)),
        outdeg.mean(), outdeg.std(), math.log1p(outdeg.max()), float(np.median(outdeg)),
        tot.std(), skew(tot), _gini(tot), float(np.mean(tot == 1)),
    ]

    edges = np.array(list(DEGREE_BINS) + [np.inf])
    hist = np.histogram(tot, bins=edges)[0] / n

    core = nx.core_number(U) if U.number_of_edges() > 0 else {v: 0 for v in U.nodes()}
    core_vals = np.array(list(core.values()), dtype=np.float64)
    triangles = sum(nx.triangles(U).values()) / 3.0
    try:
        pr = np.array(list(nx.pagerank(G, max_iter=200, tol=1e-6).values()))
    except Exception:  # noqa: BLE001 - convergence failure on pathological graphs
        pr = np.full(n, 1.0 / n)
    pr_ent = -(pr[pr > 0] * np.log(pr[pr > 0])).sum() / math.log(n) if n > 1 else 0.0
    with np.errstate(all="ignore"):
        try:
            assort = nx.degree_assortativity_coefficient(U) if U.number_of_edges() > 1 else 0.0
        except Exception:  # noqa: BLE001
            assort = 0.0
    recip_nodes = sum(1 for u, v in G.edges() if u != v and G.has_edge(v, u))
    bidir_nodes = len({u for u, v in G.edges() if u != v and G.has_edge(v, u)})
    local = [
        nx.average_clustering(U), nx.transitivity(U), recip_nodes / max(m, 1), assort,
        float(np.mean((indeg == 0) & (outdeg > 0))), float(np.mean((outdeg == 0) & (indeg > 0))),
        math.log1p(core_vals.max() if core_vals.size else 0), float(core_vals.mean() if core_vals.size else 0),
        triangles / n, float(pr.max()), pr_ent, bidir_nodes / n,
    ]
    out[:] = np.array([_safe(v) for v in size_conn + deg_stats + list(hist) + local], dtype=np.float32)
    return out


def descriptor_from_edgelist(path: str | os.PathLike) -> np.ndarray:
    return callgraph_descriptor(read_edgelist(path))


def remove_masked_methods(G, method_ranges: Mapping[str, Sequence[tuple[int, int]]], masked: np.ndarray):
    """Remove call-graph nodes whose code lies (partly) in masked byte positions.

    ``method_ranges`` maps node name -> list of ``[start, end)`` byte ranges of its code in the DEX file (e.g.
    obtained with the optional ``androguard`` package); ``masked`` is a boolean mask over file bytes.
    """
    H = G.copy()
    cum = np.concatenate([[0], np.cumsum(masked.astype(np.int64))])
    drop = [node for node, ranges in method_ranges.items()
            if node in H and any(cum[min(e, masked.size)] - cum[min(s, masked.size)] > 0 for s, e in ranges)]
    H.remove_nodes_from(drop)
    return H
