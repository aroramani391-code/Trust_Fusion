import networkx as nx
import numpy as np
import pytest

from trustfusion.data.datasets import local_degree_profile, read_edge_index
from trustfusion.data.static_features import (StaticTransform, callgraph_descriptor, descriptor_from_edgelist,
                                              ember2024_layout, histogram_extractor, load_layout, remove_masked_methods)

EIGHT_GROUPS = ["byte_histogram", "byte_entropy_histogram", "strings", "general", "header", "sections",
                "imports_exports", "data_directories"]


def test_ember_v2_layout_slices_sum_to_2381():
    lay = load_layout("configs/feature_layouts/bodmas_ember_v2.yaml")
    assert lay.dim == 2381
    assert lay.group_names == EIGHT_GROUPS
    assert lay.group_dims == [256, 256, 104, 10, 62, 255, 1280 + 128, 30]
    assert sum(lay.group_dims) == 2381
    x = np.arange(2381)
    parts = lay.slice_groups(x)
    np.testing.assert_array_equal(np.sort(np.concatenate(parts)), x)
    np.testing.assert_array_equal(parts[6], np.arange(943, 2351))


def test_ember2024_layout():
    lay = ember2024_layout()
    assert lay.dim == 2568 and lay.group_names == EIGHT_GROUPS
    assert sum(lay.group_dims) == 2568
    assert sum(int(b["dim"]) for b in lay.blocks) == 2568
    np.testing.assert_array_equal(np.sort(np.concatenate(lay.slice_groups(np.arange(2568)))), np.arange(2568))


def test_malnet_layout():
    lay = load_layout("malnet_callgraph")
    assert lay.dim == 48 and lay.group_dims == [12, 12, 12, 12]


def test_callgraph_descriptor():
    G = nx.gnp_random_graph(60, 0.08, seed=1, directed=True)
    G.add_edge(3, 3)
    d = callgraph_descriptor(G)
    assert d.shape == (48,) and np.all(np.isfinite(d))
    assert d[24:36].sum() == pytest.approx(1.0, abs=1e-5)  # degree histogram group sums to 1
    assert np.all(callgraph_descriptor(nx.DiGraph()) == 0)


def test_edgelist_roundtrip(tmp_path):
    p = tmp_path / "g.edgelist"
    p.write_text("# Directed graph\n# comment\na b\nb c\nc a\nc d\n")
    d = descriptor_from_edgelist(p)
    assert d.shape == (48,)
    e, n = read_edge_index(p)
    assert e.shape == (2, 4) and n == 4
    ldp = local_degree_profile(e, n)
    assert ldp.shape == (4, 5) and np.all(np.isfinite(ldp))


def test_remove_masked_methods():
    G = nx.DiGraph([("m1", "m2"), ("m2", "m3")])
    masked = np.zeros(100, bool)
    masked[10:20] = True
    H = remove_masked_methods(G, {"m1": [(0, 5)], "m2": [(15, 30)], "m3": [(50, 60)]}, masked)
    assert set(H.nodes) == {"m1", "m3"}


def test_static_transform_fit_on_rows():
    rng = np.random.default_rng(0)
    X = rng.lognormal(3, 2, size=(500, 10)).astype(np.float32)
    rows = np.arange(0, 500, 2)
    st = StaticTransform("log1p_standardize").fit(X, rows)
    Z = st.transform(X[rows])
    np.testing.assert_allclose(Z.mean(0), 0, atol=1e-4)
    np.testing.assert_allclose(Z.std(0), 1, atol=1e-3)
    st2 = StaticTransform.from_state(st.state())
    np.testing.assert_allclose(st2.transform(X[:5]), st.transform(X[:5]))


def test_histogram_extractor():
    lay = load_layout("bodmas_ember_v2")
    vec = histogram_extractor(lay)(np.arange(256, dtype=np.uint8))
    assert vec.shape == (2381,) and vec[:256].sum() == pytest.approx(1.0)
