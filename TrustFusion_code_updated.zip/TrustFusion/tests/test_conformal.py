import math

import numpy as np
import pytest

from trustfusion import conformal as C


def test_k_rule_bodmas_calibration_size():
    assert C.split_conformal_k(4297, 0.05) == 4084
    scores = np.random.default_rng(0).random(4297)
    assert C.split_conformal_quantile(scores, 0.05) == np.sort(scores)[4083]


@pytest.mark.parametrize("n,alpha,k", [(19, 0.05, 19), (99, 0.1, 90), (8594, 0.05, 8166), (4372, 0.05, 4155)])
def test_k_rule_exact(n, alpha, k):
    assert C.split_conformal_k(n, alpha) == k == math.ceil(round((n + 1) * (1 - alpha), 9))


def test_infinite_threshold_when_k_exceeds_n():
    assert C.split_conformal_k(10, 0.05) == 11
    assert C.split_conformal_quantile(np.random.rand(10), 0.05) == float("inf")
    assert C.split_conformal_quantile(np.array([]), 0.05) == float("inf")
    assert np.all(C.prediction_sets(np.random.dirichlet(np.ones(4), 5), float("inf")))


def test_weighted_equals_split_with_unit_weights():
    rng = np.random.default_rng(1)
    for alpha in (0.05, 0.1, 0.2):
        for n in list(range(1, 400)) + [4297, 8594]:
            s = rng.random(n)
            assert C.weighted_conformal_quantile(s, np.ones(n), alpha) == C.split_conformal_quantile(s, alpha)
        s = np.round(rng.random(300), 2)  # ties
        assert C.weighted_conformal_quantile(s, np.ones(300), alpha) == C.split_conformal_quantile(s, alpha)


def test_weighted_unattainable_is_infinite():
    s = np.random.rand(30)
    w = np.full(30, 0.1)  # sum w = 3 -> the test point carries mass 1/4 > alpha
    assert C.weighted_conformal_quantile(s, w, 0.05) == float("inf")


def test_decay_weights_half_life():
    w = C.decay_weights(np.array([100.0, 85.0, 70.0]), 100.0, 15.0)
    np.testing.assert_allclose(w, [1.0, 0.5, 0.25])
    with pytest.raises(ValueError):
        C.decay_weights(np.array([101.0]), 100.0)


def test_n_eff_uniform_month_is_0866_n():
    h, span = 15.0, 30.0
    ew = h / (span * math.log(2)) * (1 - 2 ** (-span / h))
    ew2 = h / (2 * span * math.log(2)) * (1 - 2 ** (-2 * span / h))
    assert ew ** 2 / ew2 == pytest.approx(0.866, abs=5e-4)
    rng = np.random.default_rng(0)
    n = 200_000
    ages = rng.uniform(0, span, size=n)
    w = C.decay_weights(-ages, 0.0, h)
    assert C.effective_sample_size(w) / n == pytest.approx(0.866, abs=0.003)
    assert C.effective_sample_size(np.ones(50)) == pytest.approx(50)


def test_split_conformal_marginal_coverage():
    rng = np.random.default_rng(0)
    covs = []
    for _ in range(200):
        p = rng.dirichlet(np.ones(5) * 0.7, size=600)
        y = np.array([rng.choice(5, p=row) for row in p])  # calibrated synthetic model
        res = C.calibrate_split(p[:300], y[:300], 0.1)
        sets = C.prediction_sets(p[300:], res.qhat)
        covs.append(C.summarize_sets(sets, y[300:])["coverage"])
    assert np.mean(covs) >= 0.9 - 0.01


def test_temperature_scaling_recovers_temperature():
    rng = np.random.default_rng(0)
    logits = rng.normal(0, 3, size=(4000, 6))
    p_true = C.apply_temperature(logits, 2.0)
    y = np.array([rng.choice(6, p=row) for row in p_true])
    assert C.fit_temperature(logits, y) == pytest.approx(2.0, rel=0.1)
