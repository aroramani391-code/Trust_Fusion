#!/usr/bin/env python
"""Fit the split-conformal threshold (alpha = 0.05) on the calibration split of one or more runs.

Writes ``<run>/calibration.json`` with ``qhat``, ``k = ceil((n+1)(1-alpha))``, ``n`` and the head used. With
``--temperature`` a temperature is fitted on the calibration split first (Fig. 4 "+ temperature scaling"; use a
separate ``--name``). For the P-T protocol use scripts/run_temporal.py instead (weighted, per-window thresholds).

Examples::

    python scripts/calibrate.py --run runs/bodmas/pr_family/trustfusion            # every seed directory
    python scripts/calibrate.py --run runs/bodmas/pr_family/cross_attention --temperature --name calibration_ts
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from trustfusion.cli import run_dirs  # noqa: E402
from trustfusion.evaluation import calibrate_run  # noqa: E402
from trustfusion.utils import CONFIG_ROOT, get_logger, load_config  # noqa: E402

log = get_logger("calibrate")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", nargs="+", required=True, help="run directories (seed<k>) or their method directory")
    ap.add_argument("--alpha", type=float, default=None, help="default: configs/base.yaml conformal.alpha (0.05)")
    ap.add_argument("--head", choices=["mc", "det"], default="mc")
    ap.add_argument("--temperature", action="store_true")
    ap.add_argument("--name", default="calibration")
    args = ap.parse_args()
    alpha = args.alpha if args.alpha is not None else float(load_config(CONFIG_ROOT / "base.yaml")["conformal"]["alpha"])
    for run in run_dirs(args.run):
        res = calibrate_run(run, alpha=alpha, head=args.head, temperature=args.temperature, name=args.name)
        log.info("%s: %s", run, res)


if __name__ == "__main__":
    main()
