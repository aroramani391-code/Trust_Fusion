#!/usr/bin/env python
"""P-T chronological deployment over W1..W7 with a frozen model (Fig. 6, Table 8 P-T cells).

Reads ``inference/cal.npz`` (D1) and ``inference/test.npz`` (W1..W7) of a ``pt_family`` run and writes
* ``predictions.parquet`` + ``temporal_sliding.csv``: weighted sliding-window conformal (h = 15 days)
* ``predictions_static.parquet`` + ``temporal_static.csv``: static D1 split-conformal threshold
* ``probs.npz`` (test windows) and ``calibration_windows_<mode>.json`` (pool and size used for every window)
Per-window rows contain macro-F1, accuracy, ECE, coverage, mean set size, acceptance, q_hat, |D_k| and n_eff.

Examples::

    python scripts/run_temporal.py --run runs/bodmas/pt_family/trustfusion --mode both
    python scripts/run_temporal.py --run runs/bodmas/pt_family/trustfusion --label-delay-months 1 --suffix delay1
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402

from trustfusion.cli import run_dirs  # noqa: E402
from trustfusion.data.splits import DEFAULT_PT, pt_window_bounds  # noqa: E402
from trustfusion.evaluation import run_config, select_probs  # noqa: E402
from trustfusion.io import prediction_frame, write_json, write_predictions, write_probs  # noqa: E402
from trustfusion.temporal import run_deployment  # noqa: E402
from trustfusion.training import load_inference  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("run_temporal")
KEYS = ("sample_id", "label", "window", "timestamp", "benign_source", "p_bar", "p_det", "entropy", "mutual_info", "gate")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", nargs="+", required=True)
    ap.add_argument("--mode", choices=["sliding", "static", "both"], default="both")
    ap.add_argument("--head", choices=["mc", "det"], default="mc")
    ap.add_argument("--label-delay-months", type=int, default=None, help="default: config pt.label_delay_months (0)")
    ap.add_argument("--alpha", type=float, default=None)
    ap.add_argument("--method-name", default=None, help="write into a sibling method directory")
    ap.add_argument("--suffix", default="", help="suffix appended to every output file name")
    args = ap.parse_args()
    sfx = f"_{args.suffix}" if args.suffix else ""

    for run in run_dirs(args.run):
        cfg = run_config(run)
        pt = dict(DEFAULT_PT, **cfg.get("pt", {}))
        bounds = pt_window_bounds(pt)
        alpha = args.alpha if args.alpha is not None else float(cfg.get("conformal", {}).get("alpha", 0.05))
        h = float(cfg.get("conformal", {}).get("half_life_days", 15))
        delay = int(args.label_delay_months if args.label_delay_months is not None else pt.get("label_delay_months", 0))
        cal, test = load_inference(run, "cal"), load_inference(run, "test")
        if set(np.unique(cal["window"]).tolist()) != {"D1"}:
            raise SystemExit(f"{run}: the calibration split must be D1 only (is this a pt_family run?)")
        arr = {k: np.concatenate([cal[k], test[k]]) for k in KEYS}
        p = select_probs(arr, args.head)
        out = run.parent.parent / args.method_name / run.name if args.method_name else run
        out.mkdir(parents=True, exist_ok=True)
        method = args.method_name or run.parent.name
        seed = int(run.name.replace("seed", ""))
        for i, mode in enumerate(["sliding", "static"] if args.mode == "both" else [args.mode]):
            res = run_deployment(p, arr["label"], arr["timestamp"], arr["window"], bounds, alpha=alpha, half_life_days=h,
                                 mode=mode, label_delay_months=delay)
            res.windows.assign(method=method, seed=seed, head=args.head).to_csv(out / f"temporal_{mode}{sfx}.csv", index=False)
            idx = res.samples["index"].to_numpy()
            n, y, pi = idx.size, arr["label"][idx], p[idx]
            df = prediction_frame(
                n, sample_id=arr["sample_id"][idx], corpus=cfg.get("corpus"), task=cfg.get("task", "family"),
                protocol=cfg.get("protocol"), split="test", window=res.samples["window"].to_numpy(), seed=seed, method=method,
                y_true=y, y_pred=res.samples["y_pred"].to_numpy(), p_max=pi.max(1), p_true=pi[np.arange(n), y],
                entropy=-(pi * np.log(np.clip(pi, 1e-12, None))).sum(1) if args.head == "det" else arr["entropy"][idx],
                mutual_info=np.zeros(n) if args.head == "det" else arr["mutual_info"][idx], gate=arr["gate"][idx],
                set_size=res.samples["set_size"].to_numpy(), in_set=res.samples["in_set"].to_numpy(),
                accepted=res.samples["accepted"].to_numpy(), benign_source=arr["benign_source"][idx],
                timestamp=arr["timestamp"][idx])
            write_predictions(df, out, name=("predictions" if mode == "sliding" else "predictions_static") + sfx)
            if i == 0:
                write_probs(out, pi, arr["sample_id"][idx], name=f"probs{sfx}")
            write_json(out / f"calibration_windows_{mode}{sfx}.json",
                       {w: {"pool": str(np.unique(arr["window"][v])[0]) if v.size else None, "n": int(v.size)}
                        for w, v in res.calibration_indices.items()})
            log.info("%s [%s]\n%s", out, mode, res.windows[["window", "calibration_pool", "n_cal", "n_eff", "qhat",
                                                              "macro_f1", "coverage", "acceptance"]].to_string(index=False))


if __name__ == "__main__":
    main()
