"""Common classifier interface with head-only Monte-Carlo dropout."""
from __future__ import annotations

from typing import Any, Mapping

import torch
import torch.nn as nn
import torch.nn.functional as F


def predictive_summary(probs: torch.Tensor, eps: float = 1e-12) -> dict[str, torch.Tensor]:
    """``probs [T, B, C]`` -> mean ``p_bar``, predictive entropy ``H[p_bar]`` and mutual information ``I``."""
    p_bar = probs.mean(0)
    entropy = -(p_bar * torch.log(p_bar.clamp_min(eps))).sum(-1)
    expected = -(probs * torch.log(probs.clamp_min(eps))).sum(-1).mean(0)
    return {"p_bar": p_bar, "entropy": entropy, "mutual_info": (entropy - expected).clamp_min(0.0)}


class ClassifierBase(nn.Module):
    """Subclasses implement :meth:`features` (-> dict with ``z``) and own ``self.head`` / ``self.head_dropout``.

    Only ``self.head_dropout`` is stochastic at inference: :meth:`mc_predict` computes the representation
    ``z`` once in eval mode and draws ``T`` dropout masks for the head.
    """

    head: nn.Module
    head_dropout_p: float = 0.0

    def features(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:  # pragma: no cover - abstract
        raise NotImplementedError

    def head_logits(self, z: torch.Tensor, stochastic: bool) -> torch.Tensor:
        if stochastic and self.head_dropout_p > 0:
            z = F.dropout(z, p=self.head_dropout_p, training=True)
        return self.head(z)

    def forward(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:
        out = self.features(batch)
        out["logits"] = self.head_logits(out["z"], stochastic=self.training)
        return out

    def compute_loss(self, batch: Mapping[str, Any], out: Mapping[str, torch.Tensor], criterion: nn.Module
                     ) -> tuple[torch.Tensor, dict[str, float]]:
        return criterion(out["logits"], batch["label"])

    @torch.no_grad()
    def mc_predict(self, batch: Mapping[str, Any], T: int = 12, mc: bool = True) -> dict[str, torch.Tensor]:
        """Return ``probs [T,B,C]``, ``p_bar``, ``entropy``, ``mutual_info``, ``p_det`` and ``gate``.

        ``mc=False`` (or ``T=1``) disables the head dropout (deterministic head, mutual information 0).
        """
        was_training = self.training
        self.eval()
        try:
            feats = self.features(batch)
            z = feats["z"]
            logits_det = self.head_logits(z, stochastic=False)
            p_det = F.softmax(logits_det, dim=-1)
            if mc and T > 1 and self.head_dropout_p > 0:
                logits = torch.stack([self.head_logits(z, stochastic=True) for _ in range(T)])
                probs = F.softmax(logits, dim=-1)
            else:
                probs = p_det[None]
            out = predictive_summary(probs)
            out.update(probs=probs, p_det=p_det, z=z)
            gate = feats.get("gate")
            out["gate"] = gate.reshape(-1) if gate is not None else torch.full((z.shape[0],), float("nan"))
            return out
        finally:
            self.train(was_training)
