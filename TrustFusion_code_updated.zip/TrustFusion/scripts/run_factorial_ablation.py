#!/usr/bin/env python
"""Reliability factorial (Table 8): {L_cal on/off} x {MC head on/off}, all with the same split-conformal layer.

P-R cells (BODMAS ``pr_family``): calibrate with the cell's head, evaluate into
``runs/bodmas/pr_family/trustfusion__factorial__<cell>/seed<k>`` -> ECE, error at 80% coverage, coverage, set size.
P-T cells (BODMAS ``pt_family``): deployment loop with the cell's head -> W7 coverage with the static D1 threshold
and with the weighted sliding window.

Trained runs needed per seed (``--train-missing`` trains them): ``trustfusion`` and ``trustfusion__no_lcal`` for both
``pr_family`` and ``pt_family``.

Example::

    python scripts/run_factorial_ablation.py --seeds 0 1 2 3 4 --train-missing
"""
from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from trustfusion.aggregate import load_columns, metric_value  # noqa: E402
from trustfusion.io import run_dir  # noqa: E402
from trustfusion.utils import get_logger, load_config  # noqa: E402

log = get_logger("run_factorial_ablation")
PY = sys.executable
BASE_CONFIGS = {"pr_family": "configs/trustfusion/bodmas_pr.yaml", "pt_family": "configs/trustfusion/bodmas_pt.yaml"}


def run(cmd: list[str], dry: bool) -> None:
    print("$ " + " ".join(shlex.quote(c) for c in cmd), flush=True)
    if not dry:
        subprocess.run(cmd, check=True)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="configs/ablation/factorial.yaml")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--splits", default="splits")
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--results", default="results")
    ap.add_argument("--overlay", action="append", default=[])
    ap.add_argument("--device", default=None)
    ap.add_argument("--train-missing", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    cfg = load_config(args.config)
    corpus = cfg["corpus"]
    common = ["--splits", args.splits, "--runs", args.runs] + (["--data-root", args.data_root] if args.data_root else []) \
        + sum((["--overlay", o] for o in args.overlay), []) + (["--device", args.device] if args.device else [])
    pr, pt = cfg["pr"]["protocol"], cfg["pt"]["protocol"]
    rows = []
    for s in args.seeds:
        for key, method in cfg["training_runs"].items():
            for protocol in (pr, pt):
                rd = run_dir(args.runs, corpus, protocol, method, s)
                if not (rd / "best.pt").exists():
                    if not args.train_missing:
                        raise SystemExit(f"missing trained run {rd} (use --train-missing)")
                    sets = sum((["--set", f"{k}={v}"] for k, v in (cfg.get("train_overrides", {}).get(key) or {}).items()), [])
                    run([PY, "scripts/train.py", "--config", BASE_CONFIGS[protocol], "--protocol", protocol, "--seeds", str(s),
                         "--method-name", method] + common + sets, args.dry_run)
        for cell in cfg["cells"]:
            name = f"trustfusion__factorial__{cell['name']}"
            src_pr = run_dir(args.runs, corpus, pr, cfg["training_runs"][cell["run"]], s)
            run([PY, "scripts/calibrate.py", "--run", str(src_pr), "--head", cell["head"], "--name", f"calibration_{cell['head']}"], args.dry_run)
            run([PY, "scripts/evaluate.py", "--run", str(src_pr), "--head", cell["head"], "--calibration-name",
                 f"calibration_{cell['head']}", "--method-name", name], args.dry_run)
            src_pt = run_dir(args.runs, corpus, pt, cfg["training_runs"][cell["run"]], s)
            run([PY, "scripts/run_temporal.py", "--run", str(src_pt), "--mode", "both", "--head", cell["head"], "--method-name", name],
                args.dry_run)
            if args.dry_run:
                continue
            cols = load_columns(run_dir(args.runs, corpus, pr, name, s))
            row = {"cell": cell["name"], "lcal": cell["run"], "head": cell["head"], "seed": s}
            row.update({m: metric_value(m, cols) for m in cfg["pr"]["metrics"]})
            for mode in cfg["pt"]["modes"]:
                t = pd.read_csv(run_dir(args.runs, corpus, pt, name, s) / f"temporal_{mode}.csv")
                row[f"{cfg['pt']['window']}_coverage_{mode}"] = float(t.loc[t["window"] == cfg["pt"]["window"], "coverage"].iloc[0])
            rows.append(row)
    if not args.dry_run:
        out = Path(args.results) / "ablation" / "factorial_per_seed.csv"
        out.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(rows).to_csv(out, index=False)
        log.info("wrote %s", out)


if __name__ == "__main__":
    main()
