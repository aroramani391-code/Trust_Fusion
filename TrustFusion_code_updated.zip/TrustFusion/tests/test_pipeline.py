"""Tiny SYNTHETIC integration test: corpus -> splits -> TrustFusion training -> inference -> conformal -> evaluation."""
import numpy as np
import pandas as pd

from trustfusion.data import splits as S
from trustfusion.data.datasets import PairedViewDataset, load_corpus, make_synthetic_corpus
from trustfusion.evaluation import calibrate_run, evaluate_run
from trustfusion.io import read_json, read_predictions
from trustfusion.training import build_context, infer_torch, load_inference, train_torch
from trustfusion.utils import CONFIG_ROOT, load_config

TINY = CONFIG_ROOT.parent / "tests" / "configs" / "tiny.yaml"


def test_end_to_end_synthetic(tmp_path):
    corpus_dir = make_synthetic_corpus(tmp_path / "processed" / "bodmas", seed=1, n_families=3, per_family=(14, 16),
                                       n_rare_families=3, n_benign_per_source=6, size_range=(2500, 9000))
    corpus = load_corpus(corpus_dir)
    df, classes, _ = S.bodmas_pr_family(corpus.meta, min_family_size=5)
    S.write_split(df, classes, tmp_path / "splits", "bodmas", "pr_family")

    cfg = load_config(CONFIG_ROOT / "trustfusion" / "bodmas_pr.yaml", overlays=[TINY])
    ctx = build_context(cfg, tmp_path / "processed", tmp_path / "splits", tmp_path / "runs", seed=0)
    ds = PairedViewDataset(ctx.corpus, ctx.rows("train"), cfg["data"], train=True)
    item = ds[0]
    assert tuple(item["image"].shape) == (3, 32, 32) and item["static"].shape[0] == 2381

    info = train_torch(ctx)
    assert (ctx.run_dir / "best.pt").exists() and info["epochs_run"] == 1
    infer_torch(ctx.run_dir, tmp_path / "processed", tmp_path / "splits", device="cpu")
    test = load_inference(ctx.run_dir, "test")
    assert test["p_bar"].shape == (int((df["split"] == "test").sum()), len(classes))
    assert int(test["T"]) == 12 and bool(test["mc"])

    cal = calibrate_run(ctx.run_dir, alpha=0.05)
    assert cal["k"] == int(np.ceil((cal["n"] + 1) * 0.95 - 1e-9))
    metrics = evaluate_run(ctx.run_dir)
    assert 0 <= metrics["macro_f1"] <= 1 and 0 <= metrics["coverage"] <= 1
    pred = read_predictions(ctx.run_dir)
    assert len(pred) == len(test["label"]) and set(pred["method"]) == {"trustfusion"}
    assert read_json(ctx.run_dir / "metrics.json")["seed"] == 0
    assert isinstance(pred, pd.DataFrame)
