"""TrustFusion: explainable, uncertainty-calibrated multimodal malware detection and classification.

Reproducibility package accompanying the manuscript. Sub-modules:

* :mod:`trustfusion.data`        -- byte images, static descriptors, datasets and splits
* :mod:`trustfusion.models`      -- TrustFusion and the nine baselines
* :mod:`trustfusion.losses`      -- class-balanced focal, calibration and alignment losses
* :mod:`trustfusion.conformal`   -- split / weighted conformal prediction
* :mod:`trustfusion.temporal`    -- chronological (P-T) deployment loop
* :mod:`trustfusion.attribution` -- Grad-CAM / Grad-CAM++ and byte-offset projection
* :mod:`trustfusion.faithfulness`-- deletion / insertion AUC
* :mod:`trustfusion.metrics`, :mod:`trustfusion.stats`, :mod:`trustfusion.provenance`
"""

__version__ = "1.0.0"
