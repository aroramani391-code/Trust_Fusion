"""Training objectives (SPEC §2).

``L = L_CB-focal + lambda_1 L_cal + lambda_2 L_align`` with ``lambda_1 = 0.35`` and ``lambda_2 = 0.10``.

* Class-balanced focal loss (Cui et al., 2019; Lin et al., 2017): weight ``w_c = (1 - beta) / (1 - beta^{n_c})``
  with ``beta = 0.999`` (effective number of samples), normalised to sum to the number of classes, and focusing
  parameter ``gamma = 2``: ``-w_y (1 - p_y)^gamma log p_y`` averaged over the batch.
* Differentiable calibration loss: ``L_cal = sum_m |B_m|/n * |acc(B_m) - conf(B_m)|`` over ``M = 15``
  equal-width confidence bins ``((m-1)/M, m/M]``; the accuracy term is detached, so gradients flow through the
  confidences only.
* Alignment loss: ``mean(1 - cos(proj(z_v), proj(z_s)))`` over samples in which both views are present.

Every criterion returns ``(loss, logs)``.
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


def class_balanced_weights(class_counts: Sequence[int] | np.ndarray, beta: float = 0.999) -> torch.Tensor:
    counts = np.asarray(class_counts, dtype=np.float64)
    present = counts > 0
    eff = 1.0 - np.power(beta, counts)
    w = np.zeros_like(counts)
    w[present] = (1.0 - beta) / eff[present]
    if w.sum() > 0:
        w = w / w.sum() * present.sum()
    return torch.tensor(w, dtype=torch.float32)


def confidence_bins(conf: torch.Tensor, n_bins: int = 15) -> torch.Tensor:
    """Bin index for equal-width bins ``((m-1)/M, m/M]`` (confidence 0 goes to the first bin)."""
    return torch.clamp(torch.ceil(conf * n_bins).long() - 1, 0, n_bins - 1)


class ClassBalancedFocalLoss(nn.Module):
    def __init__(self, class_counts: Sequence[int] | np.ndarray, beta: float = 0.999, gamma: float = 2.0):
        super().__init__()
        self.gamma = float(gamma)
        self.register_buffer("weights", class_balanced_weights(class_counts, beta))

    def forward(self, logits: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        logp = F.log_softmax(logits, dim=-1)
        logp_y = logp.gather(1, y.view(-1, 1)).squeeze(1)
        p_y = logp_y.exp()
        return (-self.weights[y] * (1.0 - p_y).pow(self.gamma) * logp_y).mean()


def calibration_loss(logits: torch.Tensor, y: torch.Tensor, n_bins: int = 15) -> torch.Tensor:
    probs = F.softmax(logits, dim=-1)
    conf, pred = probs.max(dim=-1)
    acc = (pred == y).to(conf.dtype).detach()
    bins = confidence_bins(conf.detach(), n_bins)
    conf_sum = torch.zeros(n_bins, dtype=conf.dtype, device=conf.device).scatter_add(0, bins, conf)
    acc_sum = torch.zeros(n_bins, dtype=conf.dtype, device=conf.device).scatter_add(0, bins, acc)
    # |B_m|/n * |acc_m - conf_m| == |sum_acc_m - sum_conf_m| / n
    return (acc_sum - conf_sum).abs().sum() / max(int(logits.shape[0]), 1)


def alignment_loss(z_v: torch.Tensor, z_s: torch.Tensor, mask: torch.Tensor | None = None) -> torch.Tensor:
    cos = F.cosine_similarity(z_v, z_s, dim=-1)
    if mask is not None:
        mask = mask.to(torch.bool)
        if not bool(mask.any()):
            return (z_v.sum() + z_s.sum()) * 0.0
        cos = cos[mask]
    return (1.0 - cos).mean()


class CrossEntropyCriterion(nn.Module):
    def forward(self, logits: torch.Tensor, y: torch.Tensor, **_: Any) -> tuple[torch.Tensor, dict[str, float]]:
        loss = F.cross_entropy(logits, y)
        return loss, {"loss": float(loss.detach())}


class TrustFusionLoss(nn.Module):
    def __init__(self, class_counts: Sequence[int] | np.ndarray, loss_cfg: Mapping[str, Any]):
        super().__init__()
        self.kind = str(loss_cfg.get("type", "cb_focal"))
        if self.kind == "cb_focal":
            self.cls = ClassBalancedFocalLoss(class_counts, float(loss_cfg.get("beta", 0.999)), float(loss_cfg.get("gamma", 2.0)))
        elif self.kind == "ce":
            self.cls = None
        else:
            raise ValueError(f"unknown loss type {self.kind!r}")
        self.lambda_cal = float(loss_cfg.get("lambda_cal", 0.35))
        self.lambda_align = float(loss_cfg.get("lambda_align", 0.10))
        self.cal_bins = int(loss_cfg.get("cal_bins", 15))

    def forward(self, logits: torch.Tensor, y: torch.Tensor, z_v: torch.Tensor | None = None,
                z_s: torch.Tensor | None = None, pair_mask: torch.Tensor | None = None) -> tuple[torch.Tensor, dict[str, float]]:
        cls = self.cls(logits, y) if self.cls is not None else F.cross_entropy(logits, y)
        total = cls
        logs = {"cls": float(cls.detach())}
        if self.lambda_cal > 0:
            cal = calibration_loss(logits, y, self.cal_bins)
            total = total + self.lambda_cal * cal
            logs["cal"] = float(cal.detach())
        if self.lambda_align > 0 and z_v is not None and z_s is not None:
            align = alignment_loss(z_v, z_s, pair_mask)
            total = total + self.lambda_align * align
            logs["align"] = float(align.detach())
        logs["loss"] = float(total.detach())
        return total, logs


def build_criterion(cfg: Mapping[str, Any], class_counts: Sequence[int] | np.ndarray) -> nn.Module:
    loss_cfg = dict(cfg.get("loss", {}))
    if cfg.get("method") == "trustfusion":
        return TrustFusionLoss(class_counts, loss_cfg)
    kind = loss_cfg.get("type", "ce")
    if kind == "ce":
        return CrossEntropyCriterion()
    return TrustFusionLoss(class_counts, {**loss_cfg, "lambda_cal": loss_cfg.get("lambda_cal", 0.0),
                                          "lambda_align": loss_cfg.get("lambda_align", 0.0)})
