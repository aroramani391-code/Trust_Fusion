#!/usr/bin/env python
"""Faithfulness control (Table 9) and attribution-mass data (Fig. 2).

For every selected test file: Grad-CAM / Grad-CAM++ maps for the four variants, projection to byte offsets, and
deletion / insertion AUC over 21 points under the ``image_view`` and ``coupled`` protocols.

Outputs (``--out``, default results/faithfulness): ``<corpus>/seed<k>/per_sample.csv``, ``summary.csv`` (mean AUC per
variant x protocol), ``region_mass.csv`` (Grad-CAM++ through fusion, per PE region) and ``strip.csv`` (normalised
attribution along the file offset of the first sample).

Coupled protocol callbacks
  * BODMAS: ``--extractor ember_v2`` (optional ``ember`` + ``lief``); ``histogram_only`` is a TEST-ONLY stand-in.
  * MalNet: DEX bytes are needed (``--dex-dir``, not part of MalNet-Image); ``--render-fn module:function`` must map
    bytes to the un-normalised 3-channel image used in training, and ``--graph-fn module:function`` called as
    ``fn(sample_id, bytes, masked)`` must return the 48-d descriptor after removing methods in masked ranges (see trustfusion.data.static_features.remove_masked_methods;
    method offsets can be obtained with the optional ``androguard`` package).

Example::

    python scripts/run_faithfulness.py --run runs/bodmas/pr_family/trustfusion --n-samples 1000
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import torch  # noqa: E402

from trustfusion.attribution import VARIANTS  # noqa: E402
from trustfusion.cli import import_callable, run_dirs  # noqa: E402
from trustfusion.data.byte_image import ChannelStats, parse_pe, region_mass  # noqa: E402
from trustfusion.data.datasets import PairedViewDataset  # noqa: E402
from trustfusion.data.static_features import EmberFeatureExtractor, StaticTransform, histogram_extractor  # noqa: E402
from trustfusion.faithfulness import PROTOCOLS, FaithfulnessInputs, ProbabilityOracle, evaluate_faithfulness  # noqa: E402
from trustfusion.training import build_context, load_torch_model  # noqa: E402
from trustfusion.utils import get_logger, load_config, resolve_device  # noqa: E402

log = get_logger("run_faithfulness")


def strip_profile(scores: np.ndarray, points: int) -> np.ndarray:
    bins = np.array_split(np.asarray(scores, dtype=np.float64), points)
    prof = np.array([b.mean() if b.size else 0.0 for b in bins])
    return prof / prof.max() if prof.max() > 0 else prof


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", nargs="+", required=True)
    ap.add_argument("--config", default="configs/faithfulness.yaml")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--splits", default="splits")
    ap.add_argument("--out", default="results/faithfulness")
    ap.add_argument("--n-samples", type=int, default=None)
    ap.add_argument("--variants", nargs="+", default=None, choices=list(VARIANTS))
    ap.add_argument("--protocols", nargs="+", default=None, choices=list(PROTOCOLS))
    ap.add_argument("--extractor", default=None, choices=["ember_v2", "ember_v3", "histogram_only", "none"])
    ap.add_argument("--render-fn", default=None)
    ap.add_argument("--graph-fn", default=None)
    ap.add_argument("--dex-dir", default=None)
    ap.add_argument("--strip-points", type=int, default=458)
    ap.add_argument("--device", default=None)
    args = ap.parse_args()
    fcfg = load_config(args.config)
    frac = fcfg.get("fractions", {})
    fractions = np.linspace(float(frac.get("start", 0.0)), float(frac.get("stop", 1.0)), int(frac.get("points", 21)))
    device = resolve_device(args.device)

    for run in run_dirs(args.run):
        model, ckpt = load_torch_model(run, device)
        cfg = ckpt["config"]
        corpus_name = cfg["corpus"]
        ccfg = dict(fcfg.get("corpora", {}).get(corpus_name, {}))
        ctx = build_context(cfg, args.data_root, args.splits, run.parents[3], int(ckpt["seed"]), run.parent.name, str(device))
        rows = ctx.rows(ccfg.get("split", "test"))
        n = args.n_samples if args.n_samples is not None else fcfg.get("n_samples")
        if n is not None and n < len(rows):
            rows = rows.sample(n=int(n), random_state=int(fcfg.get("sample_seed", 2024))).reset_index(drop=True)
        st = StaticTransform.from_state(ckpt["static_transform"]) if ckpt.get("static_transform") else None
        stats = ChannelStats(**ckpt["image_stats"]) if ckpt.get("image_stats") else ChannelStats.identity()
        ds = PairedViewDataset(ctx.corpus, rows, cfg["data"], train=False, static_transform=None, image_stats=stats)
        kind = ctx.corpus.meta["image_kind"].to_numpy()
        if args.render_fn:
            user_render = import_callable(args.render_fn)
            render = lambda b: stats.normalise(user_render(b))  # noqa: E731
        elif all(kind[r] == "bytes" for r in rows["row"]):
            render = lambda b: ds.normalise(ds.render(b, None))  # noqa: E731
        else:
            raise SystemExit("image files are pre-rendered (PNG); pass --render-fn for byte-level perturbations")
        ext_name = args.extractor or ccfg.get("extractor", "none")
        extractor = graph_fn = None
        if ext_name in ("ember_v2", "ember_v3"):
            extractor = EmberFeatureExtractor(ext_name)
        elif ext_name == "histogram_only":
            extractor = histogram_extractor(ctx.layout)
        if args.graph_fn:
            graph_fn = import_callable(args.graph_fn)
        protocols = args.protocols or fcfg.get("protocols", list(PROTOCOLS))
        if extractor is None and graph_fn is None:
            protocols = [p for p in protocols if p != "coupled"]
            log.warning("no extractor/graph callback: running the image_view protocol only")
        samples = []
        dex_dir = Path(args.dex_dir or ccfg.get("dex_dir") or "")
        for sid, row in zip(rows["sample_id"], rows["row"]):
            data = ds.read_bytes(int(row)) if kind[row] == "bytes" else np.frombuffer((dex_dir / f"{sid}.dex").read_bytes(), np.uint8)
            static_raw = np.asarray(ctx.corpus.static[int(row)], np.float32) if ctx.corpus.static is not None else None
            samples.append(FaithfulnessInputs(str(sid), data, static_raw))
        oracle = ProbabilityOracle(model, render, st, device, extractor=extractor, graph_fn=graph_fn)
        fam = dict(zip(ctx.corpus.meta["sample_id"], ctx.corpus.meta["family"]))
        mass_rows, strip = [], None

        def on_attr(sample: FaithfulnessInputs, variant: str, scores: np.ndarray) -> None:
            nonlocal strip
            if variant != "gradcampp_fusion":
                return
            mass_rows.append({"sample_id": sample.sample_id, "family": fam.get(sample.sample_id, ""),
                              **region_mass(scores, parse_pe(sample.data))})
            if strip is None:
                strip = strip_profile(scores, args.strip_points)

        res = evaluate_faithfulness(model, samples, oracle, args.variants or fcfg.get("variants", list(VARIANTS)), protocols,
                                    int(cfg["data"]["image"]["size"]), fractions, on_attribution=on_attr)
        out = Path(args.out) / corpus_name / run.name
        out.mkdir(parents=True, exist_ok=True)
        df = pd.DataFrame(res).assign(method=run.parent.name, seed=int(ckpt["seed"]))
        df.to_csv(out / "per_sample.csv", index=False)
        df.groupby(["variant", "protocol"])[["deletion_auc", "insertion_auc"]].mean().reset_index().to_csv(out / "summary.csv", index=False)
        pd.DataFrame(mass_rows).to_csv(out / "region_mass.csv", index=False)
        if strip is not None:
            np.savetxt(out / "strip.csv", strip, fmt="%.3f",
                       header=f"normalised attribution along file offset (0..1), sample {samples[0].sample_id}")
        log.info("%s: %d samples\n%s", out, len(samples), pd.read_csv(out / "summary.csv").to_string(index=False))


if __name__ == "__main__":
    torch.set_grad_enabled(True)
    main()
