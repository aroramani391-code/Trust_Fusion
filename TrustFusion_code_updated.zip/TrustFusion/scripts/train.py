#!/usr/bin/env python
"""Train a torch method (TrustFusion or a neural baseline) for one or more seeds, then run inference.

Writes ``runs/<corpus>/<protocol>/<method>/seed<k>/{best.pt, config.yaml, history.csv, train_info.json,
inference/{val,cal,test}.npz}``.

Examples::

    python scripts/train.py --config configs/trustfusion/bodmas_pr.yaml                       # 5 seeds, P-R family
    python scripts/train.py --config configs/trustfusion/bodmas_pr.yaml --protocol pr_detection
    python scripts/train.py --config configs/baselines/cross_attention.yaml --corpus malnet_tiny --seeds 0
    python scripts/train.py --config configs/trustfusion/bodmas_pr.yaml --method-name trustfusion__no_lcal \
        --set loss.lambda_cal=0
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from trustfusion.cli import add_config_args, add_path_args, add_seed_args, load_cfg, seeds_from  # noqa: E402
from trustfusion.models import method_kind  # noqa: E402
from trustfusion.training import build_context, infer_torch, subsample_train, train_torch  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("train")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_config_args(ap)
    add_path_args(ap)
    add_seed_args(ap)
    ap.add_argument("--method-name", default=None, help="run-directory method name (default: config method)")
    ap.add_argument("--train-subsample", type=float, default=None, help="stratified fraction of the training split")
    ap.add_argument("--no-infer", action="store_true", help="skip inference on val/cal/test")
    args = ap.parse_args()

    cfg = load_cfg(args)
    if method_kind(cfg["method"]) not in ("torch", "graph"):
        raise SystemExit(f"{cfg['method']} is not a torch method; use scripts/train_gbdt.py")
    if cfg.get("corpora") and cfg["corpus"] not in cfg["corpora"]:
        raise SystemExit(f"{cfg['method']} is not defined for corpus {cfg['corpus']} (applicable: {cfg['corpora']})")
    if cfg["corpus"] == "malnet_tiny" and cfg.get("task") == "detection" and not cfg.get("data", {}).get("benign_source"):
        raise SystemExit("MalNet-Tiny detection needs an explicit benign source: --set data.benign_source=<name>")
    for seed in seeds_from(args, cfg):
        ctx = build_context(cfg, args.data_root, args.splits, args.runs, seed, args.method_name, args.device)
        if args.train_subsample:
            subsample_train(ctx, args.train_subsample)
        info = train_torch(ctx)
        log.info("seed %d done: %s", seed, info)
        if not args.no_infer:
            for p in infer_torch(ctx.run_dir, args.data_root, args.splits, device=args.device):
                log.info("wrote %s", p)


if __name__ == "__main__":
    main()
