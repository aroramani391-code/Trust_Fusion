"""Training and inference plumbing shared by ``scripts/train.py``, ``scripts/train_gbdt.py`` and ``scripts/tune.py``.

Optimisation (SPEC §2, §4): AdamW (Adam for the structural GIN), cosine learning-rate schedule over
``max_epochs * steps_per_epoch`` steps, at most 80 epochs, early stopping on validation macro-F1 (deterministic
head) with patience 12; the best-validation checkpoint is kept as ``best.pt``.

Inference writes ``inference/<split>.npz`` with ``p_bar`` (head-only MC dropout, T = 12, when ``inference.mc``),
``p_det`` (dropout disabled), ``entropy``, ``mutual_info``, ``gate`` and the sample metadata needed downstream.
"""
from __future__ import annotations

import math
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader

from .data.byte_image import ChannelStats, compute_channel_stats
from .data.datasets import (DATASETS, CallGraphDataset, CorpusData, PairedViewDataset, RawImageDataset, collate_graphs,
                            load_corpus)
from .data.splits import read_split, stratified_split
from .data.static_features import FeatureLayout, StaticTransform, load_layout
from .io import load_checkpoint, read_json, run_dir as make_run_dir, save_checkpoint, write_json
from .losses import build_criterion
from .metrics import macro_f1
from .models import build_torch_model
from .models.baselines.graph import node_summaries
from .utils import get_logger, resolve_device, save_config, seed_everything, torch_generator, worker_init_fn

log = get_logger("trustfusion.training")

IMAGE_METHODS = {"byte_cnn", "mcdropout_cnn", "msvit", "cross_attention"}
STATIC_METHODS = {"feature_graph", "cross_attention", "lgbm_static", "conformal_lgbm"}


# --------------------------------------------------------------------------------------------- context
@dataclass
class RunContext:
    cfg: dict
    corpus: CorpusData
    split_df: pd.DataFrame
    classes: list[str]
    layout: FeatureLayout | None
    run_dir: Path
    seed: int
    device: torch.device
    train_fraction: float = 1.0

    @property
    def method(self) -> str:
        return str(self.cfg["method"])

    @property
    def num_classes(self) -> int:
        return len(self.classes)

    def rows(self, split: str) -> pd.DataFrame:
        return self.split_df[self.split_df["split"] == split].reset_index(drop=True)


def corpus_dir_from(cfg: Mapping[str, Any], data_root: str | Path | None) -> Path:
    if data_root is not None:
        return Path(data_root) / str(cfg["corpus"])
    return Path(cfg.get("data", {}).get("processed_dir", Path("data/processed") / str(cfg["corpus"])))


def build_context(cfg: dict, data_root: str | Path | None, splits_dir: str | Path, runs_root: str | Path, seed: int,
                  method_name: str | None = None, device: str | None = None) -> RunContext:
    corpus = load_corpus(corpus_dir_from(cfg, data_root))
    split_df, classes = read_split(splits_dir, cfg["corpus"], cfg["protocol"])
    lay_path = cfg.get("data", {}).get("layout")
    layout = load_layout(lay_path) if lay_path else corpus.layout
    if layout is not None and corpus.static is not None and corpus.static.shape[1] != layout.dim:
        raise ValueError(f"static.npy has {corpus.static.shape[1]} columns but layout {layout.name} expects {layout.dim}")
    rd = make_run_dir(runs_root, cfg["corpus"], cfg["protocol"], method_name or cfg["method"], seed)
    return RunContext(cfg=cfg, corpus=corpus, split_df=split_df, classes=classes, layout=layout, run_dir=rd, seed=seed,
                      device=resolve_device(device or cfg.get("training", {}).get("device", "auto")))


def subsample_train(ctx: RunContext, fraction: float, seed: int = 2024) -> None:
    """Keep a stratified ``fraction`` of the training rows (EMBER2024 tuning on a 10% training subsample)."""
    tr = ctx.split_df.index[ctx.split_df["split"] == "train"].to_numpy()
    labels = ctx.split_df["label"].to_numpy()
    keep, _ = stratified_split(tr, labels, 1.0 - fraction, seed) if fraction < 1 else (tr, None)
    drop = np.setdiff1d(tr, keep)
    ctx.split_df = ctx.split_df.drop(index=drop).reset_index(drop=True)
    ctx.train_fraction = float(fraction)


def uses_image(cfg: Mapping[str, Any]) -> bool:
    if cfg.get("data", {}).get("views", {}).get("image", "bytes") == "none":
        return False
    m = cfg["method"]
    return (m == "trustfusion" and bool(cfg.get("model", {}).get("use_image", True))) or m in IMAGE_METHODS


def uses_static(cfg: Mapping[str, Any]) -> bool:
    m = cfg["method"]
    return (m == "trustfusion" and bool(cfg.get("model", {}).get("use_static", True))) or m in STATIC_METHODS


# --------------------------------------------------------------------------------------------- preprocessing
def fit_static_transform(ctx: RunContext) -> StaticTransform | None:
    if ctx.corpus.static is None or not uses_static(ctx.cfg):
        return None
    kind = ctx.cfg.get("data", {}).get("static", {}).get("transform", "log1p_standardize")
    return StaticTransform(kind=kind).fit(ctx.corpus.static, ctx.rows("train")["row"].to_numpy())


def image_statistics(ctx: RunContext) -> ChannelStats | None:
    """Per-channel mean/std over the training split, cached per (corpus, protocol, channels, size)."""
    if not uses_image(ctx.cfg):
        return None
    img = ctx.cfg.get("data", {}).get("image", {})
    tag = "-".join(img.get("channels", ["grey", "entropy", "bigram"])) + f"_{int(img.get('size', 224))}"
    if ctx.train_fraction < 1.0:
        tag += f"_train{ctx.train_fraction:g}"
    cache = ctx.run_dir.parent.parent / f"_image_stats_{tag}.json"
    if cache.exists():
        d = read_json(cache)
        return ChannelStats(d["mean"], d["std"])
    ds = PairedViewDataset(ctx.corpus, ctx.rows("train"), ctx.cfg["data"], train=False, use_static=False)
    loader = make_loader(RawImageDataset(ds, img.get("stats_max_samples")), ctx.cfg, shuffle=False, seed=0)

    def images():
        for batch in loader:
            for im, has in zip(batch["image"], batch["has_image"]):
                if bool(has):
                    yield im

    stats = compute_channel_stats(images())
    write_json(cache, {"mean": stats.mean, "std": stats.std, "n_train": len(ds)})
    return stats


def make_dataset(ctx: RunContext, split: str, train: bool, static_transform: StaticTransform | None,
                 stats: ChannelStats | None) -> torch.utils.data.Dataset:
    rows = ctx.rows(split)
    if ctx.method == "gin_callgraph":
        return CallGraphDataset(ctx.corpus, rows)
    cls = DATASETS.get(str(ctx.cfg["corpus"]), PairedViewDataset)
    return cls(ctx.corpus, rows, ctx.cfg["data"], train=train, static_transform=static_transform,
               image_stats=stats, use_image=uses_image(ctx.cfg), use_static=uses_static(ctx.cfg))


def make_loader(ds: torch.utils.data.Dataset, cfg: Mapping[str, Any], shuffle: bool, seed: int,
                batch_size: int | None = None) -> DataLoader:
    tr = cfg.get("training", {})
    nw = int(tr.get("num_workers", 0))
    return DataLoader(ds, batch_size=int(batch_size or cfg.get("optim", {}).get("batch_size", 128)), shuffle=shuffle,
                      num_workers=nw, worker_init_fn=worker_init_fn if nw > 0 else None, generator=torch_generator(seed),
                      collate_fn=collate_graphs if isinstance(ds, CallGraphDataset) else None,
                      pin_memory=torch.cuda.is_available())


def take_rows(X: np.ndarray, rows: np.ndarray) -> np.ndarray:
    """``X[rows]`` for (memory-mapped) arrays, reading rows in sorted order and restoring the requested order."""
    rows = np.asarray(rows, dtype=np.int64)
    order = np.argsort(rows, kind="stable")
    out = np.asarray(X[rows[order]], dtype=np.float32)
    inv = np.empty_like(order)
    inv[order] = np.arange(order.size)
    return out[inv]


def to_device(batch: Mapping[str, Any], device: torch.device) -> dict[str, Any]:
    return {k: (v.to(device, non_blocking=True) if isinstance(v, torch.Tensor) else v) for k, v in batch.items()}


def feature_graph_adjacency(ctx: RunContext, st: StaticTransform, chunk: int = 8192) -> np.ndarray:
    rows = np.sort(ctx.rows("train")["row"].to_numpy())
    idx = ctx.layout.group_indices()
    summaries = np.concatenate([node_summaries(st.transform(ctx.corpus.static[rows[i:i + chunk]]), idx)
                                for i in range(0, rows.size, chunk)])
    thr = float(ctx.cfg.get("model", {}).get("corr_threshold", 0.3))
    with np.errstate(invalid="ignore", divide="ignore"):
        r = np.nan_to_num(np.corrcoef(summaries, rowvar=False))
    A = (np.abs(r) >= thr).astype(np.float32)
    np.fill_diagonal(A, 0.0)
    return A


# --------------------------------------------------------------------------------------------- torch training
@torch.no_grad()
def validation_macro_f1(model: torch.nn.Module, loader: DataLoader, device: torch.device) -> float:
    model.eval()
    ys, ps = [], []
    for batch in loader:
        batch = to_device(batch, device)
        out = model.mc_predict(batch, T=1, mc=False)
        ps.append(out["p_det"].argmax(1).cpu().numpy())
        ys.append(batch["label"].cpu().numpy())
    return macro_f1(np.concatenate(ys), np.concatenate(ps)) if ys else float("nan")


def build_optimizer(model: torch.nn.Module, cfg: Mapping[str, Any]) -> torch.optim.Optimizer:
    o = cfg.get("optim", {})
    name = str(o.get("name", "adamw")).lower()
    lr, wd = float(o.get("lr", 3e-4)), float(o.get("weight_decay", 0.0))
    if name == "adamw":
        return torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=wd)
    if name == "adam":
        return torch.optim.Adam(model.parameters(), lr=lr, weight_decay=wd)
    raise ValueError(f"unknown optimiser {name!r}")


def cosine_schedule(opt: torch.optim.Optimizer, total_steps: int) -> torch.optim.lr_scheduler.LambdaLR:
    total = max(1, int(total_steps))
    return torch.optim.lr_scheduler.LambdaLR(opt, lambda step: 0.5 * (1.0 + math.cos(math.pi * min(step, total) / total)))


def train_torch(ctx: RunContext) -> dict[str, Any]:
    cfg = ctx.cfg
    seed_everything(ctx.seed, bool(cfg.get("training", {}).get("deterministic", True)))
    ctx.run_dir.mkdir(parents=True, exist_ok=True)
    save_config(cfg, ctx.run_dir / "config.yaml")
    st = fit_static_transform(ctx)
    stats = image_statistics(ctx)
    train_ds = make_dataset(ctx, "train", True, st, stats)
    val_ds = make_dataset(ctx, "val", False, st, stats)
    train_loader = make_loader(train_ds, cfg, shuffle=True, seed=ctx.seed)
    val_loader = make_loader(val_ds, cfg, shuffle=False, seed=ctx.seed)
    counts = np.bincount(ctx.rows("train")["label"].to_numpy(), minlength=ctx.num_classes)
    adjacency = feature_graph_adjacency(ctx, st) if ctx.method == "feature_graph" else None
    static_dim = int(ctx.corpus.static.shape[1]) if ctx.corpus.static is not None else 0
    model = build_torch_model(cfg, ctx.num_classes, ctx.layout.group_indices() if ctx.layout else None, static_dim,
                              adjacency).to(ctx.device)
    criterion = build_criterion(cfg, counts).to(ctx.device)
    opt = build_optimizer(model, cfg)
    tr_cfg = cfg.get("training", {})
    max_epochs, patience = int(tr_cfg.get("max_epochs", 80)), int(tr_cfg.get("patience", 12))
    sched = cosine_schedule(opt, max_epochs * max(1, len(train_loader)))
    extras = {"classes": ctx.classes, "num_classes": ctx.num_classes, "seed": ctx.seed, "method": ctx.method,
              "layout": ctx.layout.to_dict() if ctx.layout else None,
              "static_transform": st.state() if st is not None else None,
              "image_stats": {"mean": stats.mean, "std": stats.std} if stats is not None else None,
              "adjacency": adjacency.tolist() if adjacency is not None else None, "static_dim": static_dim}
    best, best_epoch, bad, history = -math.inf, -1, 0, []
    t0 = time.time()
    for epoch in range(max_epochs):
        model.train()
        sums: dict[str, float] = {}
        n_batches = 0
        for batch in train_loader:
            batch = to_device(batch, ctx.device)
            out = model(batch)
            loss, logs = model.compute_loss(batch, out, criterion)
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            sched.step()
            for k, v in logs.items():
                sums[k] = sums.get(k, 0.0) + v
            n_batches += 1
        val_f1 = validation_macro_f1(model, val_loader, ctx.device)
        row = {"epoch": epoch, "val_macro_f1": val_f1, "lr": opt.param_groups[0]["lr"],
               **{f"train_{k}": v / max(n_batches, 1) for k, v in sums.items()}}
        history.append(row)
        log.info("%s seed%d epoch %d: %s", ctx.method, ctx.seed, epoch,
                 ", ".join(f"{k}={v:.4f}" for k, v in row.items() if isinstance(v, float)))
        if val_f1 > best or best_epoch < 0:
            best, best_epoch, bad = val_f1, epoch, 0
            save_checkpoint(ctx.run_dir / "best.pt", model, cfg, epoch=epoch, val_macro_f1=val_f1, **extras)
        else:
            bad += 1
            if bad >= patience:
                break
    pd.DataFrame(history).to_csv(ctx.run_dir / "history.csv", index=False)
    info = {"best_epoch": best_epoch, "best_val_macro_f1": best, "epochs_run": len(history),
            "wall_time_s": time.time() - t0, "n_parameters": int(sum(p.numel() for p in model.parameters())),
            "n_train": len(train_ds), "n_val": len(val_ds)}
    write_json(ctx.run_dir / "train_info.json", info)
    return info


def load_torch_model(run: str | Path, device: str | torch.device = "cpu") -> tuple[torch.nn.Module, dict[str, Any]]:
    ckpt = load_checkpoint(Path(run) / "best.pt", map_location="cpu")
    cfg = ckpt["config"]
    layout = FeatureLayout.from_dict(ckpt["layout"]) if ckpt.get("layout") else None
    adjacency = np.asarray(ckpt["adjacency"], dtype=np.float32) if ckpt.get("adjacency") is not None else None
    model = build_torch_model(cfg, int(ckpt["num_classes"]), layout.group_indices() if layout else None,
                              int(ckpt.get("static_dim", 0)), adjacency)
    model.load_state_dict(ckpt["state_dict"])
    return model.to(device).eval(), ckpt


# --------------------------------------------------------------------------------------------- inference
@torch.no_grad()
def predict_loader(model: torch.nn.Module, loader: DataLoader, device: torch.device, T: int = 12, mc: bool = True
                   ) -> dict[str, np.ndarray]:
    keys = ("p_bar", "p_det", "entropy", "mutual_info", "gate")
    acc: dict[str, list[np.ndarray]] = {k: [] for k in keys}
    idx = []
    for batch in loader:
        batch = to_device(batch, device)
        out = model.mc_predict(batch, T=T, mc=mc)
        for k in keys:
            acc[k].append(out[k].float().cpu().numpy())
        idx.append(batch["index"].cpu().numpy())
    res = {k: np.concatenate(v) for k, v in acc.items()}
    order = np.argsort(np.concatenate(idx))
    return {k: v[order] for k, v in res.items()}


def _meta_arrays(ctx: RunContext, rows: pd.DataFrame) -> dict[str, np.ndarray]:
    meta = ctx.corpus.meta
    r = rows["row"].to_numpy()
    return {"sample_id": rows["sample_id"].astype(str).to_numpy(), "row": r, "label": rows["label"].to_numpy(),
            "window": rows["window"].astype(str).to_numpy(), "benign_source": meta["benign_source"].to_numpy()[r].astype(str),
            "timestamp": meta["timestamp"].to_numpy()[r].astype(str)}


def save_inference(run: Path, split: str, arrays: Mapping[str, np.ndarray], **scalars: Any) -> Path:
    path = Path(run) / "inference" / f"{split}.npz"
    path.parent.mkdir(parents=True, exist_ok=True)

    def _plain(v: Any) -> np.ndarray:
        a = np.asarray(v)
        return a.astype(str) if a.dtype == object else a  # no pickled object arrays on disk

    np.savez_compressed(path, **{k: _plain(v) for k, v in arrays.items()}, **{k: _plain(v) for k, v in scalars.items()})
    return path


def load_inference(run: str | Path, split: str) -> dict[str, np.ndarray]:
    with np.load(Path(run) / "inference" / f"{split}.npz", allow_pickle=False) as f:
        return {k: f[k] for k in f.files}


def infer_torch(run: str | Path, data_root: str | Path | None, splits_dir: str | Path,
                splits: Sequence[str] = ("val", "cal", "test"), device: str | None = None,
                batch_size: int | None = None) -> list[Path]:
    run = Path(run)
    dev = resolve_device(device)
    model, ckpt = load_torch_model(run, dev)
    cfg = ckpt["config"]
    ctx = build_context(cfg, data_root, splits_dir, run.parents[3], int(ckpt["seed"]), method_name=run.parent.name,
                        device=str(dev))
    st = StaticTransform.from_state(ckpt["static_transform"]) if ckpt.get("static_transform") else None
    stats = ChannelStats(**ckpt["image_stats"]) if ckpt.get("image_stats") else None
    inf = cfg.get("inference", {})
    T, mc = int(cfg.get("mc", {}).get("T", 12)), bool(inf.get("mc", False))
    paths = []
    for split in splits:
        rows = ctx.rows(split)
        if rows.empty:
            continue
        ds = make_dataset(ctx, split, False, st, stats)
        preds = predict_loader(model, make_loader(ds, cfg, shuffle=False, seed=0, batch_size=batch_size), dev, T=T, mc=mc)
        paths.append(save_inference(run, split, {**_meta_arrays(ctx, rows), **preds}, T=T if mc else 1, mc=mc))
    return paths


def probs_summary(p: np.ndarray) -> dict[str, np.ndarray]:
    ent = -(p * np.log(np.clip(p, 1e-12, None))).sum(1)
    return {"p_bar": p.astype(np.float32), "p_det": p.astype(np.float32), "entropy": ent.astype(np.float32),
            "mutual_info": np.zeros(p.shape[0], np.float32), "gate": np.full(p.shape[0], np.nan, np.float32)}
