#!/usr/bin/env python
"""Prepare the processed EMBER2024 corpus from local files (no download).

Where to obtain the data
  EMBER2024 (Joyce et al., 2025): https://github.com/FutureComputing4AI/EMBER2024 -- install ``thrember`` and call
  ``thrember.download_dataset(dir)`` to fetch the raw-feature JSONL files; optionally vectorise them with
  ``thrember.create_vectorized_features(dir)`` (X_train.dat / X_test.dat). EMBER2024 ships no binaries, so
  TrustFusion runs in single-stream mode (image view permanently masked).

Row order: ``X_<subset>.dat`` rows follow thrember's ``gather_feature_paths`` order (JSONL file names containing
``train`` / ``test`` sorted alphabetically, lines in file order); metadata is read in the same order and the row
counts are asserted. With ``--vectorize`` the vectors are computed here with ``thrember.PEFeatureExtractor``.

Example::

    python scripts/prepare_ember2024.py --data-dir raw/ember2024 --vectorized-dir raw/ember2024 \
        --out data/processed/ember2024 --check-counts
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from trustfusion.data.datasets import META_COLUMNS  # noqa: E402
from trustfusion.io import write_json  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("prepare_ember2024")
DIM = 2568
META_KEYS = ("sha256", "first_submission_date", "label", "file_type", "family")


def jsonl_files(data_dir: Path, subset: str) -> list[Path]:
    return [data_dir / f for f in sorted(os.listdir(data_dir)) if f.endswith(".jsonl") and subset in f]


def read_metadata(files: list[Path], subset: str, time_field: str, vectorizer=None, X_out=None, offset: int = 0) -> pd.DataFrame:
    recs = []
    i = offset
    for fp in files:
        with open(fp, "r", encoding="utf8") as f:
            for line in f:
                raw = json.loads(line)
                recs.append({k: raw.get(k) for k in META_KEYS if k != "first_submission_date"} | {"time": raw.get(time_field)})
                if vectorizer is not None:
                    X_out[i] = vectorizer.process_raw_features(raw)
                i += 1
    df = pd.DataFrame(recs)
    df["released_split"] = subset
    return df


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--data-dir", required=True, help="directory with EMBER2024 *.jsonl files")
    ap.add_argument("--vectorized-dir", default=None, help="directory with X_train.dat / X_test.dat")
    ap.add_argument("--vectorize", action="store_true", help="vectorise the JSONL here (needs thrember)")
    ap.add_argument("--time-field", default="first_submission_date")
    ap.add_argument("--out", default="data/processed/ember2024")
    ap.add_argument("--check-counts", action="store_true", help="assert 2,626,000 train and 606,000 test files")
    args = ap.parse_args()

    data_dir, out = Path(args.data_dir), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    files = {s: jsonl_files(data_dir, s) for s in ("train", "test")}
    n_rows = {s: sum(1 for fp in fs for _ in open(fp, "r", encoding="utf8")) for s, fs in files.items()}
    total = n_rows["train"] + n_rows["test"]
    static = np.lib.format.open_memmap(out / "static.npy", mode="w+", dtype=np.float32, shape=(total, DIM))
    vectorizer = None
    if args.vectorize:
        import thrember  # type: ignore

        vectorizer = thrember.PEFeatureExtractor()
        assert int(vectorizer.dim) == DIM
    elif not args.vectorized_dir:
        raise SystemExit("pass --vectorized-dir or --vectorize")
    frames = []
    offset = 0
    for subset in ("train", "test"):
        df = read_metadata(files[subset], subset, args.time_field, vectorizer, static, offset)
        if vectorizer is None:
            X = np.memmap(Path(args.vectorized_dir) / f"X_{subset}.dat", dtype=np.float32, mode="r").reshape(-1, DIM)
            if X.shape[0] != len(df):
                raise SystemExit(f"X_{subset}.dat has {X.shape[0]} rows but the JSONL files have {len(df)}")
            for s in range(0, len(df), 100_000):
                static[offset + s: offset + min(len(df), s + 100_000)] = X[s: s + 100_000]
        frames.append(df)
        offset += len(df)
    static.flush()
    raw = pd.concat(frames, ignore_index=True)
    t = raw["time"]
    ts = pd.to_datetime(t, unit="s", utc=True) if pd.api.types.is_numeric_dtype(t) else pd.to_datetime(t, utc=True, format="mixed")
    meta = pd.DataFrame({
        "sample_id": raw["sha256"].astype(str), "sha256": raw["sha256"].astype(str),
        "family": raw["family"].fillna("").astype(str), "is_malicious": raw["label"].fillna(-1).astype(int),
        "timestamp": ts.dt.tz_localize(None).astype(str), "benign_source": "", "file_format": raw["file_type"].astype(str),
        "released_split": raw["released_split"], "image_path": "", "image_kind": "", "has_static": 1, "graph_path": "",
    })[META_COLUMNS]
    counts = {"train": int((meta["released_split"] == "train").sum()), "test": int((meta["released_split"] == "test").sum()),
              "unlabelled": int((meta["is_malicious"] < 0).sum()),
              "formats": {str(k): int(v) for k, v in meta["file_format"].value_counts().items()}}
    if args.check_counts:
        assert counts["train"] == 2_626_000 and counts["test"] == 606_000, counts
    meta.to_csv(out / "meta.csv.gz", index=False, compression="gzip")
    write_json(out / "corpus.json", {"corpus": "ember2024", "layout": "configs/feature_layouts/ember2024.yaml",
                                     "views": {"image": "none", "static": "vector"}, "counts": counts})
    log.info("wrote %s: %s", out, counts)


if __name__ == "__main__":
    main()
