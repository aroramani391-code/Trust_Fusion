#!/usr/bin/env python
"""Prepare the processed MalNet-Image Tiny corpus with the 48-d call-graph view (no download).

Where to obtain the data
  MalNet (Freitas et al., 2022): https://mal-net.org -- MalNet-Image Tiny (``malnet-images-tiny``, 256x256 DEX images,
  43 types) and MalNet-Graph edge lists (``malnet-graphs``) for the sha256 matching.

Inputs
  * ``--images-dir``: either ``{train,val,test}/<type>/<family>/<sha256>.png`` or a flat ``<type>/<family>/<sha256>.png``
    tree together with ``--split-info`` (directory with ``train.txt``, ``val.txt``, ``test.txt`` of relative paths)
  * ``--graphs-dir``: MalNet-Graph tree containing ``<sha256>.edgelist`` files (optional; unmatched -> graph view masked)
  * ``--benign-images-dir`` + ``--benign-source``: optional benign images for the detection protocol. The manuscript
    uses ``--benign-source googleplay``: 5,000 benign Android APKs collected from the Google Play Store with zero
    VirusTotal detections, rendered as MalNet-style DEX images (``<sha256>.png``); the APKs are not redistributed,
    only their sha256 index

Output: ``<out>/meta.csv.gz``, ``<out>/static.npy``, ``<out>/corpus.json``, ``<out>/sha256_index.csv`` (sha256, class,
family type and benign source of every file, e.g. the ``googleplay`` benign APKs for the release index).

Example::

    python scripts/prepare_malnet.py --images-dir raw/malnet/malnet-images-tiny --graphs-dir raw/malnet/malnet-graphs \
        --out data/processed/malnet_tiny --workers 16 --check-counts
"""
from __future__ import annotations

import argparse
import sys
from multiprocessing import Pool
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from trustfusion.data.datasets import write_corpus  # noqa: E402
from trustfusion.data.static_features import descriptor_from_edgelist  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("prepare_malnet")


def _descriptor(path: str) -> np.ndarray:
    return descriptor_from_edgelist(path)


def scan_images(images_dir: Path, split_info: Path | None) -> pd.DataFrame:
    rows = []
    if split_info is not None:
        for split in ("train", "val", "test"):
            for rel in (split_info / f"{split}.txt").read_text().split():
                rel = rel.strip()
                p = images_dir / (rel if rel.endswith(".png") else rel + ".png")
                parts = Path(rel).parts
                rows.append((split, parts[0], parts[1] if len(parts) > 2 else "", Path(rel).stem, p))
    else:
        for split in ("train", "val", "test"):
            for p in sorted((images_dir / split).rglob("*.png")):
                rel = p.relative_to(images_dir / split).parts
                rows.append((split, rel[0], rel[1] if len(rel) > 2 else "", p.stem, p))
    return pd.DataFrame(rows, columns=["released_split", "type", "family", "sha256", "path"])


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--images-dir", required=True)
    ap.add_argument("--split-info", default=None)
    ap.add_argument("--graphs-dir", default=None)
    ap.add_argument("--benign-images-dir", default=None)
    ap.add_argument("--benign-source", default=None)
    ap.add_argument("--out", default="data/processed/malnet_tiny")
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--check-counts", action="store_true",
                    help="assert 61,201 / 8,743 / 17,486 files, 43 types, 1,286 files without a call graph (with "
                         "--graphs-dir) and 5,000 benign files (with --benign-source googleplay)")
    args = ap.parse_args()

    df = scan_images(Path(args.images_dir), Path(args.split_info) if args.split_info else None)
    if args.check_counts:
        c = df["released_split"].value_counts().to_dict()
        assert c == {"train": 61201, "val": 8743, "test": 17486}, c
        assert df["type"].nunique() == 43, df["type"].nunique()
    graphs: dict[str, Path] = {}
    if args.graphs_dir:
        graphs = {p.stem: p for p in Path(args.graphs_dir).rglob("*.edgelist")}
    meta = pd.DataFrame({
        "sample_id": df["sha256"], "sha256": df["sha256"], "family": df["type"], "is_malicious": 1, "timestamp": "",
        "benign_source": "", "file_format": "DEX", "released_split": df["released_split"],
        "image_path": [str(p.resolve()) for p in df["path"]], "image_kind": "png",
        "graph_path": [str(graphs[s].resolve()) if s in graphs else "" for s in df["sha256"]],
    })
    if args.benign_images_dir:
        if not args.benign_source:
            raise SystemExit("--benign-images-dir requires an explicit --benign-source name")
        bp = sorted(Path(args.benign_images_dir).rglob("*.png"))
        meta = pd.concat([meta, pd.DataFrame({
            "sample_id": [p.stem for p in bp], "sha256": [p.stem for p in bp], "family": "", "is_malicious": 0,
            "timestamp": "", "benign_source": args.benign_source, "file_format": "DEX", "released_split": "",
            "image_path": [str(p.resolve()) for p in bp], "image_kind": "png",
            "graph_path": [str(graphs[p.stem].resolve()) if p.stem in graphs else "" for p in bp]})], ignore_index=True)
    meta["has_static"] = (meta["graph_path"] != "").astype(int)
    static = np.zeros((len(meta), 48), dtype=np.float32)
    todo = np.flatnonzero(meta["has_static"].to_numpy() == 1)
    paths = meta["graph_path"].to_numpy()[todo].tolist()
    if paths:
        with Pool(max(1, args.workers)) as pool:
            for i, vec in zip(todo, pool.imap(_descriptor, paths, chunksize=16)):
                static[i] = vec
    tiny = meta["is_malicious"] == 1
    counts = {"released": {str(k): int(v) for k, v in meta.loc[tiny, "released_split"].value_counts().items()},
              "n_types": int(meta.loc[tiny, "family"].nunique()),
              "graph_unmatched": int((tiny & (meta["has_static"] == 0)).sum()),
              "benign": int((~tiny).sum()), "benign_source": args.benign_source}
    if args.check_counts:
        if args.graphs_dir:
            assert counts["graph_unmatched"] == 1286, counts
        if args.benign_source == "googleplay":
            assert counts["benign"] == 5000, counts
    write_corpus(args.out, meta, static, {"corpus": "malnet_tiny", "layout": "configs/feature_layouts/malnet_callgraph.yaml",
                                          "views": {"image": "png", "static": "vector"}, "counts": counts})
    meta[["sha256", "is_malicious", "family", "benign_source", "released_split"]].to_csv(Path(args.out) / "sha256_index.csv", index=False)
    log.info("wrote %s: %s", args.out, counts)


if __name__ == "__main__":
    main()
