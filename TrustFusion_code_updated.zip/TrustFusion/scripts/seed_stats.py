#!/usr/bin/env python
"""Seed statistics from per-sample prediction files.

Mean +- SD mode (Tables 4 and 6)::

    python scripts/seed_stats.py --runs runs --corpus bodmas --protocol pr_family \
        --methods trustfusion cross_attention late_fusion lgbm_static --metrics accuracy macro_f1 ece \
        --out results/tables/seed_stats_bodmas_pr_family.csv

Paired mode (Table 5): the six comparisons of ``configs/base.yaml`` (``stats.table5_comparisons``), paired t-test
(``scipy.stats.ttest_rel``) and 95% t-interval over seeds, paired bootstrap over test samples (10,000 resamples),
Holm correction over all comparisons::

    python scripts/seed_stats.py --paired --runs runs --out results/tables/table5.csv

Metrics: accuracy, macro_f1, ece, coverage, mean_set_size, acceptance, accepted_error, roc_auc, tpr@fpr=0.001,
tpr@fpr=0.01, selective_error@<c>, macro_f1@W<k>, pt_loss (macro-F1 W1 - W7).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import yaml  # noqa: E402

from trustfusion.aggregate import paired_comparisons, per_seed_table, summarize  # noqa: E402
from trustfusion.utils import CONFIG_ROOT, get_logger, load_config  # noqa: E402

log = get_logger("seed_stats")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", required=True, help="output CSV (a *_per_seed.csv companion is written as well)")
    ap.add_argument("--seeds", type=int, nargs="+", default=None)
    ap.add_argument("--paired", action="store_true")
    ap.add_argument("--comparisons", default=None, help="YAML with a `comparisons` list (default: base.yaml Table 5)")
    ap.add_argument("--n-boot", type=int, default=None, help="bootstrap resamples (default: base.yaml, 10,000)")
    ap.add_argument("--corpus")
    ap.add_argument("--protocol")
    ap.add_argument("--methods", nargs="+")
    ap.add_argument("--metrics", nargs="+", default=["accuracy", "macro_f1", "ece"])
    ap.add_argument("--predictions-name", default="predictions")
    args = ap.parse_args()
    base = load_config(CONFIG_ROOT / "base.yaml")
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    if args.paired:
        if args.comparisons:
            with open(args.comparisons, "r", encoding="utf8") as f:
                comps = yaml.safe_load(f)["comparisons"]
        else:
            comps = base["stats"]["table5_comparisons"]
        df = paired_comparisons(args.runs, comps, args.seeds, int(args.n_boot or base["stats"]["bootstrap_resamples"]),
                                float(base["stats"]["confidence"]), name=args.predictions_name)
        df.to_csv(out, index=False)
        log.info("wrote %s\n%s", out, df.to_string(index=False))
        return
    if not (args.corpus and args.protocol and args.methods):
        raise SystemExit("--corpus, --protocol and --methods are required without --paired")
    per_seed = per_seed_table(args.runs, args.corpus, args.protocol, args.methods, args.metrics, args.seeds, args.predictions_name)
    per_seed.to_csv(out.with_name(out.stem + "_per_seed.csv"), index=False)
    summary = summarize(per_seed)
    summary.to_csv(out, index=False)
    log.info("wrote %s\n%s", out, summary.to_string(index=False))


if __name__ == "__main__":
    main()
