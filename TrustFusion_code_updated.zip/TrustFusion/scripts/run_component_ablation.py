#!/usr/bin/env python
"""Component ablation (Table 7): train / calibrate / evaluate every variant of configs/ablation/component.yaml.

Each step is executed as a subprocess of the regular scripts (``--dry-run`` prints the commands instead), then
``results/ablation/component_per_seed.csv`` collects the metrics of every variant and seed.

Example::

    python scripts/run_component_ablation.py --seeds 0 1 2 3 4
"""
from __future__ import annotations

import argparse
import shlex
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from trustfusion.aggregate import metric_value, load_columns  # noqa: E402
from trustfusion.io import run_dir  # noqa: E402
from trustfusion.utils import get_logger, load_config  # noqa: E402

log = get_logger("run_component_ablation")
PY = sys.executable


def run(cmd: list[str], dry: bool) -> None:
    print("$ " + " ".join(shlex.quote(c) for c in cmd), flush=True)
    if not dry:
        subprocess.run(cmd, check=True)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="configs/ablation/component.yaml")
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--variants", nargs="+", default=None, help="subset of variant names")
    ap.add_argument("--data-root", default=None)
    ap.add_argument("--splits", default="splits")
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--results", default="results")
    ap.add_argument("--overlay", action="append", default=[])
    ap.add_argument("--device", default=None)
    ap.add_argument("--skip-existing", action="store_true", help="do not retrain runs that already have best.pt")
    ap.add_argument("--dry-run", action="store_true")
    args = ap.parse_args()
    cfg = load_config(args.config)
    corpus, protocol = cfg["corpus"], cfg["protocol"]
    common = ["--splits", args.splits, "--runs", args.runs] + (["--data-root", args.data_root] if args.data_root else []) \
        + sum((["--overlay", o] for o in args.overlay), []) + (["--device", args.device] if args.device else [])
    variants = [v for v in cfg["variants"] if args.variants is None or v["name"] in args.variants]
    for v in variants:
        for s in args.seeds:
            if v.get("reuse"):
                src = run_dir(args.runs, corpus, protocol, v["reuse"], s)
                ev = v.get("evaluate", {})
                run([PY, "scripts/evaluate.py", "--run", str(src), "--method-name", v["name"]]
                    + (["--no-conformal"] if ev.get("conformal") is False else []), args.dry_run)
                continue
            rd = run_dir(args.runs, corpus, protocol, v["name"], s)
            if not (args.skip_existing and (rd / "best.pt").exists()):
                sets = sum((["--set", f"{k}={val}"] for k, val in (v.get("train") or {}).items()), [])
                run([PY, "scripts/train.py", "--config", cfg["base_config"], "--protocol", protocol, "--seeds", str(s),
                     "--method-name", v["name"]] + common + sets, args.dry_run)
            run([PY, "scripts/calibrate.py", "--run", str(rd)], args.dry_run)
            run([PY, "scripts/evaluate.py", "--run", str(rd)], args.dry_run)
    if args.dry_run:
        return
    rows = []
    for v in variants:
        for s in args.seeds:
            cols = load_columns(run_dir(args.runs, corpus, protocol, v["name"], s))
            if cols is None:
                continue
            rows += [{"variant": v["name"], "label": v["label"], "seed": s, "metric": m, "value": metric_value(m, cols)}
                     for m in cfg["metrics"]]
    out = Path(args.results) / "ablation" / "component_per_seed.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    log.info("wrote %s", out)


if __name__ == "__main__":
    main()
