"""Gradient-boosted static model and conformal-gated static model (SPEC §4).

LightGBM with 1,024 leaves, learning rate 0.05, feature_fraction 0.5, bagging_fraction 0.5 (bagging_freq 1), at most
4,000 rounds with early stopping (100 rounds) on the validation loss, and balanced class weights for family tasks.
The conformal-gated variant adds the split-conformal layer (alpha = 0.05) fitted on the calibration split and
predicts only on singleton sets (handled by ``scripts/calibrate.py`` / ``scripts/evaluate.py``).
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Mapping

import numpy as np


class LightGBMModel:
    def __init__(self, num_classes: int, model_cfg: Mapping[str, Any], seed: int = 0, class_weight: str | None = None,
                 num_threads: int = 0):
        self.num_classes = int(num_classes)
        self.cfg = dict(model_cfg)
        self.seed = int(seed)
        self.class_weight = class_weight
        self.num_threads = int(num_threads)
        self.booster = None
        self.best_iteration: int | None = None

    def params(self) -> dict[str, Any]:
        binary = self.num_classes == 2
        p = {
            "objective": "binary" if binary else "multiclass",
            "metric": "binary_logloss" if binary else "multi_logloss",
            "num_leaves": int(self.cfg.get("num_leaves", 1024)),
            "learning_rate": float(self.cfg.get("learning_rate", 0.05)),
            "feature_fraction": float(self.cfg.get("feature_fraction", 0.5)),
            "bagging_fraction": float(self.cfg.get("bagging_fraction", 0.5)),
            "bagging_freq": int(self.cfg.get("bagging_freq", 1)),
            "min_data_in_leaf": int(self.cfg.get("min_data_in_leaf", 20)),
            "seed": self.seed, "deterministic": True, "force_row_wise": True, "verbosity": -1,
            "num_threads": self.num_threads,
        }
        if not binary:
            p["num_class"] = self.num_classes
        return p

    def fit(self, X_tr: np.ndarray, y_tr: np.ndarray, X_val: np.ndarray, y_val: np.ndarray) -> "LightGBMModel":
        import lightgbm as lgb
        from sklearn.utils.class_weight import compute_sample_weight

        weight = compute_sample_weight("balanced", y_tr) if self.class_weight == "balanced" else None
        dtrain = lgb.Dataset(np.asarray(X_tr, dtype=np.float32), label=np.asarray(y_tr), weight=weight, free_raw_data=True)
        dval = lgb.Dataset(np.asarray(X_val, dtype=np.float32), label=np.asarray(y_val), reference=dtrain)
        self.booster = lgb.train(
            self.params(), dtrain, num_boost_round=int(self.cfg.get("num_boost_round", 4000)), valid_sets=[dval],
            valid_names=["val"], callbacks=[lgb.early_stopping(int(self.cfg.get("early_stopping_rounds", 100)), verbose=False)])
        self.best_iteration = int(self.booster.best_iteration or self.booster.current_iteration())
        return self

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        if self.booster is None:
            raise RuntimeError("model is not fitted")
        p = self.booster.predict(np.asarray(X, dtype=np.float32), num_iteration=self.best_iteration)
        if self.num_classes == 2:
            p = np.column_stack([1.0 - p, p])
        return np.asarray(p, dtype=np.float64)

    def save(self, directory: str | os.PathLike) -> Path:
        d = Path(directory)
        d.mkdir(parents=True, exist_ok=True)
        self.booster.save_model(str(d / "model.txt"), num_iteration=self.best_iteration)
        with open(d / "model_meta.json", "w", encoding="utf8") as f:
            json.dump({"num_classes": self.num_classes, "best_iteration": self.best_iteration, "cfg": self.cfg,
                       "seed": self.seed, "class_weight": self.class_weight}, f, indent=2)
        return d / "model.txt"

    @staticmethod
    def load(directory: str | os.PathLike) -> "LightGBMModel":
        import lightgbm as lgb

        d = Path(directory)
        with open(d / "model_meta.json", "r", encoding="utf8") as f:
            meta = json.load(f)
        m = LightGBMModel(meta["num_classes"], meta["cfg"], meta["seed"], meta["class_weight"])
        m.booster = lgb.Booster(model_file=str(d / "model.txt"))
        m.best_iteration = None  # the saved model already contains only the best iterations
        return m
