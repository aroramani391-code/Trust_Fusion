"""Data handling: byte images, static descriptors, datasets and splits."""
