"""Conformal prediction layer (SPEC §3) and post-hoc temperature scaling.

Non-conformity score ``s_i = 1 - p_bar(y_i | x_i)``; prediction set ``C(x) = {y : 1 - p_bar(y|x) <= q_hat}``;
the model predicts iff ``|C(x)| = 1`` and abstains otherwise.

Split conformal (P-R, EMBER2024, MalNet)
    ``q_hat`` = k-th smallest calibration score with ``k = ceil((n + 1)(1 - alpha))``; ``q_hat = +inf`` if
    ``k > n``. With ``alpha = 0.05`` and the BODMAS calibration split ``n = 4,297``: ``k = ceil(4298 * 0.95) =
    ceil(4083.1) = 4,084``.

Weighted conformal (P-T)
    ``w_i = 2^{-(tau_k - t_i)/h}`` with half-life ``h = 15`` days (``t`` in days);
    ``p~_i = w_i / (sum_j w_j + 1)``; the test point's mass ``1 / (sum_j w_j + 1)`` sits at ``+inf``;
    ``q_hat_k = inf{q : sum_i p~_i 1[s_i <= q] >= 1 - alpha}`` (``+inf`` if unattainable). With unit weights
    this reduces exactly to the split rule. Effective sample size ``n_eff = (sum w)^2 / sum w^2``; for arrivals
    uniform over a 30-day month (ages ``a ~ U(0, 30)``), ``E[w] = (h / (30 ln 2)) (1 - 2^{-2})`` and
    ``E[w^2] = (h / (60 ln 2)) (1 - 2^{-4})`` so ``n_eff / n -> E[w]^2 / E[w^2] = 0.866``.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

import numpy as np

_EPS = 1e-9


def conformal_scores(probs: np.ndarray, y: np.ndarray) -> np.ndarray:
    probs = np.asarray(probs, dtype=np.float64)
    return 1.0 - probs[np.arange(probs.shape[0]), np.asarray(y, dtype=np.int64)]


def split_conformal_k(n: int, alpha: float = 0.05) -> int:
    """``k = ceil((n + 1)(1 - alpha))`` (guarded against floating-point round-up, e.g. 20 * 0.95)."""
    return int(math.ceil((n + 1) * (1.0 - alpha) - _EPS))


def split_conformal_quantile(scores: np.ndarray, alpha: float = 0.05) -> float:
    scores = np.sort(np.asarray(scores, dtype=np.float64))
    n = scores.size
    k = split_conformal_k(n, alpha)
    if n == 0 or k > n:
        return float("inf")
    return float(scores[k - 1])


def decay_weights(t_days: np.ndarray, tau_days: float, half_life_days: float = 15.0) -> np.ndarray:
    ages = float(tau_days) - np.asarray(t_days, dtype=np.float64)
    if np.any(ages < 0):
        raise ValueError("calibration samples must precede tau_k")
    return np.power(2.0, -ages / float(half_life_days))


def weighted_conformal_quantile(scores: np.ndarray, weights: np.ndarray, alpha: float = 0.05) -> float:
    scores = np.asarray(scores, dtype=np.float64)
    weights = np.asarray(weights, dtype=np.float64)
    if scores.shape != weights.shape:
        raise ValueError("scores and weights must have the same shape")
    if scores.size == 0:
        return float("inf")
    order = np.argsort(scores, kind="stable")
    s, w = scores[order], weights[order]
    p = w / (w.sum() + 1.0)  # the remaining mass 1 / (sum w + 1) is the test point at +inf
    cum = np.cumsum(p)
    hit = np.flatnonzero(cum >= (1.0 - alpha) - _EPS)
    if hit.size == 0:
        return float("inf")
    return float(s[hit[0]])


def effective_sample_size(weights: np.ndarray) -> float:
    w = np.asarray(weights, dtype=np.float64)
    denom = float((w ** 2).sum())
    return float(w.sum() ** 2 / denom) if denom > 0 else 0.0


def prediction_sets(probs: np.ndarray, qhat: float) -> np.ndarray:
    """Boolean ``[N, C]`` membership ``1 - p <= q_hat``."""
    return (1.0 - np.asarray(probs, dtype=np.float64)) <= qhat


def summarize_sets(sets: np.ndarray, y: np.ndarray | None = None) -> dict[str, float]:
    sizes = sets.sum(axis=1)
    out = {"mean_set_size": float(sizes.mean()) if sizes.size else float("nan"),
           "acceptance": float((sizes == 1).mean()) if sizes.size else float("nan")}
    if y is not None and sizes.size:
        out["coverage"] = float(sets[np.arange(sets.shape[0]), np.asarray(y, dtype=np.int64)].mean())
    return out


@dataclass
class ConformalResult:
    qhat: float
    n: int
    alpha: float
    k: int | None = None
    n_eff: float | None = None

    def to_dict(self) -> dict[str, Any]:
        return {"qhat": self.qhat, "n": self.n, "alpha": self.alpha, "k": self.k, "n_eff": self.n_eff}


def calibrate_split(probs: np.ndarray, y: np.ndarray, alpha: float = 0.05) -> ConformalResult:
    scores = conformal_scores(probs, y)
    return ConformalResult(qhat=split_conformal_quantile(scores, alpha), n=int(scores.size), alpha=alpha,
                           k=split_conformal_k(int(scores.size), alpha))


def calibrate_weighted(probs: np.ndarray, y: np.ndarray, t_days: np.ndarray, tau_days: float, alpha: float = 0.05,
                       half_life_days: float = 15.0) -> ConformalResult:
    scores = conformal_scores(probs, y)
    w = decay_weights(t_days, tau_days, half_life_days)
    return ConformalResult(qhat=weighted_conformal_quantile(scores, w, alpha), n=int(scores.size), alpha=alpha,
                           n_eff=effective_sample_size(w))


# --------------------------------------------------------------------------------------------- temperature scaling
def fit_temperature(log_probs: np.ndarray, y: np.ndarray, max_iter: int = 200) -> float:
    """Fit a single temperature on held-out data by minimising NLL of ``softmax(logits / T)``.

    ``log_probs`` may be logits or log-probabilities (softmax is invariant to per-row additive constants).
    """
    import torch

    z = torch.as_tensor(np.asarray(log_probs, dtype=np.float64))
    z = torch.nan_to_num(z, neginf=-1e4)
    t = torch.as_tensor(np.asarray(y, dtype=np.int64))
    log_t = torch.zeros(1, dtype=torch.float64, requires_grad=True)
    opt = torch.optim.LBFGS([log_t], lr=0.1, max_iter=max_iter, line_search_fn="strong_wolfe")

    def closure():
        opt.zero_grad()
        loss = torch.nn.functional.cross_entropy(z / log_t.exp(), t)
        loss.backward()
        return loss

    opt.step(closure)
    return float(log_t.exp().item())


def apply_temperature(log_probs: np.ndarray, temperature: float) -> np.ndarray:
    z = np.nan_to_num(np.asarray(log_probs, dtype=np.float64), neginf=-1e4) / float(temperature)
    z = z - z.max(axis=1, keepdims=True)
    e = np.exp(z)
    return e / e.sum(axis=1, keepdims=True)
