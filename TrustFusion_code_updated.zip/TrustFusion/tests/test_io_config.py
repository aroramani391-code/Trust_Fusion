"""Configs must carry the manuscript's values (SPEC.md); I/O helpers round-trip."""
import numpy as np
import pytest

from trustfusion import io as tio
from trustfusion.utils import CONFIG_ROOT, load_config, sample_search_space


def cfg(path, **kw):
    return load_config(CONFIG_ROOT / path, **kw)


def test_base_config_values():
    b = cfg("base.yaml")
    assert b["seeds"] == [0, 1, 2, 3, 4] and b["split_seed"] == 2024
    assert b["tuning"]["trials"] == 20 and b["tuning"]["seed"] == 0
    assert b["training"]["patience"] == 12 and b["training"]["max_epochs"] == 80
    assert b["conformal"]["alpha"] == 0.05 and b["conformal"]["half_life_days"] == 15 and b["mc"]["T"] == 12
    assert b["metrics"]["ece_bins"] == 15 and b["metrics"]["tpr_at_fpr"] == [0.001, 0.01]
    assert b["stats"]["bootstrap_resamples"] == 10000 and len(b["stats"]["table5_comparisons"]) == 6


def test_trustfusion_configs():
    c = cfg("trustfusion/bodmas_pr.yaml")
    m, l, o = c["model"], c["loss"], c["optim"]
    assert (m["d_model"], m["coattention"]["layers"], m["coattention"]["heads"]) == (512, 2, 4)
    assert m["modality_dropout"] == 0.15 and m["head_dropout"] == 0.2 and m["pretrained"] is True
    assert (l["beta"], l["gamma"], l["lambda_cal"], l["lambda_align"], l["cal_bins"]) == (0.999, 2.0, 0.35, 0.10, 15)
    assert (o["lr"], o["weight_decay"], o["batch_size"], o["schedule"]) == (3e-4, 0.05, 128, "cosine")
    assert c["data"]["image"]["size"] == 224 and c["data"]["image"]["entropy_window"] == 256
    assert c["data"]["image"]["augment"]["overlay_truncation"] == {"p": 0.3, "max_fraction": 0.5}
    assert c["task"] == "family" and c["protocol"] == "pr_family"
    det = cfg("trustfusion/bodmas_pr.yaml", protocol="pr_detection")
    assert det["task"] == "detection"
    pt = cfg("trustfusion/bodmas_pt.yaml")
    assert pt["protocol"] == "pt_family" and pt["temporal"] and pt["pt"]["n_windows"] == 7
    em = cfg("trustfusion/ember2024.yaml")
    assert em["optim"]["batch_size"] == 64 and em["model"]["use_image"] is False and em["data"]["views"]["image"] == "none"
    assert em["splits"]["expected_families"] == 2358
    mn = cfg("trustfusion/malnet_tiny.yaml")
    assert mn["data"]["layout"].endswith("malnet_callgraph.yaml") and mn["optim"]["batch_size"] == 128


def test_data_configs_carry_manuscript_counts():
    """Section 4.1 / Table 2 counts asserted by make_splits.py --check-counts."""
    bo = cfg("data/bodmas.yaml")
    assert bo["splits"]["expected_benign_sources"] == {"win10": 11368, "win11": 9527, "repo": 3285}
    assert sum(bo["splits"]["expected_benign_sources"].values()) == bo["splits"]["expected_benign"] == 24180
    assert bo["pt"]["expected_named_families"] == 68
    em = cfg("data/ember2024.yaml")["splits"]
    fam, det, off = em["expected_family"], em["expected_detection"], em["expected_official"]
    assert fam == {"train_official": 1101898, "test_official": 254284}
    # the family subset holds malicious files only, so it must stay below the official split sizes
    assert fam["train_official"] < off["train"] and fam["test_official"] < off["test"]
    assert det == {"train_official": 2340000, "test_official": 540000}
    mn = cfg("data/malnet_tiny.yaml")["splits"]
    assert mn["expected_graph_unmatched"] == 1286 and mn["benign_source_name"] == "googleplay" and mn["expected_benign"] == 5000


@pytest.mark.parametrize("name,selected,space", [
    ("byte_cnn", {"optim.lr": 3e-4, "optim.weight_decay": 0.05, "optim.batch_size": 128},
     {"optim.lr": [1e-4, 3e-4, 1e-3], "optim.weight_decay": [0.01, 0.05]}),
    ("msvit", {"optim.lr": 1e-4, "optim.batch_size": 64, "model.consistency": 0.1},
     {"optim.lr": [5e-5, 1e-4, 3e-4], "model.consistency": [0.05, 0.1, 0.2]}),
    ("lgbm_static", {"model.num_leaves": 1024, "model.learning_rate": 0.05, "model.feature_fraction": 0.5,
                     "model.bagging_fraction": 0.5, "model.bagging_freq": 1, "model.num_boost_round": 4000,
                     "model.early_stopping_rounds": 100},
     {"model.num_leaves": [256, 512, 1024, 2048], "model.learning_rate": [0.03, 0.05, 0.1]}),
    ("conformal_lgbm", {"model.num_leaves": 1024}, {"model.num_leaves": [256, 512, 1024, 2048], "model.learning_rate": [0.03, 0.05, 0.1]}),
    ("feature_graph", {"model.width": 256, "model.layers": 3, "model.corr_threshold": 0.3, "optim.lr": 1e-3,
                       "optim.weight_decay": 1e-4, "optim.batch_size": 256},
     {"model.width": [128, 256], "optim.lr": [3e-4, 1e-3]}),
    ("gin_callgraph", {"model.width": 128, "model.layers": 5, "optim.lr": 1e-3, "optim.batch_size": 64, "optim.name": "adam"},
     {"model.width": [64, 128], "optim.lr": [3e-4, 1e-3]}),
    ("late_fusion", {"model.C": 1.0}, {"model.C": [0.1, 1.0, 10.0]}),
    ("cross_attention", {"optim.lr": 1e-4, "optim.batch_size": 64, "model.heads": 4, "model.backbone": "convnext_tiny"},
     {"optim.lr": [5e-5, 1e-4, 3e-4]}),
    ("mcdropout_cnn", {"model.head_dropout": 0.3, "mc.T": 12}, {"model.head_dropout": [0.1, 0.2, 0.3, 0.5]}),
])
def test_baseline_configs(name, selected, space):
    from trustfusion.utils import get_by_dotted

    c = cfg(f"baselines/{name}.yaml", corpus="bodmas")
    for k, v in selected.items():
        assert get_by_dotted(c, k) == v, k
    assert c["search_space"] == space
    assert c["training"]["patience"] == 12 and c["training"]["max_epochs"] == 80


def test_late_fusion_malnet_includes_gin():
    assert cfg("baselines/late_fusion.yaml", corpus="malnet_tiny")["base_methods"] == ["byte_cnn", "lgbm_static", "gin_callgraph"]
    assert cfg("baselines/late_fusion.yaml", corpus="bodmas")["base_methods"] == ["byte_cnn", "lgbm_static"]


def test_sample_search_space_distinct_and_deterministic():
    space = {"a": [1, 2, 3], "b": [0.1, 0.2]}
    d1 = sample_search_space(space, 20, 0)
    assert len(d1) == 6 and len({tuple(sorted(d.items())) for d in d1}) == 6
    assert d1 == sample_search_space(space, 20, 0)
    big = {"x": list(range(10)), "y": list(range(10))}
    assert len(sample_search_space(big, 20, 0)) == 20


@pytest.mark.parametrize("pyarrow", [True, False])
def test_prediction_writer_roundtrip(tmp_path, monkeypatch, pyarrow):
    if pyarrow and not tio._has_pyarrow():
        pytest.skip("pyarrow not installed")
    if not pyarrow:
        monkeypatch.setattr(tio, "_has_pyarrow", lambda: False)
    n = 5
    df = tio.prediction_frame(n, sample_id=[f"s{i}" for i in range(n)], corpus="synthetic", task="family", protocol="p",
                              split="test", window="", seed=0, method="m", y_true=np.arange(n), y_pred=np.arange(n),
                              p_max=np.full(n, 0.5), p_true=np.full(n, 0.5), entropy=np.zeros(n), mutual_info=np.zeros(n),
                              gate=np.full(n, np.nan), set_size=np.ones(n, int), in_set=np.ones(n, bool),
                              accepted=np.ones(n, bool), benign_source="", timestamp="")
    assert list(df.columns) == tio.PREDICTION_COLUMNS
    path = tio.write_predictions(df, tmp_path)
    assert path.suffix == (".parquet" if pyarrow else ".gz")
    back = tio.read_predictions(tmp_path)
    assert list(back.columns) == tio.PREDICTION_COLUMNS and len(back) == n
    np.testing.assert_array_equal(back["y_true"].to_numpy(), np.arange(n))
    tio.write_probs(tmp_path, np.full((n, 3), 1 / 3), df["sample_id"].to_numpy())
    assert tio.read_npz(tmp_path / "probs.npz")["p_bar"].shape == (n, 3)


def test_json_infinity_roundtrip(tmp_path):
    tio.write_json(tmp_path / "c.json", {"qhat": float("inf")})
    assert tio.json_float(tio.read_json(tmp_path / "c.json")["qhat"]) == float("inf")
