#!/usr/bin/env python
"""Train the non-neural methods: LightGBM (``lgbm_static``, ``conformal_lgbm``) and the late-fusion stacker.

Writes ``runs/<corpus>/<protocol>/<method>/seed<k>/{model.txt | stacker.pkl, config.yaml, train_info.json,
inference/{val,cal,test}.npz}``. The late-fusion stacker reads the base runs' inference files for the same seed.

Examples::

    python scripts/train_gbdt.py --config configs/baselines/lgbm_static.yaml --corpus bodmas
    python scripts/train_gbdt.py --config configs/baselines/conformal_lgbm.yaml --corpus ember2024
    python scripts/train_gbdt.py --config configs/baselines/late_fusion.yaml --corpus malnet_tiny
"""
from __future__ import annotations

import argparse
import pickle
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402

from trustfusion.cli import add_config_args, add_path_args, add_seed_args, load_cfg, seeds_from  # noqa: E402
from trustfusion.io import run_dir, write_json  # noqa: E402
from trustfusion.metrics import macro_f1  # noqa: E402
from trustfusion.models import method_kind  # noqa: E402
from trustfusion.models.baselines import LateFusionStacker, LightGBMModel  # noqa: E402
from trustfusion.training import (_meta_arrays, build_context, load_inference, probs_summary, save_inference,  # noqa: E402
                                  subsample_train, take_rows)
from trustfusion.utils import get_logger, save_config, seed_everything  # noqa: E402

log = get_logger("train_gbdt")
SPLITS = ("val", "cal", "test")


def fit_lightgbm(ctx, cfg) -> dict:
    X = ctx.corpus.static
    rows = {s: ctx.rows(s) for s in ("train",) + SPLITS}
    task = cfg.get("task", "family")
    model_cfg = dict(cfg.get("model", {}))
    cw = model_cfg.get("class_weight_family") if task == "family" else None
    m = LightGBMModel(ctx.num_classes, model_cfg, seed=ctx.seed, class_weight=cw, num_threads=int(model_cfg.get("num_threads", 0)))
    t0 = time.time()
    m.fit(take_rows(X, rows["train"]["row"].to_numpy()), rows["train"]["label"].to_numpy(),
          take_rows(X, rows["val"]["row"].to_numpy()), rows["val"]["label"].to_numpy())
    m.save(ctx.run_dir)
    val_f1 = float("nan")
    for split in SPLITS:
        if rows[split].empty:
            continue
        p = m.predict_proba(take_rows(X, rows[split]["row"].to_numpy()))
        if split == "val":
            val_f1 = macro_f1(rows[split]["label"].to_numpy(), p.argmax(1))
        save_inference(ctx.run_dir, split, {**_meta_arrays(ctx, rows[split]), **probs_summary(p)}, T=1, mc=False)
    return {"best_iteration": m.best_iteration, "val_macro_f1": val_f1, "wall_time_s": time.time() - t0}


def fit_stacker(ctx, cfg, runs_root: str) -> dict:
    bases = list(cfg["base_methods"])
    inf = {b: {s: load_inference(run_dir(runs_root, cfg["corpus"], cfg["protocol"], b, ctx.seed), s) for s in SPLITS}
           for b in bases}
    for s in SPLITS:
        ids = [inf[b][s]["sample_id"] for b in bases]
        if any(not np.array_equal(ids[0], i) for i in ids[1:]):
            raise SystemExit(f"base runs are not aligned on split {s}")
    val = inf[bases[0]]["val"]
    st = LateFusionStacker(ctx.num_classes, C=float(cfg["model"]["C"]), max_iter=int(cfg["model"].get("max_iter", 2000)), seed=ctx.seed)
    st.fit([inf[b]["val"]["p_bar"] for b in bases], val["label"])
    with open(ctx.run_dir / "stacker.pkl", "wb") as f:
        pickle.dump(st, f)
    out = {}
    for s in SPLITS:
        p = st.predict_proba([inf[b][s]["p_bar"] for b in bases])
        ref = inf[bases[0]][s]
        meta = {k: ref[k] for k in ("sample_id", "row", "label", "window", "benign_source", "timestamp")}
        save_inference(ctx.run_dir, s, {**meta, **probs_summary(p)}, T=1, mc=False)
        if s == "val":
            out["val_macro_f1_in_sample"] = macro_f1(ref["label"], p.argmax(1))
    out["base_methods"] = bases
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_config_args(ap)
    add_path_args(ap)
    add_seed_args(ap)
    ap.add_argument("--method-name", default=None)
    ap.add_argument("--train-subsample", type=float, default=None)
    args = ap.parse_args()
    cfg = load_cfg(args)
    kind = method_kind(cfg["method"])
    if kind not in ("gbdt", "stacker"):
        raise SystemExit(f"{cfg['method']} is a torch method; use scripts/train.py")
    if cfg.get("corpora") and cfg["corpus"] not in cfg["corpora"]:
        raise SystemExit(f"{cfg['method']} is not defined for corpus {cfg['corpus']}")
    if cfg["corpus"] == "malnet_tiny" and cfg.get("task") == "detection" and not cfg.get("data", {}).get("benign_source"):
        raise SystemExit("MalNet-Tiny detection needs an explicit benign source: --set data.benign_source=<name>")
    for seed in seeds_from(args, cfg):
        seed_everything(seed)
        ctx = build_context(cfg, args.data_root, args.splits, args.runs, seed, args.method_name, args.device)
        if args.train_subsample:
            subsample_train(ctx, args.train_subsample)
        ctx.run_dir.mkdir(parents=True, exist_ok=True)
        save_config(cfg, ctx.run_dir / "config.yaml")
        info = fit_lightgbm(ctx, cfg) if kind == "gbdt" else fit_stacker(ctx, cfg, args.runs)
        write_json(ctx.run_dir / "train_info.json", info)
        log.info("%s seed %d: %s", cfg["method"], seed, info)


if __name__ == "__main__":
    main()
