"""Shared fixtures. All data here is SYNTHETIC and only exercises the code paths."""
from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pytest
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from trustfusion.data.static_features import synthetic_layout  # noqa: E402
from trustfusion.models import build_torch_model  # noqa: E402

TINY_MODEL = {"backbone": "tiny", "pretrained": False, "d_model": 32,
              "coattention": {"layers": 2, "heads": 4, "ffn_mult": 2}, "head_dropout": 0.2, "modality_dropout": 0.15}


@pytest.fixture(autouse=True)
def _seed():
    torch.manual_seed(0)
    np.random.seed(0)
    yield


@pytest.fixture
def layout():
    return synthetic_layout(64, 8)


@pytest.fixture
def tiny_cfg():
    return {"method": "trustfusion", "data": {"image": {"size": 32}}, "model": dict(TINY_MODEL)}


@pytest.fixture
def tiny_model(tiny_cfg, layout):
    torch.manual_seed(0)
    return build_torch_model(tiny_cfg, 5, layout.group_indices(), layout.dim)


def make_batch(B: int = 6, C: int = 5, size: int = 32, dim: int = 64, image: bool = True, static: bool = True):
    g = torch.Generator().manual_seed(1)
    return {
        "image": torch.rand(B, 3, size, size, generator=g) if image else torch.zeros(B, 0),
        "static": torch.randn(B, dim, generator=g) if static else torch.zeros(B, 0),
        "has_image": torch.full((B,), image, dtype=torch.bool),
        "has_static": torch.full((B,), static, dtype=torch.bool),
        "label": torch.randint(0, C, (B,), generator=g),
    }


@pytest.fixture
def batch():
    return make_batch()
