"""Per-sample prediction files, probability matrices, checkpoints and JSON helpers.

Output layout (SPEC §7)::

    runs/<corpus>/<protocol>/<method>/seed<k>/
        best.pt                    checkpoint (torch methods) / model.txt (LightGBM)
        inference/{val,cal,test}.npz  raw model outputs (MC and deterministic head)
        calibration.json           conformal threshold (and optional temperature)
        predictions.parquet        per-sample predictions (csv.gz if pyarrow is unavailable)
        probs.npz                  full probability matrix aligned with predictions
        metrics.json
"""
from __future__ import annotations

import importlib.util
import json
import os
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

PREDICTION_COLUMNS: list[str] = [
    "sample_id", "corpus", "task", "protocol", "split", "window", "seed", "method",
    "y_true", "y_pred", "p_max", "p_true", "entropy", "mutual_info", "gate",
    "set_size", "in_set", "accepted", "benign_source", "timestamp",
]

_DTYPES: dict[str, str] = {
    "sample_id": "string", "corpus": "string", "task": "string", "protocol": "string", "split": "string",
    "window": "string", "seed": "int64", "method": "string", "y_true": "int64", "y_pred": "int64",
    "p_max": "float64", "p_true": "float64", "entropy": "float64", "mutual_info": "float64",
    "gate": "float64", "set_size": "int64", "in_set": "boolean", "accepted": "boolean",
    "benign_source": "string", "timestamp": "string",
}


def _has_pyarrow() -> bool:
    return importlib.util.find_spec("pyarrow") is not None


def run_dir(runs_root: str | os.PathLike, corpus: str, protocol: str, method: str, seed: int) -> Path:
    return Path(runs_root) / corpus / protocol / method / f"seed{seed}"


def prediction_frame(n: int, **columns: Any) -> pd.DataFrame:
    """Build a prediction DataFrame with the canonical column order and dtypes.

    Scalars are broadcast; missing columns are filled with ``<NA>``.
    """
    extra = set(columns) - set(PREDICTION_COLUMNS)
    if extra:
        raise KeyError(f"unknown prediction columns: {sorted(extra)}")
    data = {}
    for col in PREDICTION_COLUMNS:
        val = columns.get(col, None)
        dtype = _DTYPES[col]
        if val is None:
            data[col] = pd.array([pd.NA] * n, dtype=dtype)
            continue
        if np.isscalar(val) or isinstance(val, str):
            val = [val] * n
        if dtype == "string":
            data[col] = pd.array([None if _is_missing(v) else str(v) for v in val], dtype="string")
        else:
            data[col] = pd.array(np.asarray(val), dtype=dtype)
        if len(data[col]) != n:
            raise ValueError(f"column {col} has length {len(data[col])}, expected {n}")
    return pd.DataFrame(data, columns=PREDICTION_COLUMNS)


def _is_missing(v: Any) -> bool:
    if v is None or v is pd.NA:
        return True
    return isinstance(v, float) and np.isnan(v)


def write_predictions(df: pd.DataFrame, out_dir: str | os.PathLike, name: str = "predictions") -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    missing = [c for c in PREDICTION_COLUMNS if c not in df.columns]
    if missing:
        raise KeyError(f"prediction frame lacks columns {missing}")
    if _has_pyarrow():
        path = out_dir / f"{name}.parquet"
        df.to_parquet(path, index=False)
    else:
        path = out_dir / f"{name}.csv.gz"
        df.to_csv(path, index=False, compression="gzip")
    return path


def find_predictions(run: str | os.PathLike, name: str = "predictions") -> Path | None:
    run = Path(run)
    for ext in (".parquet", ".csv.gz"):
        p = run / f"{name}{ext}"
        if p.exists():
            return p
    return None


def read_predictions(path: str | os.PathLike, name: str = "predictions") -> pd.DataFrame:
    path = Path(path)
    if path.is_dir():
        found = find_predictions(path, name)
        if found is None:
            raise FileNotFoundError(f"no {name}.parquet / {name}.csv.gz in {path}")
        path = found
    if path.suffix == ".parquet":
        return pd.read_parquet(path)
    df = pd.read_csv(path, dtype={"sample_id": str, "window": str, "benign_source": str, "timestamp": str})
    return df


def write_probs(out_dir: str | os.PathLike, p_bar: np.ndarray, sample_id: np.ndarray, name: str = "probs",
                dtype: str = "float32", **extra: np.ndarray) -> Path:
    """Save the full probability matrix (rows aligned with the prediction file)."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{name}.npz"
    arrays = {"p_bar": np.asarray(p_bar, dtype=dtype), "sample_id": np.asarray(sample_id).astype(str)}
    arrays.update({k: np.asarray(v) for k, v in extra.items() if v is not None})
    np.savez_compressed(path, **arrays)
    return path


def read_npz(path: str | os.PathLike) -> dict[str, np.ndarray]:
    with np.load(path, allow_pickle=False) as f:
        return {k: f[k] for k in f.files}


# --------------------------------------------------------------------------------------------- json
def _json_default(o: Any) -> Any:
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, (np.floating,)):
        return None if not np.isfinite(o) else float(o)
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    raise TypeError(f"not JSON serialisable: {type(o)}")


def _sanitize(o: Any) -> Any:
    if isinstance(o, float) and not np.isfinite(o):
        return "inf" if o > 0 else ("-inf" if o < 0 else None)
    if isinstance(o, Mapping):
        return {str(k): _sanitize(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_sanitize(v) for v in o]
    if isinstance(o, np.floating):
        return _sanitize(float(o))
    return o


def write_json(path: str | os.PathLike, obj: Any) -> Path:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf8") as f:
        json.dump(_sanitize(obj), f, indent=2, default=_json_default)
        f.write("\n")
    return path


def read_json(path: str | os.PathLike) -> Any:
    with open(path, "r", encoding="utf8") as f:
        return json.load(f)


def json_float(v: Any) -> float:
    """Inverse of the ``inf`` sanitisation used by :func:`write_json`."""
    if v in ("inf", "+inf"):
        return float("inf")
    if v == "-inf":
        return float("-inf")
    return float("nan") if v is None else float(v)


def update_json(path: str | os.PathLike, updates: Mapping[str, Any]) -> dict[str, Any]:
    """Merge ``updates`` into a JSON object on disk (created if missing)."""
    from .utils import deep_update

    path = Path(path)
    current = read_json(path) if path.exists() else {}
    merged = deep_update(current, updates)
    write_json(path, merged)
    return dict(merged)


# --------------------------------------------------------------------------------------------- checkpoints
def save_checkpoint(path: str | os.PathLike, model: Any, cfg: Mapping[str, Any], **extra: Any) -> Path:
    import torch

    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    state = {"state_dict": model.state_dict(), "config": dict(cfg)}
    state.update(extra)
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(state, tmp)
    os.replace(tmp, path)
    return path


def load_checkpoint(path: str | os.PathLike, map_location: str = "cpu") -> dict[str, Any]:
    import torch

    return torch.load(path, map_location=map_location, weights_only=False)
