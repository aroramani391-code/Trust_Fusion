"""Seed-level tables and figure data computed from per-sample prediction files (used by ``seed_stats.py`` and
``aggregate_results.py``). Nothing here contains results: every number is recomputed from ``runs/`` and ``results/``.
"""
from __future__ import annotations

import math
import warnings
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
import pandas as pd

from .io import find_predictions, read_npz, read_predictions, run_dir
from .metrics import ece_from_confidence, macro_f1, reliability_bins, roc_auc, roc_on_grid, tpr_at_fpr
from .stats import format_interval, format_p, holm, mean_sd, paired_bootstrap, paired_ttest, t_interval

#: metrics reported in percent
PERCENT_METRICS = {"accuracy", "macro_f1", "ece", "coverage", "acceptance", "roc_auc", "tpr@fpr=0.001", "tpr@fpr=0.01",
                   "pt_loss", "accepted_error"}


def is_percent(metric: str) -> bool:
    return metric in PERCENT_METRICS or metric.startswith("selective_error@") or metric.startswith("macro_f1@")


# --------------------------------------------------------------------------------------------- loading
def load_columns(run: str | Path, name: str = "predictions", probs_name: str = "probs") -> dict[str, np.ndarray] | None:
    """Per-sample arrays of a run (sorted by sample_id); ``score`` = P(malicious) for binary tasks."""
    run = Path(run)
    if find_predictions(run, name) is None:
        return None
    df = read_predictions(run, name)
    order = np.argsort(df["sample_id"].astype(str).to_numpy(), kind="stable")
    df = df.iloc[order].reset_index(drop=True)
    cols = {
        "sample_id": df["sample_id"].astype(str).to_numpy(),
        "y_true": df["y_true"].to_numpy(dtype=np.int64), "y_pred": df["y_pred"].to_numpy(dtype=np.int64),
        "p_max": df["p_max"].to_numpy(dtype=np.float64),
        "in_set": df["in_set"].fillna(False).to_numpy(dtype=bool), "accepted": df["accepted"].fillna(False).to_numpy(dtype=bool),
        "set_size": df["set_size"].fillna(-1).to_numpy(dtype=np.float64),
        "window": df["window"].fillna("").astype(str).to_numpy(),
        "benign_source": df["benign_source"].fillna("").astype(str).to_numpy(),
    }
    cols["correct"] = cols["y_true"] == cols["y_pred"]
    probs_path = run / f"{probs_name}.npz"
    if probs_path.exists():
        pz = read_npz(probs_path)
        sid = pz["sample_id"].astype(str)
        pos = pd.Series(np.arange(sid.size), index=sid)
        p = pz["p_bar"][pos.loc[cols["sample_id"]].to_numpy()]
        cols["probs"] = p
        if p.shape[1] == 2:
            cols["score"] = p[:, 1].astype(np.float64)
    return cols


def metric_value(metric: str, cols: Mapping[str, np.ndarray], idx: np.ndarray | None = None) -> float:
    idx = np.arange(cols["y_true"].size) if idx is None else idx
    y, yp = cols["y_true"][idx], cols["y_pred"][idx]
    if metric == "accuracy":
        return float((y == yp).mean())
    if metric == "macro_f1":
        return macro_f1(y, yp)
    if metric.startswith("macro_f1@"):
        w = cols["window"][idx] == metric.split("@", 1)[1]
        return macro_f1(y[w], yp[w]) if w.any() else float("nan")
    if metric == "pt_loss":
        w = cols["window"][idx]
        return macro_f1(y[w == "W1"], yp[w == "W1"]) - macro_f1(y[w == "W7"], yp[w == "W7"])
    if metric == "ece":
        return ece_from_confidence(cols["p_max"][idx], cols["correct"][idx])
    if metric.startswith("selective_error@"):
        c = float(metric.split("@", 1)[1])
        conf, corr = cols["p_max"][idx], cols["correct"][idx]
        k = int(math.ceil(c * conf.size - 1e-9))
        top = np.argsort(-conf, kind="stable")[:k]
        return float(1.0 - corr[top].mean()) if k else float("nan")
    if metric == "coverage":
        return float(cols["in_set"][idx].mean())
    if metric == "mean_set_size":
        return float(cols["set_size"][idx].mean())
    if metric == "acceptance":
        return float(cols["accepted"][idx].mean())
    if metric == "accepted_error":
        a = cols["accepted"][idx]
        return float((~cols["correct"][idx][a]).mean()) if a.any() else float("nan")
    if metric == "roc_auc":
        return roc_auc(y, cols["score"][idx])
    if metric.startswith("tpr@fpr="):
        f = float(metric.split("=", 1)[1])
        return tpr_at_fpr(y, cols["score"][idx], [f])[f]
    raise KeyError(f"unknown metric {metric!r}")


def available_seeds(runs_root: str | Path, corpus: str, protocol: str, method: str, name: str = "predictions") -> list[int]:
    d = Path(runs_root) / corpus / protocol / method
    return sorted(int(p.name[4:]) for p in d.glob("seed*") if find_predictions(p, name) is not None)


# --------------------------------------------------------------------------------------------- seed tables
def per_seed_table(runs_root: str | Path, corpus: str, protocol: str, methods: Sequence[str], metrics: Sequence[str],
                   seeds: Sequence[int] | None = None, name: str = "predictions") -> pd.DataFrame:
    rows = []
    for method in methods:
        use = seeds if seeds is not None else available_seeds(runs_root, corpus, protocol, method, name)
        for s in use:
            cols = load_columns(run_dir(runs_root, corpus, protocol, method, s), name)
            if cols is None:
                warnings.warn(f"missing predictions: {corpus}/{protocol}/{method}/seed{s}")
                continue
            for m in metrics:
                try:
                    v = metric_value(m, cols)
                except KeyError:
                    v = float("nan")
                rows.append({"corpus": corpus, "protocol": protocol, "method": method, "seed": s, "metric": m, "value": v})
    return pd.DataFrame(rows, columns=["corpus", "protocol", "method", "seed", "metric", "value"])


def summarize(per_seed: pd.DataFrame, digits: int = 2) -> pd.DataFrame:
    rows = []
    if per_seed.empty:
        return pd.DataFrame(columns=["corpus", "protocol", "method", "metric", "n_seeds", "mean", "sd", "formatted"])
    for (corpus, protocol, method, metric), g in per_seed.groupby(["corpus", "protocol", "method", "metric"], sort=False):
        scale = 100.0 if is_percent(metric) else 1.0
        vals = g["value"].dropna().to_numpy() * scale
        m, s = mean_sd(vals)
        rows.append({"corpus": corpus, "protocol": protocol, "method": method, "metric": metric, "n_seeds": int(vals.size),
                     "mean": m, "sd": s, "formatted": f"{m:.{digits}f} ± {s:.{digits}f}" if vals.size else ""})
    return pd.DataFrame(rows)


def paired_comparisons(runs_root: str | Path, comparisons: Sequence[Mapping[str, Any]], seeds: Sequence[int] | None = None,
                       n_resamples: int = 10_000, confidence: float = 0.95, boot_seed: int = 2024,
                       name: str = "predictions") -> pd.DataFrame:
    """Table 5: paired t-test / t-interval over seeds, paired bootstrap over test samples, Holm over all rows.

    ``t_ci`` and ``p_holm_formatted`` reproduce the manuscript's columns (interval to two decimals; Holm-corrected p as
    ``"< 0.001"`` below 0.001). Both come from the same seed differences, so the reported p always agrees with the
    reported interval.
    """
    rows = []
    for comp in comparisons:
        corpus, protocol, metric, a, b = comp["corpus"], comp["protocol"], comp["metric"], comp["a"], comp["b"]
        sa = set(available_seeds(runs_root, corpus, protocol, a, name))
        sb = set(available_seeds(runs_root, corpus, protocol, b, name))
        use = sorted((sa & sb) if seeds is None else (sa & sb & set(seeds)))
        base = {"comparison": comp.get("name", f"{corpus}_{metric}_{a}_vs_{b}"), "corpus": corpus, "protocol": protocol,
                "metric": metric, "method_a": a, "method_b": b, "n_seeds": len(use)}
        if len(use) < 2:
            warnings.warn(f"comparison {base['comparison']}: fewer than two paired seeds available")
            rows.append({**base, "p_ttest": float("nan")})
            continue
        ca = [load_columns(run_dir(runs_root, corpus, protocol, a, s), name) for s in use]
        cb = [load_columns(run_dir(runs_root, corpus, protocol, b, s), name) for s in use]
        for x, y in zip(ca, cb):
            if not np.array_equal(x["sample_id"], y["sample_id"]):
                raise ValueError(f"{base['comparison']}: methods were evaluated on different samples")
        scale = 100.0 if is_percent(metric) else 1.0
        va = np.array([metric_value(metric, c) for c in ca]) * scale
        vb = np.array([metric_value(metric, c) for c in cb]) * scale
        t, p = paired_ttest(va, vb)
        md, lo, hi = t_interval(va - vb, confidence)
        strata = ca[0]["window"] if metric == "pt_loss" else None
        boot = paired_bootstrap(ca, cb, lambda c, i: metric_value(metric, c, i), n_resamples, boot_seed, confidence, strata)
        rows.append({**base, "mean_a": va.mean(), "sd_a": va.std(ddof=1), "mean_b": vb.mean(), "sd_b": vb.std(ddof=1),
                     "mean_diff": md, "t_ci_low": lo, "t_ci_high": hi, "t_stat": t, "p_ttest": p,
                     "boot_diff": boot["diff"] * scale, "boot_ci_low": boot["ci_low"] * scale,
                     "boot_ci_high": boot["ci_high"] * scale, "p_bootstrap": boot["p_value"], "n_resamples": n_resamples})
    df = pd.DataFrame(rows)
    if not df.empty:
        ok = df["p_ttest"].notna()
        df["p_holm"] = np.nan
        if ok.any():
            df.loc[ok, "p_holm"] = holm(df.loc[ok, "p_ttest"].to_numpy())
        if "t_ci_low" in df:
            df["t_ci"] = [format_interval(lo, hi) for lo, hi in zip(df["t_ci_low"], df["t_ci_high"])]
        df["p_holm_formatted"] = [format_p(p) for p in df["p_holm"]]
    return df


# --------------------------------------------------------------------------------------------- figure data
def _seed_cols(runs_root: str | Path, corpus: str, protocol: str, method: str, name: str = "predictions") -> list[dict]:
    return [c for c in (load_columns(run_dir(runs_root, corpus, protocol, method, s), name)
                        for s in available_seeds(runs_root, corpus, protocol, method, name)) if c is not None]


def roc_figure(runs_root: str | Path, roc_cfg: Mapping[str, Any], labels: Mapping[str, str], corpus_labels: Mapping[str, str],
               grid: np.ndarray) -> pd.DataFrame | None:
    rows = []
    for corpus, spec in roc_cfg.items():
        for method in spec["methods"]:
            seeds = _seed_cols(runs_root, corpus, spec["protocol"], method)
            if not seeds or any("score" not in c for c in seeds):
                warnings.warn(f"ROC figure: missing detection predictions for {corpus}/{method}")
                return None
            tpr = np.mean([roc_on_grid(c["y_true"], c["score"], grid) for c in seeds], axis=0)
            rows += [{"corpus": corpus_labels[corpus], "method": labels[method], "fpr": f"{f:.6g}", "tpr": round(float(t), 4)}
                     for f, t in zip(grid, tpr)]
    return pd.DataFrame(rows)


def reliability_figure(runs_root: str | Path, corpus: str, rel_cfg: Mapping[str, Any], n_bins: int = 15) -> pd.DataFrame | None:
    out = pd.DataFrame({"bin_center": np.round((np.arange(n_bins) + 0.5) / n_bins, 4)})
    for series in rel_cfg["series"]:
        seeds = _seed_cols(runs_root, corpus, rel_cfg["protocol"], series["method"])
        if not seeds or any("probs" not in c for c in seeds):
            warnings.warn(f"reliability figure: missing predictions for {series['method']}")
            return None
        accs = np.array([reliability_bins(c["probs"], c["y_true"], n_bins)["accuracy"] for c in seeds])
        eces = [100 * ece_from_confidence(c["p_max"], c["correct"], n_bins) for c in seeds]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", RuntimeWarning)
            acc = np.nanmean(accs, axis=0)
        out[f"{series['label']} (ECE {np.mean(eces):.2f}%)"] = np.round(acc, 3)
    return out


def risk_coverage_figure(runs_root: str | Path, rc_cfg: Mapping[str, Any], corpus_labels: Mapping[str, str],
                         coverages: Sequence[float]) -> pd.DataFrame | None:
    rows = []
    for corpus, spec in rc_cfg.items():
        for model, method in (("TrustFusion", "trustfusion"), ("uncalibrated baseline", spec["baseline"])):
            seeds = _seed_cols(runs_root, corpus, spec["protocol"], method)
            if not seeds:
                warnings.warn(f"risk-coverage figure: missing predictions for {corpus}/{method}")
                return None
            row = {"corpus": corpus_labels[corpus], "model": model}
            for c in coverages:
                row[f"cov{int(round(c * 100))}"] = round(100 * float(np.mean([metric_value(f"selective_error@{c:g}", s) for s in seeds])), 2)
            rows.append(row)
    return pd.DataFrame(rows)


def temporal_figure(runs_root: str | Path, corpus: str, t_cfg: Mapping[str, Any], labels: Mapping[str, str],
                    n_windows: int = 7) -> pd.DataFrame | None:
    rows = []
    for method in t_cfg["methods"]:
        seeds = _seed_cols(runs_root, corpus, t_cfg["protocol"], method)
        if not seeds:
            warnings.warn(f"temporal figure: missing P-T predictions for {method}")
            return None
        row = {"method": labels[method]}
        for k in range(1, n_windows + 1):
            row[f"W{k}"] = round(100 * float(np.mean([metric_value(f"macro_f1@W{k}", s) for s in seeds])), 1)
        rows.append(row)
    return pd.DataFrame(rows)


def mean_over_seeds(df: pd.DataFrame, keys: Sequence[str], value: str) -> pd.DataFrame:
    return df.groupby(list(keys), sort=False)[value].mean().reset_index()


def iter_existing(paths: Iterable[Path]) -> list[Path]:
    return [p for p in paths if p.exists()]
