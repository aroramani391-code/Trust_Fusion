#!/usr/bin/env python
"""Create SYNTHETIC data for tests and the smoke test (random numbers only; never used for reported results).

* ``--out DIR``: a tiny BODMAS-like processed corpus at ``DIR/processed/bodmas`` (minimal PE binaries with
  class-dependent byte statistics, random EMBER-layout vectors, timestamps Aug 2019 - Sep 2020, benign sources).
* ``--predictions-out DIR``: synthetic per-sample prediction files for two synthetic methods and three seeds under
  ``DIR/synthetic/<protocol>/<method>/seed<k>/`` (for exercising scripts/seed_stats.py).
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from trustfusion.data.datasets import make_synthetic_corpus, make_synthetic_predictions  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("make_synthetic")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--out", default=None)
    ap.add_argument("--predictions-out", default=None)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()
    if args.out is None and args.predictions_out is None:
        raise SystemExit("pass --out and/or --predictions-out")
    if args.out:
        path = make_synthetic_corpus(Path(args.out) / "processed" / "bodmas", seed=args.seed)
        log.info("synthetic corpus: %s", path)
    if args.predictions_out:
        path = make_synthetic_predictions(args.predictions_out, seed=args.seed)
        log.info("synthetic predictions: %s", path)


if __name__ == "__main__":
    main()
