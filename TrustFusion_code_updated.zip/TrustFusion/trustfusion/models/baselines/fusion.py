"""Fusion baselines (SPEC §4).

* ``late_fusion``: multinomial logistic-regression stacker (C = 1) fitted on the validation-split probabilities of
  the byte-image CNN and LightGBM (MalNet: + structural GIN).
* ``cross_attention``: ConvNeXt-T (ImageNet-1k) image tokens + a 2 x 512 MLP on the static vector, one
  cross-attention layer (4 heads) in the image -> static direction (the static token queries the image tokens),
  and a head on the concatenation ``[mean image token; attended static token]``.
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn

from ..base import ClassifierBase
from ..image_encoder import build_backbone


class LateFusionStacker:
    def __init__(self, num_classes: int, C: float = 1.0, max_iter: int = 2000, seed: int = 0):
        self.num_classes = int(num_classes)
        self.C = float(C)
        self.max_iter = int(max_iter)
        self.seed = int(seed)
        self.clf = None

    @staticmethod
    def stack(prob_list: Sequence[np.ndarray]) -> np.ndarray:
        return np.hstack([np.asarray(p, dtype=np.float64) for p in prob_list])

    def fit(self, prob_list: Sequence[np.ndarray], y: np.ndarray) -> "LateFusionStacker":
        from sklearn.linear_model import LogisticRegression

        self.clf = LogisticRegression(C=self.C, max_iter=self.max_iter, random_state=self.seed)
        self.clf.fit(self.stack(prob_list), np.asarray(y))
        return self

    def predict_proba(self, prob_list: Sequence[np.ndarray]) -> np.ndarray:
        p = self.clf.predict_proba(self.stack(prob_list))
        out = np.zeros((p.shape[0], self.num_classes))
        out[:, self.clf.classes_.astype(int)] = p
        return out


class CrossAttentionFusion(ClassifierBase):
    def __init__(self, num_classes: int, static_dim: int, model_cfg: Mapping[str, Any]):
        super().__init__()
        d = int(model_cfg.get("d_model", 512))
        self.backbone, ch = build_backbone(str(model_cfg.get("backbone", "convnext_tiny")), bool(model_cfg.get("pretrained", False)))
        self.img_proj = nn.Linear(ch, d)
        hidden = int(model_cfg.get("static_hidden", 512))
        self.static_mlp = nn.Sequential(nn.Linear(static_dim, hidden), nn.GELU(), nn.Linear(hidden, d), nn.GELU())
        self.attn = nn.MultiheadAttention(d, int(model_cfg.get("heads", 4)), batch_first=True)
        self.norm = nn.LayerNorm(d)
        self.head_dropout_p = float(model_cfg.get("head_dropout", 0.0))
        self.head = nn.Linear(2 * d, num_classes)

    def features(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:
        A = self.backbone(batch["image"])
        v = self.img_proj(A.flatten(2).transpose(1, 2))
        s = self.static_mlp(batch["static"]).unsqueeze(1)
        s_att, _ = self.attn(s, v, v, need_weights=False)
        s = self.norm(s + s_att)[:, 0]
        return {"z": torch.cat([v.mean(1), s], dim=-1), "A": A}
