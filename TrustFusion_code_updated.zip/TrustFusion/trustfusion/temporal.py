"""Chronological deployment loop for the P-T protocol (SPEC §1, §3).

The network, gate and head are frozen after training (no retraining): the loop only consumes the frozen model's
predictions ``p_bar`` for the calibration pool D1 and the test windows W1..W7.

For window ``W_k`` with start ``tau_k``:

* ``mode='sliding'`` (weighted conformal): the calibration pool is ``D_1 = D1`` for ``k = 1`` and, for ``k >= 2``,
  the labelled samples first seen in ``W_{k-1-d}`` (``d = label_delay_months``; pools before W1 fall back to D1,
  the fit period is never used). Weights ``w_i = 2^{-(tau_k - t_i)/h}``, ``h = 15`` days.
* ``mode='static'``: the unweighted split-conformal threshold of D1, computed once and reused for every window.

``q_hat_k`` is computed once at ``tau_k`` and frozen during ``W_k``. Leakage assertions: calibration and test
indices are disjoint, every calibration timestamp precedes ``tau_k``, the pool's labels have been released (pool
end + d months <= tau_k for k >= 2), and no fit/validation sample is used for calibration.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Mapping, Sequence

import numpy as np
import pandas as pd

from .conformal import (calibrate_split, conformal_scores, decay_weights, effective_sample_size,
                        prediction_sets, weighted_conformal_quantile)
from .metrics import accuracy, ece, macro_f1

DAY_NS = 86_400 * 10**9


def to_days(ts: Sequence | np.ndarray | pd.Series) -> np.ndarray:
    """Timestamps (strings with or without a UTC offset, or datetimes) -> float days since the epoch (naive UTC)."""
    s = pd.Series(ts)
    if not pd.api.types.is_datetime64_any_dtype(s):
        s = pd.to_datetime(s.astype(str), utc=True, format="mixed").dt.tz_localize(None)
    elif getattr(s.dt, "tz", None) is not None:
        s = s.dt.tz_convert("UTC").dt.tz_localize(None)
    return s.to_numpy(dtype="datetime64[ns]").astype(np.int64) / DAY_NS


@dataclass
class DeploymentResult:
    windows: pd.DataFrame
    samples: pd.DataFrame
    calibration_indices: dict[str, np.ndarray] = field(default_factory=dict)


def calibration_pool(k: int, label_delay_months: int = 0) -> str:
    """Name of the calibration pool used for ``W_k`` in sliding mode (``'D1'`` or ``'W<j>'``)."""
    if k <= 1:
        return "D1"
    j = k - 1 - int(label_delay_months)
    return "D1" if j < 1 else f"W{j}"


def run_deployment(p_bar: np.ndarray, y: np.ndarray, timestamps: Sequence, window_labels: Sequence[str],
                   window_bounds: Mapping[str, tuple[pd.Timestamp, pd.Timestamp]], alpha: float = 0.05,
                   half_life_days: float = 15.0, mode: str = "sliding", label_delay_months: int = 0,
                   excluded_mask: np.ndarray | None = None, n_bins: int = 15) -> DeploymentResult:
    """Run the frozen-model deployment over W1..Wn.

    ``window_labels[i]`` is ``'D1'``, ``'W1'``..``'Wn'`` (anything else is ignored); ``excluded_mask`` marks samples
    that must never be used for calibration (fit / validation samples).
    """
    if mode not in ("sliding", "static"):
        raise ValueError(mode)
    p_bar = np.asarray(p_bar, dtype=np.float64)
    y = np.asarray(y, dtype=np.int64)
    labels = np.asarray(window_labels).astype(str)
    days = to_days(timestamps)
    n_windows = sum(1 for k in window_bounds if k.startswith("W"))
    pred = p_bar.argmax(axis=1)
    excluded = np.zeros(len(y), bool) if excluded_mask is None else np.asarray(excluded_mask, bool)

    static = None
    if mode == "static":
        d1 = np.flatnonzero(labels == "D1")
        static = calibrate_split(p_bar[d1], y[d1], alpha)

    rows, sample_frames, cal_used = [], [], {}
    for k in range(1, n_windows + 1):
        wk = f"W{k}"
        tau = pd.Timestamp(window_bounds[wk][0])
        tau_days = float(to_days([tau])[0])
        test_idx = np.flatnonzero(labels == wk)
        pool = "D1" if mode == "static" else calibration_pool(k, label_delay_months)
        cal_idx = np.flatnonzero(labels == pool)
        # ---- leakage assertions -------------------------------------------------------------
        assert np.intersect1d(cal_idx, test_idx).size == 0, f"{wk}: calibration overlaps the current window"
        assert cal_idx.size == 0 or days[cal_idx].max() < tau_days, f"{wk}: calibration sample at/after tau_k"
        assert not excluded[cal_idx].any(), f"{wk}: fit/validation sample used for calibration"
        if mode == "sliding" and k >= 2 and pool != "D1":
            release = pd.Timestamp(window_bounds[pool][1]) + pd.DateOffset(months=int(label_delay_months))
            assert release <= tau, f"{wk}: labels of {pool} not yet released at tau_k"
        # ---- threshold at tau_k, frozen during W_k -------------------------------------------
        if mode == "static":
            qhat, n_eff = static.qhat, float(static.n)
        else:
            scores = conformal_scores(p_bar[cal_idx], y[cal_idx])
            w = decay_weights(days[cal_idx], tau_days, half_life_days)
            qhat = weighted_conformal_quantile(scores, w, alpha)
            n_eff = effective_sample_size(w)
        cal_used[wk] = cal_idx
        sets = prediction_sets(p_bar[test_idx], qhat)
        sizes = sets.sum(axis=1)
        in_set = sets[np.arange(test_idx.size), y[test_idx]] if test_idx.size else np.zeros(0, bool)
        accepted = sizes == 1
        rows.append({
            "window": wk, "tau": str(tau.date()), "mode": mode, "calibration_pool": pool,
            "label_delay_months": int(label_delay_months), "n_cal": int(cal_idx.size), "n_eff": n_eff, "qhat": qhat,
            "n_test": int(test_idx.size),
            "accuracy": accuracy(y[test_idx], pred[test_idx]), "macro_f1": macro_f1(y[test_idx], pred[test_idx]),
            "ece": ece(p_bar[test_idx], y[test_idx], n_bins) if test_idx.size else float("nan"),
            "coverage": float(in_set.mean()) if test_idx.size else float("nan"),
            "mean_set_size": float(sizes.mean()) if test_idx.size else float("nan"),
            "acceptance": float(accepted.mean()) if test_idx.size else float("nan"),
            "accepted_error": float((pred[test_idx][accepted] != y[test_idx][accepted]).mean()) if accepted.any() else float("nan"),
        })
        sample_frames.append(pd.DataFrame({"index": test_idx, "window": wk, "qhat": qhat, "set_size": sizes,
                                           "in_set": in_set, "accepted": accepted, "y_pred": pred[test_idx]}))
    samples = pd.concat(sample_frames, ignore_index=True) if sample_frames else pd.DataFrame()
    return DeploymentResult(windows=pd.DataFrame(rows), samples=samples, calibration_indices=cal_used)
