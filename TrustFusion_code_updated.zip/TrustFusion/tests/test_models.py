import numpy as np
import pytest
import torch

from conftest import make_batch
from trustfusion.data.datasets import collate_graphs
from trustfusion.data.static_features import load_layout
from trustfusion.losses import CrossEntropyCriterion, TrustFusionLoss
from trustfusion.models import build_torch_model
from trustfusion.models.baselines import LateFusionStacker, LightGBMModel, pearson_adjacency


def test_trustfusion_forward_shapes(tiny_model, batch):
    tiny_model.train()
    out = tiny_model(batch)
    assert out["logits"].shape == (6, 5)
    assert out["A"].shape == (6, 64, 4, 4)
    assert out["v_tokens"].shape == (6, 16, 32) and out["s_tokens"].shape == (6, 8, 32)
    assert ((out["gate"] > 0) & (out["gate"] < 1)).all()
    loss, logs = tiny_model.compute_loss(batch, out, TrustFusionLoss(np.array([5, 4, 3, 2, 1]), {}))
    loss.backward()
    assert np.isfinite(logs["loss"]) and {"cls", "cal", "align"} <= set(logs)


def test_mc_predict_is_head_only(tiny_model, batch):
    calls, outputs = [], []

    def hook(_m, _inp, out):
        calls.append(1)
        outputs.append(out[1].detach().clone() if isinstance(out, tuple) else out.detach().clone())

    h1 = tiny_model.image_encoder.register_forward_hook(hook)
    h2 = tiny_model.set_encoder.register_forward_hook(hook)
    r1 = tiny_model.mc_predict(batch, T=12)
    assert len(calls) == 2, "encoders must run exactly once per mc_predict call (z_f cached)"
    r2 = tiny_model.mc_predict(batch, T=12)
    h1.remove()
    h2.remove()
    assert torch.equal(outputs[0], outputs[2]) and torch.equal(outputs[1], outputs[3]), "encoder outputs differ across passes"
    assert torch.equal(r1["z"], r2["z"])
    assert r1["probs"].shape == (12, 6, 5)
    assert (r1["probs"][0] - r1["probs"][1]).abs().max() > 1e-6, "head dropout must make MC passes differ"
    torch.testing.assert_close(r1["p_bar"], r1["probs"].mean(0))
    assert (r1["mutual_info"] >= 0).all() and (r1["entropy"] >= r1["mutual_info"] - 1e-6).all()
    det = tiny_model.mc_predict(batch, T=12, mc=False)
    assert det["probs"].shape == (1, 6, 5) and torch.all(det["mutual_info"] == 0)
    torch.testing.assert_close(det["p_bar"], det["p_det"])


def test_modality_dropout_never_both(tiny_model):
    B = 4000
    batch = make_batch(B=B)
    with torch.no_grad():
        enc = tiny_model.encode(batch, modality_dropout=True)
    kv, ks = enc["keep_v"], enc["keep_s"]
    assert not bool((~kv & ~ks).any())
    assert abs((~kv).float().mean().item() - 0.15) < 0.03 and abs((~ks).float().mean().item() - 0.15) < 0.03
    masked = ~kv
    assert torch.allclose(enc["v_tokens"][masked], tiny_model.mask_token_v.expand_as(enc["v_tokens"])[masked])


def test_missing_views_use_mask_tokens(tiny_model):
    b = make_batch(B=3, image=False)
    out = tiny_model.mc_predict(b, T=4)
    assert out["p_bar"].shape == (3, 5)
    b2 = make_batch(B=3)
    b2["has_static"] = torch.tensor([True, False, True])
    with torch.no_grad():
        enc = tiny_model.encode(b2)
    assert torch.allclose(enc["s_tokens"][1], tiny_model.mask_token_s.expand(1, 8, 32)[0])


@pytest.mark.parametrize("override", [{"fusion": "concat"}, {"use_image": False}, {"use_static": False}, {"modality_dropout": 0.0}])
def test_ablation_variants(tiny_cfg, layout, batch, override):
    cfg = dict(tiny_cfg, model={**tiny_cfg["model"], **override})
    m = build_torch_model(cfg, 5, layout.group_indices(), layout.dim)
    m.train()
    out = m(batch)
    loss, _ = m.compute_loss(batch, out, TrustFusionLoss(np.ones(5), {"type": "ce"}))
    loss.backward()
    assert m.mc_predict(batch, T=3)["p_bar"].shape == (6, 5)


def test_resnet50_encoder_tokens():
    lay = load_layout("bodmas_ember_v2")
    cfg = {"method": "trustfusion", "data": {"image": {"size": 224}}, "model": {"backbone": "resnet50", "pretrained": False}}
    m = build_torch_model(cfg, 97, lay.group_indices(), lay.dim).eval()
    b = make_batch(B=1, C=97, size=224, dim=2381)
    with torch.no_grad():
        enc = m.encode(b)
    assert enc["A"].shape == (1, 2048, 7, 7)
    assert enc["v_tokens"].shape == (1, 49, 512) and enc["s_tokens"].shape == (1, 8, 512)
    assert m.head.in_features == 512 and m.head_dropout_p == 0.2


def _train_step(model, batch, criterion=None):
    model.train()
    out = model(batch)
    loss, _ = model.compute_loss(batch, out, criterion or CrossEntropyCriterion())
    loss.backward()
    assert torch.isfinite(loss)
    return model.mc_predict(batch, T=4, mc=True)


def test_image_baselines(batch):
    for method, extra in (("byte_cnn", {}), ("mcdropout_cnn", {"head_dropout": 0.3}),
                          ("cross_attention", {"static_hidden": 16}),
                          ("msvit", {"scales": [16, 32], "vit": {"use_timm": False, "patch": 8, "dim": 32, "depth": 1, "heads": 2, "base_grid": 4}})):
        cfg = {"method": method, "data": {"image": {"size": 32}}, "model": {"backbone": "tiny", "pretrained": False, "d_model": 32, **extra}}
        m = build_torch_model(cfg, 5, None, 64)
        r = _train_step(m, batch)
        assert r["p_bar"].shape == (6, 5)
        if method == "mcdropout_cnn":
            assert (r["probs"][0] - r["probs"][1]).abs().max() > 0


def test_feature_graph_gcn(layout, batch):
    X = np.random.default_rng(0).normal(size=(200, layout.dim))
    X[:, :16] += X[:, 16:32]  # correlate two groups
    A = pearson_adjacency(X, layout.group_indices(), 0.3)
    assert A.shape == (9, 9) and np.allclose(A, A.T) and np.all(np.diag(A) == 0)
    m = build_torch_model({"method": "feature_graph", "model": {"width": 16}}, 5, layout.group_indices(), layout.dim, A)
    assert _train_step(m, batch)["p_bar"].shape == (6, 5)


def test_structural_gin():
    rng = np.random.default_rng(0)
    items = []
    for g in range(3):
        n = int(rng.integers(3, 9))
        e = torch.as_tensor(rng.integers(0, n, size=(2, 2 * n)), dtype=torch.long)
        items.append({"x": torch.rand(n, 5), "edge_index": e, "label": g % 2, "index": g})
    batch = collate_graphs(items)
    m = build_torch_model({"method": "gin_callgraph", "model": {"width": 8, "layers": 5}}, 2)
    assert _train_step(m, batch)["p_bar"].shape == (3, 2)


def test_lightgbm_and_stacker(tmp_path):
    rng = np.random.default_rng(0)
    X = rng.normal(size=(300, 12)).astype(np.float32)
    y = (X[:, 0] + 0.5 * X[:, 1] > 0).astype(int) + (X[:, 2] > 1).astype(int)
    cfg = {"num_leaves": 7, "num_boost_round": 30, "early_stopping_rounds": 5, "min_data_in_leaf": 5}
    m = LightGBMModel(3, cfg, seed=0, class_weight="balanced", num_threads=1).fit(X[:200], y[:200], X[200:], y[200:])
    p = m.predict_proba(X[200:])
    assert p.shape == (100, 3) and np.allclose(p.sum(1), 1)
    m.save(tmp_path)
    np.testing.assert_allclose(LightGBMModel.load(tmp_path).predict_proba(X[200:]), p, rtol=1e-6)
    b = LightGBMModel(2, cfg, seed=0).fit(X[:200], (y[:200] > 0).astype(int), X[200:], (y[200:] > 0).astype(int))
    assert b.predict_proba(X[:5]).shape == (5, 2)
    st = LateFusionStacker(4, C=1.0).fit([p, p[:, ::-1]], y[200:])  # class 3 absent from the validation labels
    q = st.predict_proba([p, p[:, ::-1]])
    assert q.shape == (100, 4) and np.allclose(q.sum(1), 1) and np.all(q[:, 3] == 0)
