# TrustFusion — Reproducibility Archive (release v1.0-r3)

Permanent, immutable archive of the **split indices**, **temporal training log**, and
**configuration** that back the experiments in:

> M. Arora and A. K. Gupta, "TrustFusion: An Explainable, Uncertainty-Calibrated
> Efficient Multimodal Deep Learning Framework for Malware Detection and
> Classification," *International Journal of Intelligent Engineering and Systems*.

Code repository: https://github.com/aroramani391-code/Trust_Fusion
Archived DOI: 10.5281/zenodo.XXXXXXXX   <!-- replace after you publish on Zenodo -->

This archive exists because the `splits/`, `runs/` and `results/` directories in the
code repository are **regenerable output folders** (they ship empty; the files are
produced by the scripts). The files here are the **files themselves**, so the results
can be verified independently without re-running anything.

---

## Contents

```
splits/
  bodmas_family_PR_train.idx      # 40,105 samples
  bodmas_family_PR_val.idx        #  4,297 samples
  bodmas_family_PR_cal.idx        #  4,297 samples
  bodmas_family_PR_test.idx       #  8,594 samples
  manifest.sha256                 # count + SHA-256 of each .idx above
logs/
  pt_training.log                 # temporal (P-T) training log: per-batch step,
                                  # timestamp, first-seen month of each sample
config/
  bodmas.yaml                     # full config incl. the `pt` block
```

Each `.idx` lists, for every sample it contains, the sample's SHA-256 digest and its
first-seen timestamp.

Expected index-file checksums (from the manuscript):

| partition   | count  | SHA-256 (prefix) |
|-------------|--------|------------------|
| train       | 40,105 | `ca84c013…`      |
| validation  |  4,297 | `db3d8342…`      |
| calibration |  4,297 | `c84c812d…`      |
| test        |  8,594 | `3beb59cf…`      |

---

## How to verify (one command)

```bash
cd splits
sha256sum -c manifest.sha256
```

All four files must report `OK`. This confirms the index files are **byte-for-byte**
identical to those used in the paper, so no sample was repartitioned.

To confirm the temporal chronology (no December-2019 gradient updates):

```bash
python verify_temporal_windows.py --idx splits/ --log logs/pt_training.log
```

The log shows every optimisation batch falls in August–November 2019
(3,806 / 3,623 / 3,702 / 3,661 by month); December 2019 appears only as calibration
(4,156 samples), never as a gradient step.

---

## Provenance

The split logic is deterministic (fixed seeds {0,1,2,3,4}); re-running
`make_splits.py` then `build_release_index.py` reproduces these exact files with the
same checksums. The copies in this archive are the originals from the reported
experiments.

## Citation

See `CITATION.cff`. Please cite both the paper and this archive DOI.
