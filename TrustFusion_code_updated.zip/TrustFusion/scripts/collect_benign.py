#!/usr/bin/env python
"""Collect the benign PE pool manifest (sha256, source, path) from local directories.

Scans each ``--root DIR:SOURCE`` recursively (e.g. a mounted Windows 10 installation as ``win10``, a Windows 11
installation as ``win11``, and a folder of installers / portable software downloaded from software repositories as
``repo``), keeps files that parse as PE (``MZ`` header with a valid ``PE\\0\\0`` signature), de-duplicates by sha256
(first occurrence wins, in the order of ``--root``) and writes ``manifest.csv`` plus a sha256-only index for release.
Files are only read, never copied or uploaded.

Example::

    python scripts/collect_benign.py --root /mnt/win10:win10 --root /mnt/win11:win11 --root /data/repo:repo \
        --out raw/benign
"""
from __future__ import annotations

import argparse
import hashlib
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from trustfusion.data.byte_image import parse_pe  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("collect_benign")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--root", action="append", required=True, metavar="DIR:SOURCE")
    ap.add_argument("--out", default="raw/benign")
    ap.add_argument("--max-size-mb", type=float, default=None, help="skip files larger than this (default: no limit)")
    args = ap.parse_args()
    seen: set[str] = set()
    rows = []
    for spec in args.root:
        root, _, source = spec.rpartition(":")
        if not root or not source:
            raise SystemExit(f"--root must look like DIR:SOURCE, got {spec!r}")
        for dirpath, _dirs, files in os.walk(root):
            for name in files:
                p = Path(dirpath) / name
                try:
                    if not p.is_file() or (args.max_size_mb and p.stat().st_size > args.max_size_mb * 2**20):
                        continue
                    data = p.read_bytes()
                except OSError:
                    continue
                if parse_pe(data) is None:
                    continue
                sha = hashlib.sha256(data).hexdigest()
                if sha in seen:
                    continue
                seen.add(sha)
                rows.append({"sha256": sha, "source": source, "path": str(p), "size": len(data)})
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    df = pd.DataFrame(rows, columns=["sha256", "source", "path", "size"])
    df.to_csv(out / "manifest.csv", index=False)
    df[["sha256", "source"]].to_csv(out / "sha256_index.csv", index=False)
    log.info("%d unique PE files: %s", len(df), df["source"].value_counts().to_dict())


if __name__ == "__main__":
    main()
