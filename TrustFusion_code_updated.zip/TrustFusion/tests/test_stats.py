import numpy as np
import pytest
from scipy import stats as sps

from trustfusion import stats as S
from trustfusion.metrics import macro_f1


def test_mean_sd_and_format():
    v = [0.8694, 0.8712, 0.8650, 0.8701, 0.8688]
    m, s = S.mean_sd(v)
    assert m == pytest.approx(np.mean(v)) and s == pytest.approx(np.std(v, ddof=1))
    assert S.format_mean_sd(v).startswith(f"{100 * np.mean(v):.2f} ± ")


def test_paired_ttest_and_interval_match_scipy():
    rng = np.random.default_rng(0)
    a = rng.normal(0.85, 0.01, 5)
    b = a - rng.normal(0.02, 0.005, 5)
    t, p = S.paired_ttest(a, b)
    ref = sps.ttest_rel(a, b)
    assert t == pytest.approx(ref.statistic) and p == pytest.approx(ref.pvalue)
    d = a - b
    m, lo, hi = S.t_interval(d, 0.95)
    rlo, rhi = sps.t.interval(0.95, df=4, loc=d.mean(), scale=sps.sem(d))
    assert (m, lo, hi) == pytest.approx((d.mean(), rlo, rhi))


def test_p_from_t_interval_matches_ttest():
    rng = np.random.default_rng(1)
    for _ in range(20):
        a = rng.normal(0.85, 0.01, 5)
        b = a - rng.normal(rng.uniform(-0.01, 0.03), rng.uniform(0.002, 0.01), 5)
        d = 100 * (a - b)
        m, lo, hi = S.t_interval(d, 0.95)
        t, p = S.p_from_t_interval(m, lo, hi, n=5)
        ref = sps.ttest_rel(100 * a, 100 * b)
        assert t == pytest.approx(ref.statistic, rel=1e-9) and p == pytest.approx(ref.pvalue, rel=1e-7)
    # an interval that excludes zero by several half-widths cannot carry a p-value of the order of 0.01
    t, p = S.p_from_t_interval(4.0, 3.5, 4.5, n=5)
    assert t == pytest.approx(22.2116, abs=1e-3) and p < 1e-4
    assert S.holm([p] * 6).max() < 1e-3


def test_format_p_and_interval():
    assert S.format_p(0.00014) == "< 0.001" and S.format_p(0.0009999) == "< 0.001"
    assert S.format_p(0.001) == "0.001" and S.format_p(0.0172) == "0.017" and S.format_p(float("nan")) == ""
    assert S.format_interval(3.789, 4.951) == "[3.79, 4.95]" and S.format_interval(float("nan"), 1.0) == ""


def test_holm_known_values():
    adj = S.holm([0.01, 0.04, 0.03, 0.005])
    np.testing.assert_allclose(adj, [0.03, 0.06, 0.06, 0.02])
    assert np.all(S.holm([0.5, 0.9, 0.7]) <= 1.0)


def test_paired_bootstrap():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 4, 400)
    good = [{"y_true": y, "y_pred": np.where(rng.random(400) < 0.9, y, rng.integers(0, 4, 400))} for _ in range(3)]
    bad = [{"y_true": y, "y_pred": np.where(rng.random(400) < 0.5, y, rng.integers(0, 4, 400))} for _ in range(3)]
    metric = lambda c, i: macro_f1(c["y_true"][i], c["y_pred"][i])  # noqa: E731
    same = S.paired_bootstrap(good, good, metric, n_resamples=300)
    assert same["diff"] == 0 and same["ci_low"] == 0 and same["ci_high"] == 0 and same["p_value"] == 1.0
    res = S.paired_bootstrap(good, bad, metric, n_resamples=300)
    assert res["ci_low"] > 0 and res["p_value"] < 0.01
    strata = np.repeat(["W1", "W7"], 200)
    res2 = S.paired_bootstrap(good, bad, metric, n_resamples=100, strata=strata)
    assert res2["ci_low"] > 0
