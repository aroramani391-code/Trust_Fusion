"""Argument helpers shared by ``scripts/*.py``."""
from __future__ import annotations

import argparse
import importlib
from pathlib import Path
from typing import Any, Callable

from .utils import load_config


def add_config_args(p: argparse.ArgumentParser, required: bool = True) -> None:
    p.add_argument("--config", required=required, help="method config (configs/trustfusion/*.yaml, configs/baselines/*.yaml)")
    p.add_argument("--corpus", help="bodmas | ember2024 | malnet_tiny (default: the config's corpus)")
    p.add_argument("--protocol", help="protocol name from configs/data/<corpus>.yaml (default: the config's protocol)")
    p.add_argument("--overlay", action="append", default=[], help="extra YAML merged on top (repeatable)")
    p.add_argument("--set", dest="overrides", action="append", default=[], metavar="KEY=VALUE",
                   help="dotted override, e.g. --set optim.lr=1e-4 (repeatable)")


def add_path_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--data-root", default=None, help="directory containing processed corpora (default: config data.processed_dir)")
    p.add_argument("--splits", default="splits", help="split directory (default: splits)")
    p.add_argument("--runs", default="runs", help="run directory root (default: runs)")
    p.add_argument("--device", default=None, help="cpu | cuda | cuda:0 (default: auto)")


def add_seed_args(p: argparse.ArgumentParser) -> None:
    p.add_argument("--seeds", type=int, nargs="+", default=None, help="seeds (default: config seeds [0..4])")


def load_cfg(args: argparse.Namespace) -> dict[str, Any]:
    return load_config(args.config, corpus=args.corpus, protocol=args.protocol, overlays=args.overlay,
                       overrides=args.overrides)


def seeds_from(args: argparse.Namespace, cfg: dict[str, Any]) -> list[int]:
    return list(args.seeds) if args.seeds is not None else list(cfg.get("seeds", [0, 1, 2, 3, 4]))


def import_callable(spec: str) -> Callable[..., Any]:
    """Import ``package.module:function``."""
    module, _, name = spec.partition(":")
    if not name:
        raise ValueError("expected module:function")
    return getattr(importlib.import_module(module), name)


def run_dirs(paths: list[str]) -> list[Path]:
    out = []
    for p in paths:
        path = Path(p)
        if path.name.startswith("seed"):
            out.append(path)
        else:
            out.extend(sorted(d for d in path.glob("seed*") if d.is_dir()))
    return out
