"""The nine baselines of Table 4 (SPEC §4)."""
from .byte_cnn import ByteImageCNN
from .fusion import CrossAttentionFusion, LateFusionStacker
from .gbdt import LightGBMModel
from .graph import FeatureGraphGCN, StructuralGIN, pearson_adjacency
from .msvit import MultiScaleViT

__all__ = ["ByteImageCNN", "CrossAttentionFusion", "LateFusionStacker", "LightGBMModel", "FeatureGraphGCN",
           "StructuralGIN", "pearson_adjacency", "MultiScaleViT"]
