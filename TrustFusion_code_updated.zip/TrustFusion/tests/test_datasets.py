import numpy as np
import pandas as pd
import pytest
import torch
from PIL import Image

from trustfusion.data.datasets import (BODMASDataset, CallGraphDataset, EMBER2024Dataset, MalNetTinyDataset,
                                       collate_graphs, load_corpus, make_synthetic_corpus, write_corpus)
from trustfusion.data.static_features import descriptor_from_edgelist
from trustfusion.evaluation import require_detection_benign_source


def split_frame(n: int) -> pd.DataFrame:
    return pd.DataFrame({"row": np.arange(n), "sample_id": [f"s{i}" for i in range(n)], "split": "train",
                         "window": "", "label": np.arange(n) % 2})


def test_bodmas_dataset_views_and_augmentation(tmp_path):
    corpus = load_corpus(make_synthetic_corpus(tmp_path / "bodmas", n_families=2, per_family=(5, 5), n_rare_families=1,
                                               n_benign_per_source=1))
    rows = pd.DataFrame({"row": [0, 1], "sample_id": corpus.meta["sample_id"][:2], "split": "train", "window": "", "label": [0, 1]})
    cfg = {"image": {"size": 32, "augment": {"entropy_jitter": [0.95, 1.05], "overlay_truncation": {"p": 1.0, "max_fraction": 0.5}}},
           "views": {"image": "bytes", "static": "vector"}}
    ds = BODMASDataset(corpus, rows, cfg, train=True)
    item = ds[0]
    assert item["image"].shape == (3, 32, 32) and item["static"].shape == (2381,)
    assert item["has_image"] and item["has_static"] and item["label"] == 0


def test_render_cache_is_exact(tmp_path):
    corpus = load_corpus(make_synthetic_corpus(tmp_path / "bodmas", n_families=2, per_family=(5, 5), n_rare_families=1,
                                               n_benign_per_source=1))
    rows = pd.DataFrame({"row": [0, 1], "sample_id": corpus.meta["sample_id"][:2], "split": "test", "window": "", "label": [0, 1]})
    plain = BODMASDataset(corpus, rows, {"image": {"size": 32}, "views": {"image": "bytes"}})
    cached = BODMASDataset(corpus, rows, {"image": {"size": 32, "cache_dir": str(tmp_path / "cache")}, "views": {"image": "bytes"}})
    first, second = cached[0]["image"], cached[0]["image"]  # write, then read back
    assert any((tmp_path / "cache").rglob("*.npy"))
    assert torch.equal(first, plain[0]["image"]) and torch.equal(second, plain[0]["image"])


def test_ember2024_dataset_is_single_stream(tmp_path):
    meta = pd.DataFrame({"sample_id": ["a", "b"], "sha256": ["a", "b"], "is_malicious": [1, 0], "has_static": 1})
    write_corpus(tmp_path / "ember", meta, np.random.rand(2, 2568).astype(np.float32), {"layout": "ember2024"})
    ds = EMBER2024Dataset(load_corpus(tmp_path / "ember"), split_frame(2), {"image": {"size": 224}, "views": {"image": "none"}})
    item = ds[1]
    assert item["image"].numel() == 0 and not item["has_image"] and item["static"].shape == (2568,)


def test_malnet_dataset_png_and_graph_masks(tmp_path):
    rng = np.random.default_rng(0)
    rows = []
    for i in range(4):
        png = tmp_path / f"img{i}.png"
        Image.fromarray(rng.integers(0, 256, size=(64, 64, 3), dtype=np.uint8)).save(png)
        graph = ""
        if i < 3:
            g = tmp_path / f"g{i}.edgelist"
            g.write_text("\n".join(f"{a} {b}" for a, b in rng.integers(0, 10, size=(15, 2))))
            graph = str(g)
        rows.append({"sample_id": f"m{i}", "sha256": f"m{i}", "family": "typeA", "is_malicious": 1, "image_path": str(png),
                     "image_kind": "png", "graph_path": graph, "has_static": int(bool(graph))})
    meta = pd.DataFrame(rows)
    static = np.stack([descriptor_from_edgelist(r["graph_path"]) if r["graph_path"] else np.zeros(48, np.float32) for r in rows])
    corpus = load_corpus(write_corpus(tmp_path / "malnet", meta, static, {"layout": "malnet_callgraph"}))
    ds = MalNetTinyDataset(corpus, split_frame(4), {"image": {"size": 32}, "views": {"image": "png", "static": "vector"}})
    items = [ds[i] for i in range(4)]
    assert all(it["image"].shape == (3, 32, 32) for it in items)
    assert [it["has_static"] for it in items] == [True, True, True, False]
    assert torch.all(items[3]["static"] == 0)
    gds = CallGraphDataset(corpus, split_frame(4))
    batch = collate_graphs([gds[i] for i in range(4)])
    assert batch["num_graphs"] == 4 and batch["x"].shape[1] == 5 and int(batch["batch"].max()) == 3


def test_malnet_detection_requires_benign_source():
    cfg = {"corpus": "malnet_tiny", "task": "detection", "data": {"benign_source": "benign"}}
    with pytest.raises(RuntimeError, match="benign-source"):
        require_detection_benign_source(cfg, None)
    with pytest.raises(RuntimeError, match="differs"):
        require_detection_benign_source(cfg, "other")
    require_detection_benign_source(cfg, "benign")
    require_detection_benign_source({"corpus": "bodmas", "task": "detection"}, None)
