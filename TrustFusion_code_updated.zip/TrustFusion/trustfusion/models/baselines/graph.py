"""Graph baselines in plain PyTorch (SPEC §4; no torch_geometric dependency).

* ``feature_graph``: 9 nodes (8 field groups + a global node); edges where ``|Pearson r| >= 0.3`` between node
  summaries on the training data (node summary = mean of the group's preprocessed features, global node = mean of
  all features); symmetric-normalised GCN (``D^-1/2 (A + I) D^-1/2``), 3 layers of width 256, mean-max readout.
* ``gin_callgraph``: 5 GIN layers of width 128 on the (symmetrised) function-call graph with local-degree-profile
  node features, sum readout over the final layer's node embeddings.
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np
import torch
import torch.nn as nn

from ..base import ClassifierBase


def node_summaries(X: np.ndarray, group_indices: Sequence[np.ndarray]) -> np.ndarray:
    X = np.asarray(X, dtype=np.float64)
    cols = [X[:, idx].mean(axis=1) for idx in group_indices] + [X.mean(axis=1)]
    return np.stack(cols, axis=1)


def pearson_adjacency(X: np.ndarray, group_indices: Sequence[np.ndarray], threshold: float = 0.3) -> np.ndarray:
    S = node_summaries(X, group_indices)
    with np.errstate(invalid="ignore", divide="ignore"):
        r = np.corrcoef(S, rowvar=False)
    r = np.nan_to_num(r, nan=0.0)
    A = (np.abs(r) >= threshold).astype(np.float32)
    np.fill_diagonal(A, 0.0)
    return A


def normalised_adjacency(A: np.ndarray) -> torch.Tensor:
    A_hat = torch.as_tensor(A, dtype=torch.float32) + torch.eye(A.shape[0])
    d = A_hat.sum(1).pow(-0.5)
    return d[:, None] * A_hat * d[None, :]


class FeatureGraphGCN(ClassifierBase):
    def __init__(self, num_classes: int, group_indices: Sequence[np.ndarray], adjacency: np.ndarray,
                 model_cfg: Mapping[str, Any], static_dim: int):
        super().__init__()
        width = int(model_cfg.get("width", 256))
        for g, idx in enumerate(group_indices):
            self.register_buffer(f"idx_{g}", torch.as_tensor(np.asarray(idx), dtype=torch.long), persistent=False)
        self.n_groups = len(group_indices)
        self.inputs = nn.ModuleList([nn.Linear(len(idx), width) for idx in group_indices] + [nn.Linear(static_dim, width)])
        self.register_buffer("adj", normalised_adjacency(np.asarray(adjacency)))
        self.layers = nn.ModuleList([nn.Linear(width, width) for _ in range(int(model_cfg.get("layers", 3)))])
        self.head_dropout_p = float(model_cfg.get("head_dropout", 0.0))
        self.head = nn.Linear(2 * width, num_classes)

    def features(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:
        x = batch["static"]
        nodes = [self.inputs[g](x.index_select(1, getattr(self, f"idx_{g}"))) for g in range(self.n_groups)]
        H = torch.stack(nodes + [self.inputs[-1](x)], dim=1)
        for layer in self.layers:
            H = torch.relu(torch.einsum("ij,bjd->bid", self.adj, layer(H)))
        return {"z": torch.cat([H.mean(1), H.max(1).values], dim=-1)}


class GINLayer(nn.Module):
    def __init__(self, d_in: int, width: int):
        super().__init__()
        self.eps = nn.Parameter(torch.zeros(1))
        self.mlp = nn.Sequential(nn.Linear(d_in, width), nn.BatchNorm1d(width), nn.ReLU(), nn.Linear(width, width), nn.ReLU())

    def forward(self, h: torch.Tensor, edge_index: torch.Tensor) -> torch.Tensor:
        src = torch.cat([edge_index[0], edge_index[1]])
        dst = torch.cat([edge_index[1], edge_index[0]])
        keep = src != dst
        agg = torch.zeros_like(h).index_add_(0, dst[keep], h[src[keep]])
        return self.mlp((1 + self.eps) * h + agg)


class StructuralGIN(ClassifierBase):
    def __init__(self, num_classes: int, model_cfg: Mapping[str, Any], in_features: int = 5):
        super().__init__()
        width = int(model_cfg.get("width", 128))
        n_layers = int(model_cfg.get("layers", 5))
        self.layers = nn.ModuleList([GINLayer(in_features if i == 0 else width, width) for i in range(n_layers)])
        self.head_dropout_p = float(model_cfg.get("head_dropout", 0.0))
        self.head = nn.Linear(width, num_classes)

    def features(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:
        h, ei, bvec = batch["x"], batch["edge_index"], batch["batch"]
        for layer in self.layers:
            h = layer(h, ei)
        n_graphs = int(batch["num_graphs"])
        z = torch.zeros(n_graphs, h.shape[1], device=h.device, dtype=h.dtype).index_add_(0, bvec, h)
        return {"z": z}
