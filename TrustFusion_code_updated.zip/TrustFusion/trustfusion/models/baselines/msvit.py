"""Multi-scale ViT baseline (SPEC §4).

ViT-S/16 (ImageNet-21k weights via ``timm`` when installed) applied to the byte image at 112 and 224 px with shared
weights; the two CLS features are combined by scale attention ``a_s = softmax_s(v^T tanh(W f_s))``. Training loss:
cross-entropy on the fused logits + ``consistency`` (0.1) x symmetric KL between the per-scale predictive
distributions. Without ``timm`` the fallback is a ViT-S/16 (depth 12, width 384, 6 heads, MLP 1536) assembled from
torchvision's ``EncoderBlock`` with bicubically interpolated position embeddings (so both 112 and 224 px inputs work);
torchvision ships no ViT-S weights, so this fallback starts from random initialisation and a warning is emitted.
"""
from __future__ import annotations

import warnings
from typing import Any, Mapping, Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F

from ..base import ClassifierBase


class PlainViT(nn.Module):
    """ViT from torchvision ``EncoderBlock`` layers returning the final CLS embedding (resizable position embeddings)."""

    def __init__(self, patch: int = 16, dim: int = 384, depth: int = 12, heads: int = 6, mlp_ratio: float = 4.0,
                 base_grid: int = 14):
        super().__init__()
        self.patch, self.dim, self.base_grid = patch, dim, base_grid
        self.patch_embed = nn.Conv2d(3, dim, patch, stride=patch)
        self.cls_token = nn.Parameter(torch.zeros(1, 1, dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, 1 + base_grid * base_grid, dim))
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)
        from functools import partial

        from torchvision.models.vision_transformer import EncoderBlock

        self.blocks = nn.Sequential(*[EncoderBlock(heads, dim, int(dim * mlp_ratio), 0.0, 0.0,
                                                   partial(nn.LayerNorm, eps=1e-6)) for _ in range(depth)])
        self.norm = nn.LayerNorm(dim, eps=1e-6)
        self.num_features = dim

    def _pos(self, gh: int, gw: int) -> torch.Tensor:
        cls, grid = self.pos_embed[:, :1], self.pos_embed[:, 1:]
        if (gh, gw) != (self.base_grid, self.base_grid):
            grid = grid.reshape(1, self.base_grid, self.base_grid, -1).permute(0, 3, 1, 2)
            grid = F.interpolate(grid, size=(gh, gw), mode="bicubic", align_corners=False)
            grid = grid.permute(0, 2, 3, 1).reshape(1, gh * gw, -1)
        return torch.cat([cls, grid], dim=1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        t = self.patch_embed(x)
        gh, gw = t.shape[-2:]
        t = t.flatten(2).transpose(1, 2)
        t = torch.cat([self.cls_token.expand(t.shape[0], -1, -1), t], dim=1) + self._pos(gh, gw)
        return self.norm(self.blocks(t))[:, 0]


def build_vit(model_cfg: Mapping[str, Any]) -> nn.Module:
    vit = dict(model_cfg.get("vit", {}))
    pretrained = bool(model_cfg.get("pretrained", False))
    if vit.get("use_timm", True):
        try:
            import timm  # type: ignore

            return timm.create_model(vit.get("timm_name", "vit_small_patch16_224.augreg_in21k"), pretrained=pretrained,
                                     num_classes=0, dynamic_img_size=True)
        except ImportError:
            pass
    if pretrained:
        warnings.warn("timm is not installed: the multi-scale ViT falls back to a randomly initialised torchvision-style "
                      "ViT-S/16 (ImageNet-21k weights unavailable). Install timm to reproduce the manuscript setting.")
    patch = int(vit.get("patch", 16))
    return PlainViT(patch=patch, dim=int(vit.get("dim", 384)), depth=int(vit.get("depth", 12)), heads=int(vit.get("heads", 6)),
                    mlp_ratio=float(vit.get("mlp_ratio", 4.0)), base_grid=int(vit.get("base_grid", 224 // patch)))


class MultiScaleViT(ClassifierBase):
    def __init__(self, num_classes: int, model_cfg: Mapping[str, Any]):
        super().__init__()
        self.vit = build_vit(model_cfg)
        dim = int(getattr(self.vit, "num_features", 384))
        self.scales: Sequence[int] = tuple(int(s) for s in model_cfg.get("scales", (112, 224)))
        self.scale_attn = nn.Sequential(nn.Linear(dim, dim), nn.Tanh(), nn.Linear(dim, 1, bias=False))
        self.consistency = float(model_cfg.get("consistency", 0.1))
        self.head_dropout_p = float(model_cfg.get("head_dropout", 0.0))
        self.head = nn.Linear(dim, num_classes)

    def features(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:
        x = batch["image"]
        feats = []
        for s in self.scales:
            xs = x if x.shape[-1] == s else F.interpolate(x, size=(s, s), mode="bilinear", align_corners=False, antialias=True)
            feats.append(self.vit(xs))
        Fs = torch.stack(feats, dim=1)
        a = torch.softmax(self.scale_attn(Fs).squeeze(-1), dim=1)
        return {"z": (a.unsqueeze(-1) * Fs).sum(1), "scale_features": Fs, "scale_weights": a}

    def compute_loss(self, batch: Mapping[str, Any], out: Mapping[str, torch.Tensor], criterion: nn.Module
                     ) -> tuple[torch.Tensor, dict[str, float]]:
        loss, logs = criterion(out["logits"], batch["label"])
        logp = [F.log_softmax(self.head(out["scale_features"][:, i]), dim=-1) for i in range(len(self.scales))]
        cons = torch.zeros((), device=loss.device)
        pairs = 0
        for i in range(len(logp)):
            for j in range(i + 1, len(logp)):
                cons = cons + 0.5 * (F.kl_div(logp[i], logp[j], log_target=True, reduction="batchmean")
                                     + F.kl_div(logp[j], logp[i], log_target=True, reduction="batchmean"))
                pairs += 1
        cons = cons / max(pairs, 1)
        total = loss + self.consistency * cons
        logs.update(consistency=float(cons.detach()), loss=float(total.detach()))
        return total, logs
