"""Deletion / insertion faithfulness of byte attributions (SPEC §6, Table 9).

Bytes are ranked by projected attribution. For each fraction ``f`` in ``0%, 5%, ..., 100%`` of the file length
(21 points) the top ``round(f |b|)`` bytes are zeroed (deletion) or copied into an all-zero file of the same
length (insertion), and the target-class probability of the deterministic head is recorded. AUC is the
trapezoidal area over ``f in [0, 1]`` and therefore lies in ``[0, 1]``.

Protocols
* ``image_view``: bytes perturbed -> image re-rendered; the static vector is kept fixed.
* ``coupled``: bytes perturbed -> image re-rendered and the descriptor re-extracted with ``extractor(bytes)``;
  a failed extraction (``None``) replaces the static view by its mask token. For MalNet
  ``graph_fn(sample_id, bytes, masked)`` recomputes the call-graph descriptor after removing methods whose code lies
  in masked ranges.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Sequence

import numpy as np
import torch

from .attribution import VARIANTS, cam_to_byte_scores, compute_cam

FRACTIONS = np.linspace(0.0, 1.0, 21)
PROTOCOLS = ("image_view", "coupled")

RenderFn = Callable[[np.ndarray], torch.Tensor]  # bytes -> normalised [C, S, S] image
Extractor = Callable[[np.ndarray], "np.ndarray | None"]  # bytes -> raw descriptor (untransformed) or None
GraphFn = Callable[[str, np.ndarray, np.ndarray], "np.ndarray | None"]  # (sample_id, bytes, masked) -> descriptor|None


def normalised_auc(fractions: Sequence[float], values: Sequence[float]) -> float:
    x = np.asarray(fractions, dtype=np.float64)
    v = np.asarray(values, dtype=np.float64)
    area = float(((v[1:] + v[:-1]) * np.diff(x)).sum() / 2.0)
    return area / float(x[-1] - x[0])


def ranking_from_scores(byte_scores: np.ndarray) -> np.ndarray:
    return np.argsort(-np.asarray(byte_scores, dtype=np.float64), kind="stable")


def perturb(data: np.ndarray, ranking: np.ndarray, fraction: float, mode: str) -> tuple[np.ndarray, np.ndarray]:
    """Return the perturbed file and the boolean mask of zero-filled (masked) positions."""
    n = data.size
    k = int(round(fraction * n))
    top = ranking[:k]
    masked = np.zeros(n, dtype=bool)
    if mode == "deletion":
        x = data.copy()
        x[top] = 0
        masked[top] = True
    elif mode == "insertion":
        x = np.zeros_like(data)
        x[top] = data[top]
        masked[:] = True
        masked[top] = False
    else:
        raise ValueError(mode)
    return x, masked


@dataclass
class FaithfulnessInputs:
    sample_id: str
    data: np.ndarray                 # raw bytes (uint8)
    static_raw: np.ndarray | None    # untransformed descriptor of the original file (image_view protocol)


class ProbabilityOracle:
    """Target-class probability of the deterministic head for batches of perturbed files."""

    def __init__(self, model: Any, render_fn: RenderFn, static_transform: Any = None, device: str | torch.device = "cpu",
                 extractor: Extractor | None = None, graph_fn: GraphFn | None = None, batch_size: int = 21):
        self.model = model
        self.render_fn = render_fn
        self.static_transform = static_transform
        self.device = torch.device(device)
        self.extractor = extractor
        self.graph_fn = graph_fn
        self.batch_size = batch_size

    def _static(self, vec: np.ndarray | None) -> tuple[torch.Tensor, bool]:
        if vec is None:
            return torch.zeros(0), False
        v = self.static_transform.transform(vec) if self.static_transform is not None else np.asarray(vec, np.float32)
        return torch.from_numpy(np.asarray(v, dtype=np.float32)), True

    def __call__(self, files: Sequence[np.ndarray], masks: Sequence[np.ndarray], protocol: str,
                 static_raw: np.ndarray | None, target: int, sample_id: str = "") -> np.ndarray:
        probs = []
        for s in range(0, len(files), self.batch_size):
            chunk = range(s, min(len(files), s + self.batch_size))
            images, statics, has_s = [], [], []
            for i in chunk:
                images.append(self.render_fn(files[i]))
                if protocol == "image_view":
                    vec = static_raw
                elif protocol == "coupled":
                    if self.graph_fn is not None:
                        vec = self.graph_fn(sample_id, files[i], masks[i])
                    elif self.extractor is not None:
                        vec = self.extractor(files[i])
                    else:
                        raise ValueError("the coupled protocol needs an extractor or graph_fn callback")
                else:
                    raise ValueError(protocol)
                t, ok = self._static(vec)
                statics.append(t)
                has_s.append(ok)
            dim = next((t.numel() for t in statics if t.numel()), 0)
            static = torch.stack([t if t.numel() else torch.zeros(dim) for t in statics]) if dim else torch.zeros(len(statics), 0)
            batch = {"image": torch.stack(images).to(self.device), "static": static.to(self.device),
                     "has_image": torch.ones(len(images), dtype=torch.bool, device=self.device),
                     "has_static": torch.tensor(has_s, dtype=torch.bool, device=self.device),
                     "label": torch.full((len(images),), int(target), dtype=torch.long, device=self.device)}
            out = self.model.mc_predict(batch, T=1, mc=False)
            probs.append(out["p_det"][:, int(target)].cpu().numpy())
        return np.concatenate(probs)


def deletion_insertion(oracle: ProbabilityOracle, inputs: FaithfulnessInputs, ranking: np.ndarray, protocol: str,
                       target: int, fractions: np.ndarray = FRACTIONS) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for mode in ("deletion", "insertion"):
        pairs = [perturb(inputs.data, ranking, float(f), mode) for f in fractions]
        curve = oracle([p[0] for p in pairs], [p[1] for p in pairs], protocol, inputs.static_raw, target, inputs.sample_id)
        out[f"{mode}_curve"] = curve
        out[f"{mode}_auc"] = normalised_auc(fractions, curve)
    return out


def evaluate_faithfulness(model: Any, samples: Sequence[FaithfulnessInputs], oracle: ProbabilityOracle,
                          variants: Sequence[str] = VARIANTS, protocols: Sequence[str] = PROTOCOLS,
                          image_size: int = 224, fractions: np.ndarray = FRACTIONS,
                          on_attribution: Callable[[FaithfulnessInputs, str, np.ndarray], None] | None = None
                          ) -> list[dict[str, Any]]:
    """Per-sample deletion / insertion AUCs for every (variant, protocol).

    ``on_attribution(sample, variant, byte_scores)`` is called with the projected byte scores of every variant.
    """
    rows = []
    for sample in samples:
        img = oracle.render_fn(sample.data)
        stat, has_s = oracle._static(sample.static_raw)
        batch = {"image": img[None].to(oracle.device),
                 "static": (stat[None] if has_s else torch.zeros(1, 0)).to(oracle.device),
                 "has_image": torch.ones(1, dtype=torch.bool, device=oracle.device),
                 "has_static": torch.tensor([has_s], device=oracle.device),
                 "label": torch.zeros(1, dtype=torch.long, device=oracle.device)}
        pred = model.mc_predict(batch, T=1, mc=False)
        target = int(pred["p_det"].argmax(dim=1)[0])
        for variant in variants:
            cam = compute_cam(model, batch, variant, target=torch.tensor([target], device=oracle.device))[0]
            byte_scores = cam_to_byte_scores(cam, sample.data.size, image_size)
            if on_attribution is not None:
                on_attribution(sample, variant, byte_scores)
            ranking = ranking_from_scores(byte_scores)
            for protocol in protocols:
                res = deletion_insertion(oracle, sample, ranking, protocol, target, fractions)
                rows.append({"sample_id": sample.sample_id, "variant": variant, "protocol": protocol, "target": target,
                             "n_bytes": int(sample.data.size), "deletion_auc": res["deletion_auc"],
                             "insertion_auc": res["insertion_auc"]})
    return rows
