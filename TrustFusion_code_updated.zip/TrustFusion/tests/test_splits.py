"""Split construction on SIMULATED label vectors with the manuscript's sizes (no real data)."""
import numpy as np
import pandas as pd
import pytest

from trustfusion.data import splits as S


def simulated_bodmas_meta(seed: int = 0, n_mal: int = 57_293, n_named: int = 96, n_small: int = 485,
                          benign: dict | None = None) -> pd.DataFrame:
    """57,293 malicious samples: 96 families with >= 25 samples + 485 small families (-> residual)."""
    rng = np.random.default_rng(seed)
    small = rng.integers(1, 25, size=n_small)
    named_total = n_mal - int(small.sum())
    named = 25 + rng.multinomial(named_total - 25 * n_named, rng.dirichlet(np.full(n_named, 0.7)))
    fams = np.concatenate([np.repeat([f"fam{i:03d}" for i in range(n_named)], named),
                           np.repeat([f"small{i:03d}" for i in range(n_small)], small)])
    rows = {"sample_id": [f"m{i}" for i in range(n_mal)], "family": fams, "is_malicious": 1, "benign_source": ""}
    df = pd.DataFrame(rows)
    if benign:
        src = np.concatenate([[k] * v for k, v in benign.items()])
        df = pd.concat([df, pd.DataFrame({"sample_id": [f"b{i}" for i in range(src.size)], "family": "",
                                          "is_malicious": 0, "benign_source": src})], ignore_index=True)
    return df


def test_pr_family_counts_97_classes():
    meta = simulated_bodmas_meta()
    df, classes, summ = S.bodmas_pr_family(meta, expected={"train": 40105, "val": 4297, "cal": 4297, "test": 8594})
    assert len(classes) == 97 and classes[-1] == "residual"
    assert S.split_counts(df) == {"train": 40105, "val": 4297, "cal": 4297, "test": 8594}
    assert not df["row"].duplicated().any()
    # stratification: class proportions in the test split track the full label distribution
    full = df["label"].value_counts(normalize=True)
    test = df.loc[df["split"] == "test", "label"].value_counts(normalize=True).reindex(full.index, fill_value=0)
    assert np.abs(full - test).max() < 0.005


def test_two_stage_split_detection_size():
    rng = np.random.default_rng(3)
    strata = rng.choice(["malicious", "benign|win10", "benign|win11", "benign|repo"], p=[0.5, 0.2, 0.2, 0.1], size=48_360)
    parts = S.two_stage_split(strata)
    assert {k: len(v) for k, v in parts.items()} == {"train": 33852, "val": 3627, "cal": 3627, "test": 7254}


def test_pr_detection_subset_counts():
    meta = simulated_bodmas_meta(benign={"win10": 9000, "win11": 9000, "repo": 6180})
    df, classes, summ = S.bodmas_pr_detection(meta, expected={"train": 33852, "val": 3627, "cal": 3627, "test": 7254})
    assert classes == ["benign", "malicious"]
    assert summ["n_malicious"] == summ["n_benign"] == 24_180
    assert summ["benign_sources"] == {"win10": 9000, "win11": 9000, "repo": 6180}
    assert (df["label"] == 1).sum() == 24_180


def test_malnet_val_halving_counts():
    rng = np.random.default_rng(0)
    parts = {"train": 61_201, "val": 8_743, "test": 17_486}
    rel = np.concatenate([[k] * v for k, v in parts.items()])
    types = rng.choice([f"type{i:02d}" for i in range(43)], size=rel.size)
    meta = pd.DataFrame({"sample_id": [f"s{i}" for i in range(rel.size)], "family": types, "is_malicious": 1,
                         "released_split": rel, "has_static": rng.integers(0, 2, rel.size), "benign_source": ""})
    df, classes, summ = S.malnet_tiny_type(meta, expected={"train": 61201, "val": 4371, "cal": 4372, "test": 17486},
                                           expected_types=43)
    assert len(classes) == 43
    unmatched = int((meta["has_static"] == 0).sum())
    assert summ["graph_unmatched"] == unmatched
    S.malnet_tiny_type(meta, expected_graph_unmatched=unmatched)
    with pytest.raises(AssertionError, match="call-graph"):
        S.malnet_tiny_type(meta, expected_graph_unmatched=unmatched + 1)
    with pytest.raises(ValueError, match="benign"):
        S.malnet_tiny_detection(meta, None)
    ben = pd.DataFrame({"sample_id": [f"g{i}" for i in range(500)], "family": "", "is_malicious": 0, "released_split": "",
                        "has_static": 1, "benign_source": "googleplay"})
    both = pd.concat([meta, ben], ignore_index=True)
    det, _, dsumm = S.malnet_tiny_detection(both, "googleplay", expected_benign=500)
    assert dsumm["benign_source"] == "googleplay" and int((det["label"] == 0).sum()) == 500
    with pytest.raises(AssertionError, match="googleplay"):
        S.malnet_tiny_detection(both, "googleplay", expected_benign=5000)


def test_pt_windows_and_label_space():
    rng = np.random.default_rng(0)
    n = 6000
    t0, t1 = pd.Timestamp("2019-08-01").value, pd.Timestamp("2020-10-01").value
    ts = pd.to_datetime(rng.integers(t0, t1, size=n))
    fam = rng.choice(["a", "b", "c"], size=n)
    fam = np.where(ts >= pd.Timestamp("2020-01-01"), np.where(rng.random(n) < 0.3, "late_only", fam), fam)
    meta = pd.DataFrame({"sample_id": [f"s{i}" for i in range(n)], "family": fam, "is_malicious": 1,
                         "timestamp": ts.astype(str), "benign_source": ""})
    df, classes, summ = S.bodmas_pt(meta, expected_named_families=3)
    assert "late_only" not in classes and classes[-1] == "residual" and summ["K"] == 4 and summ["n_named_families"] == 3
    with pytest.raises(AssertionError, match="named families"):
        S.bodmas_pt(meta, expected_named_families=4)
    assert (df["timestamp"] == meta["timestamp"].to_numpy()[df["row"]]).all()
    t = pd.to_datetime(meta["timestamp"]).to_numpy()[df["row"]]
    fit = df["window"] == "fit"
    assert (t[fit.to_numpy()] >= np.datetime64("2019-08-01")).all() and (t[fit.to_numpy()] < np.datetime64("2019-12-01")).all()
    assert set(df.loc[fit, "split"]) == {"train", "val"}
    assert abs((df["split"] == "val").sum() - 0.1 * fit.sum()) <= 3
    d1 = (df["window"] == "D1").to_numpy()
    assert (df.loc[d1, "split"] == "cal").all() and (t[d1] >= np.datetime64("2019-12-01")).all() and (t[d1] < np.datetime64("2020-01-01")).all()
    for k in range(1, 8):
        w = (df["window"] == f"W{k}").to_numpy()
        month = pd.Timestamp("2020-01-01") + pd.DateOffset(months=k - 1)
        assert (pd.DatetimeIndex(t[w]).month == month.month).all() and (df.loc[w, "split"] == "test").all()
    assert (t < np.datetime64("2020-08-01")).all()  # Aug-Sep 2020 unused
    late = df["row"].map(dict(enumerate(fam))) == "late_only"
    assert (df.loc[late, "label"] == len(classes) - 1).all()


def test_ember2024_subsets():
    rng = np.random.default_rng(0)
    n_tr, n_te = 4000, 1000
    fam_pool = [f"f{i}" for i in range(40)]
    probs = rng.dirichlet(np.ones(40) * 0.5)
    rel = np.array(["train"] * n_tr + ["test"] * n_te)
    t_tr = pd.to_datetime(rng.integers(pd.Timestamp("2023-09-24").value, pd.Timestamp("2024-09-22").value, n_tr))
    t_te = pd.to_datetime(rng.integers(pd.Timestamp("2024-09-22").value, pd.Timestamp("2024-12-15").value, n_te))
    mal = rng.random(n_tr + n_te) < 0.5
    meta = pd.DataFrame({"sample_id": [f"e{i}" for i in range(n_tr + n_te)],
                         "family": np.where(mal, rng.choice(fam_pool, size=n_tr + n_te, p=probs), ""),
                         "is_malicious": mal.astype(int), "released_split": rel,
                         "timestamp": np.concatenate([t_tr, t_te]).astype(str),
                         "file_format": rng.choice(["Win32", "Win64", "Dot_Net", "APK", "ELF", "PDF"], size=n_tr + n_te)})
    vc = meta[(rel == "train") & mal]["family"].value_counts()
    expected = int((vc >= 10).sum())
    df, fams, summ = S.ember2024_family_subset(meta, expected_families=expected)
    assert len(fams) == expected
    cal_t = pd.to_datetime(meta["timestamp"]).to_numpy()[df.loc[df["split"] == "cal", "row"]]
    assert (cal_t >= np.datetime64("2024-08-25")).all() and (cal_t < np.datetime64("2024-09-22")).all()
    assert set(meta.loc[df.loc[df["split"] == "test", "row"], "released_split"]) == {"test"}
    assert set(meta.loc[df["row"], "family"]) <= set(fams)
    with pytest.raises(AssertionError):
        S.ember2024_family_subset(meta, expected_families=expected + 1)
    # Table 2 totals: official training files (train + val + cal) and test files, bounded by the malicious files
    n_split = S.split_counts(df)
    assert summ["train_official"] == n_split["train"] + n_split["val"] + n_split["cal"] and summ["test_official"] == n_split["test"]
    assert summ["malicious_train_official"] == int(((rel == "train") & mal).sum())
    assert summ["malicious_test_official"] == int(((rel == "test") & mal).sum())
    assert summ["train_official"] <= summ["malicious_train_official"] and summ["test_official"] <= summ["malicious_test_official"]
    totals = {"train_official": summ["train_official"], "test_official": summ["test_official"]}
    S.ember2024_family_subset(meta, expected_families=expected, expected=totals)
    with pytest.raises(AssertionError, match="family subset"):
        S.ember2024_family_subset(meta, expected=dict(totals, train_official=summ["malicious_train_official"] + 1))
    det, _, dsum = S.ember2024_detection_subset(meta)
    assert set(meta.loc[det["row"], "file_format"]) == {"Win32", "Win64", "Dot_Net"}
    assert dsum["train_official"] == int(((rel == "train") & meta["file_format"].isin(["Win32", "Win64", "Dot_Net"])).sum())


def test_cross_source_split():
    meta = simulated_bodmas_meta(n_mal=3000, n_named=10, n_small=20, benign={"win10": 400, "win11": 400, "repo": 400})
    det, _, _ = S.bodmas_pr_detection(meta, min_family_size=25)
    cs, _, summ = S.bodmas_cross_source(det, meta)
    src = meta["benign_source"].to_numpy()[cs["row"]]
    ben = cs["label"].to_numpy() == 0
    fit = cs["split"].to_numpy() != "test"
    assert not np.any(ben & fit & (src == "repo"))
    assert set(src[ben & ~fit]) == {"repo"} and summ["benign_test"] == 400


def test_safe_strata_pools_singletons():
    s = S.safe_strata(["a", "a", "b", "c", "c", "d"])
    assert (pd.Series(s).value_counts() >= 2).all()


def test_split_files_carry_first_seen_timestamps(tmp_path):
    meta = simulated_bodmas_meta(n_mal=3000, n_named=10, n_small=20, benign={"win10": 300, "win11": 300, "repo": 300})
    meta["timestamp"] = pd.date_range("2019-08-01", periods=len(meta), freq="10min").astype(str)
    df, classes, _ = S.bodmas_pr_family(meta, min_family_size=25)
    assert list(df.columns) == S.SPLIT_COLUMNS and S.SPLIT_COLUMNS[-1] == "timestamp"
    S.write_split(df, classes, tmp_path, "bodmas", "pr_family")
    back, back_classes = S.read_split(tmp_path, "bodmas", "pr_family")
    assert back_classes == classes
    assert (back["timestamp"].to_numpy() == meta["timestamp"].to_numpy()[back["row"]]).all()
    assert (back["sample_id"].to_numpy() == meta["sample_id"].to_numpy()[back["row"]]).all()
    no_ts, _, _ = S.bodmas_pr_family(meta.drop(columns="timestamp"), min_family_size=25)  # e.g. MalNet: no timestamps
    assert (no_ts["timestamp"] == "").all()
    # index files written before the timestamp column existed still load
    df.drop(columns="timestamp").to_csv(tmp_path / "bodmas_pr_family.csv", index=False)
    old, _ = S.read_split(tmp_path, "bodmas", "pr_family")
    assert "timestamp" not in old.columns and len(old) == len(df)
