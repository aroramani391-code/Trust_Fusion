# How to publish this archive

1. Put your real files into splits/, logs/, config/ (see the notes in each folder)
   and delete the PUT_YOUR_FILES_HERE.txt notes.

2. Verify locally:
     cd splits && sha256sum -c manifest.sha256   # all must say OK

3. GitHub Release:
     - In your repo: Releases -> Draft a new release -> create tag "v1.0-r3"
     - Attach all files (or upload this whole zip) as release assets -> Publish
     - Permanent URL: github.com/aroramani391-code/Trust_Fusion/releases/tag/v1.0-r3

4. Zenodo DOI:
     - zenodo.org -> log in with GitHub -> Settings -> GitHub -> toggle your repo ON
     - Re-publish the GitHub release; Zenodo archives it and mints a DOI
     - (or New upload -> drag this zip -> fill metadata -> Publish)

5. Put the real DOI + tag back into:
     - README.md and CITATION.cff here
     - the manuscript (replace 10.5281/zenodo.XXXXXXXX and v1.0-r3)
   Then send the DOI to me and I'll update the .docx.
