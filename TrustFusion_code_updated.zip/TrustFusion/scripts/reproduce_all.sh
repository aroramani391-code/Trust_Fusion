#!/usr/bin/env bash
# Reproduce every table and figure of the manuscript from local data (see README.md and docs/MANUSCRIPT_MAP.md).
#
#   bash scripts/reproduce_all.sh [stage ...]
#
# Stages (default: all, in this order): prepare splits tune train calibrate evaluate temporal ablation faithfulness
# provenance stats aggregate figures. Environment variables:
#   PYTHON                 python executable (default: python)
#   SEEDS                  seeds (default: "0 1 2 3 4")
#   RAW                    directory with the locally obtained raw data (default: raw), laid out as in README.md
#   DEVICE                 cpu | cuda (default: auto)
#   MALNET_BENIGN_SOURCE   benign source for MalNet detection; the manuscript uses "googleplay" (5,000 Google Play APKs
#                          with zero VirusTotal detections, MalNet-style images in $RAW/malnet/benign); skipped when empty
#   RUN_TUNING=1           re-run the 20-trial random searches (the configs already hold the selected values)
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

PY="${PYTHON:-python}"
SEEDS="${SEEDS:-0 1 2 3 4}"
RAW="${RAW:-raw}"
MALNET_BENIGN_SOURCE="${MALNET_BENIGN_SOURCE:-}"
DEV=(); [ -n "${DEVICE:-}" ] && DEV=(--device "$DEVICE")
STAGES=("$@"); [ ${#STAGES[@]} -eq 0 ] && STAGES=(prepare splits tune train calibrate evaluate temporal ablation faithfulness provenance stats aggregate figures)

say() { printf '\n### %s\n' "$*"; }
run() { echo "+ $*"; "$@"; }

# corpus -> family / detection protocols
declare -A FAMILY=([bodmas]=pr_family [ember2024]=family_subset [malnet_tiny]=tiny_type)
declare -A DETECTION=([bodmas]=pr_detection [ember2024]=detection_subset [malnet_tiny]=tiny_detection)
TORCH_BASELINES="byte_cnn msvit feature_graph gin_callgraph cross_attention mcdropout_cnn"
PT_METHODS="trustfusion cross_attention byte_cnn mcdropout_cnn lgbm_static late_fusion"   # byte_cnn: late-fusion base

applicable() {  # method corpus -> exit status
  case "$1" in
    trustfusion|lgbm_static|conformal_lgbm|feature_graph) return 0 ;;
    gin_callgraph) [ "$2" = malnet_tiny ] ;;
    *) [ "$2" != ember2024 ] ;;   # image-based methods need binaries
  esac
}
config_for() {  # method corpus protocol
  if [ "$1" = trustfusion ]; then
    case "$2/$3" in bodmas/pt_family) echo configs/trustfusion/bodmas_pt.yaml ;; bodmas/*) echo configs/trustfusion/bodmas_pr.yaml ;;
                    *) echo "configs/trustfusion/$2.yaml" ;; esac
  else echo "configs/baselines/$1.yaml"; fi
}
extra_for() {  # corpus protocol -> extra train args
  if [ "$1/$2" = malnet_tiny/tiny_detection ]; then echo "--set data.benign_source=$MALNET_BENIGN_SOURCE"; fi
}
protocols_for() {  # corpus
  echo "${FAMILY[$1]}"
  if [ "$1" != malnet_tiny ] || [ -n "$MALNET_BENIGN_SOURCE" ]; then echo "${DETECTION[$1]}"; fi
}
train_one() {  # method corpus protocol
  local cfg; cfg="$(config_for "$1" "$2" "$3")"
  # shellcheck disable=SC2046
  case "$1" in
    lgbm_static|conformal_lgbm|late_fusion)
      run "$PY" scripts/train_gbdt.py --config "$cfg" --corpus "$2" --protocol "$3" --seeds $SEEDS $(extra_for "$2" "$3") ;;
    *) run "$PY" scripts/train.py --config "$cfg" --corpus "$2" --protocol "$3" --seeds $SEEDS "${DEV[@]}" $(extra_for "$2" "$3") ;;
  esac
}
all_runs() {  # prints "method corpus protocol" for every Table 4 run and every P-T run
  for corpus in bodmas ember2024 malnet_tiny; do
    for protocol in $(protocols_for "$corpus"); do
      for m in trustfusion $TORCH_BASELINES lgbm_static conformal_lgbm late_fusion; do
        applicable "$m" "$corpus" && echo "$m $corpus $protocol"
      done
    done
  done
  for m in $PT_METHODS; do echo "$m bodmas pt_family"; done
  echo "trustfusion bodmas pr_crosssource"
}

for stage in "${STAGES[@]}"; do
  case "$stage" in
  prepare)
    say "data preparation (local files only)"
    run "$PY" scripts/prepare_bodmas.py --bodmas-npz "$RAW/bodmas/bodmas.npz" --bodmas-metadata "$RAW/bodmas/bodmas_metadata.csv" \
        --binaries-dir "$RAW/bodmas/binaries" --benign-manifest "$RAW/benign/manifest.csv" \
        --benign-features "$RAW/benign/ember_v2_features.npy" --out data/processed/bodmas --check-counts
    run "$PY" scripts/prepare_ember2024.py --data-dir "$RAW/ember2024" --vectorized-dir "$RAW/ember2024" --out data/processed/ember2024 --check-counts
    MB=(); [ -n "$MALNET_BENIGN_SOURCE" ] && MB=(--benign-images-dir "$RAW/malnet/benign" --benign-source "$MALNET_BENIGN_SOURCE")
    run "$PY" scripts/prepare_malnet.py --images-dir "$RAW/malnet/malnet-images-tiny" --graphs-dir "$RAW/malnet/malnet-graphs" \
        --out data/processed/malnet_tiny --workers 16 --check-counts "${MB[@]}"
    ;;
  splits)
    say "splits (Table 2 counts -> splits/summary.json)"
    run "$PY" scripts/make_splits.py --corpus bodmas --check-counts
    run "$PY" scripts/make_splits.py --corpus ember2024 --check-counts
    MB=(); [ -n "$MALNET_BENIGN_SOURCE" ] && MB=(--benign-source "$MALNET_BENIGN_SOURCE")
    run "$PY" scripts/make_splits.py --corpus malnet_tiny --check-counts "${MB[@]}"
    ;;
  tune)
    [ "${RUN_TUNING:-0}" = 1 ] || { say "tuning skipped (set RUN_TUNING=1)"; continue; }
    for corpus in bodmas ember2024 malnet_tiny; do
      for m in $TORCH_BASELINES lgbm_static conformal_lgbm; do
        applicable "$m" "$corpus" && run "$PY" scripts/tune.py --config "configs/baselines/$m.yaml" --corpus "$corpus" "${DEV[@]}"
      done
    done
    ;;
  train)
    say "training (TrustFusion + nine baselines, ${SEEDS// /,} seeds)"
    # late fusion last: it stacks the byte-image CNN / LightGBM / GIN runs
    all_runs | grep -v '^late_fusion' | while read -r m c p; do train_one "$m" "$c" "$p"; done
    all_runs | grep '^late_fusion' | while read -r m c p; do train_one "$m" "$c" "$p"; done
    ;;
  calibrate)
    say "split-conformal calibration (alpha = 0.05)"
    all_runs | while read -r m c p; do
      case "$p" in pt_family|detection_subset) continue ;; esac   # P-T: weighted per window; EMBER detection: no cal split
      run "$PY" scripts/calibrate.py --run "runs/$c/$p/$m"
    done
    run "$PY" scripts/calibrate.py --run runs/bodmas/pr_family/cross_attention --temperature --name calibration_ts
    ;;
  evaluate)
    say "evaluation -> predictions.parquet / probs.npz / metrics.json"
    all_runs | while read -r m c p; do
      [ "$p" = pt_family ] && continue
      BS=(); [ "$p" = tiny_detection ] && BS=(--benign-source "$MALNET_BENIGN_SOURCE")
      NC=(); [ "$p" = pr_crosssource ] && NC=(--no-conformal)
      run "$PY" scripts/evaluate.py --run "runs/$c/$p/$m" "${BS[@]}" "${NC[@]}"
    done
    run "$PY" scripts/evaluate.py --run runs/bodmas/pr_family/cross_attention --calibration-name calibration_ts --method-name cross_attention__ts
    ;;
  temporal)
    say "P-T chronological deployment (W1..W7)"
    for m in $PT_METHODS; do run "$PY" scripts/run_temporal.py --run "runs/bodmas/pt_family/$m" --mode both; done
    ;;
  ablation)
    say "Table 7 component ablation and Table 8 reliability factorial"
    run "$PY" scripts/run_component_ablation.py --seeds $SEEDS --skip-existing "${DEV[@]}"
    run "$PY" scripts/run_factorial_ablation.py --seeds $SEEDS --train-missing "${DEV[@]}"
    ;;
  faithfulness)
    say "Table 9 faithfulness (BODMAS; MalNet needs DEX bytes and render/graph callbacks, see run_faithfulness.py)"
    run "$PY" scripts/run_faithfulness.py --run runs/bodmas/pr_family/trustfusion "${DEV[@]}"
    if [ -n "${MALNET_RENDER_FN:-}" ] && [ -n "${MALNET_GRAPH_FN:-}" ] && [ -n "${MALNET_DEX_DIR:-}" ]; then
      run "$PY" scripts/run_faithfulness.py --run runs/malnet_tiny/tiny_type/trustfusion --render-fn "$MALNET_RENDER_FN" \
          --graph-fn "$MALNET_GRAPH_FN" --dex-dir "$MALNET_DEX_DIR" --extractor none "${DEV[@]}"
    fi
    ;;
  provenance)
    say "Section 5.2 provenance controls"
    run "$PY" scripts/run_provenance.py --seeds $SEEDS
    ;;
  stats)
    say "seed statistics (Tables 4-6)"
    for corpus in bodmas ember2024 malnet_tiny; do
      run "$PY" scripts/seed_stats.py --corpus "$corpus" --protocol "${FAMILY[$corpus]}" \
          --methods trustfusion $TORCH_BASELINES lgbm_static conformal_lgbm late_fusion cross_attention__ts \
          --metrics accuracy macro_f1 ece coverage mean_set_size acceptance "selective_error@0.8" \
          --out "results/tables/seed_stats_${corpus}_${FAMILY[$corpus]}.csv"
      run "$PY" scripts/seed_stats.py --corpus "$corpus" --protocol "${DETECTION[$corpus]}" \
          --methods trustfusion $TORCH_BASELINES lgbm_static conformal_lgbm late_fusion \
          --metrics roc_auc "tpr@fpr=0.001" "tpr@fpr=0.01" --out "results/tables/seed_stats_${corpus}_${DETECTION[$corpus]}.csv"
    done
    run "$PY" scripts/seed_stats.py --corpus bodmas --protocol pt_family --methods $PT_METHODS \
        --metrics macro_f1@W1 macro_f1@W2 macro_f1@W3 macro_f1@W4 macro_f1@W5 macro_f1@W6 macro_f1@W7 pt_loss coverage acceptance \
        --out results/tables/seed_stats_bodmas_pt_family.csv
    run "$PY" scripts/seed_stats.py --paired --out results/tables/table5.csv
    ;;
  aggregate)
    say "tables 4-9 and figure data"
    run "$PY" scripts/aggregate_results.py --figures-out paper_figures/data
    ;;
  figures)
    run "$PY" paper_figures/make_figures.py --data paper_figures/data --out paper_figures/out
    ;;
  *) echo "unknown stage: $stage" >&2; exit 2 ;;
  esac
done
