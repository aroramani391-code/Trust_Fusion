import math

import numpy as np
import pytest
import torch

from trustfusion.data import byte_image as bi
from trustfusion.data.datasets import synthetic_pe_bytes

KB = 1024


@pytest.mark.parametrize("n,w", [(1, 32), (10 * KB - 1, 32), (10 * KB, 64), (30 * KB - 1, 64), (30 * KB, 128),
                                 (60 * KB, 256), (100 * KB, 384), (200 * KB, 512), (500 * KB, 768),
                                 (1024 * KB - 1, 768), (1024 * KB, 1024), (5 * 1024 * KB, 1024)])
def test_width_table(n, w):
    assert bi.image_width(n) == w
    h, ww = bi.raster_shape(n)
    assert ww == w and h == math.ceil(n / w)


@pytest.mark.parametrize("n", [1, 300, 5000, 70_000])
def test_render_shapes_and_ranges(n):
    data = np.random.default_rng(n).integers(0, 256, size=n, dtype=np.uint8)
    raster = bi.render_channels(data)
    h, w = bi.raster_shape(n)
    assert raster.shape == (3, h, w)
    assert np.all(raster.reshape(3, -1)[:, n:] == 0), "padding must be zero"
    np.testing.assert_allclose(raster[0].reshape(-1)[:n], data / 255.0, rtol=1e-6)
    for size in (224, 32):
        img = bi.render_byte_image(data, size=size)
        assert tuple(img.shape) == (3, size, size)
        assert float(img.min()) >= 0.0 and float(img.max()) <= 1.0 + 1e-6
    grey3 = bi.render_byte_image(data, size=32, channels=["grey3"])
    assert torch.allclose(grey3[0], grey3[1]) and torch.allclose(grey3[1], grey3[2])


def test_entropy_channel_matches_bruteforce():
    rng = np.random.default_rng(0)
    for n in (1, 100, 256, 700, 3000):
        d = rng.integers(0, 6, size=n, dtype=np.uint8)
        ref, cnt = np.zeros(n), np.zeros(n)
        for s in range(0, n, 128):
            wdw = d[s:s + 256]
            c = np.bincount(wdw, minlength=256)
            p = c[c > 0] / wdw.size
            ref[s:s + 256] += -(p * np.log2(p)).sum() / 8
            cnt[s:s + 256] += 1
        np.testing.assert_allclose(bi.entropy_channel(d), ref / cnt, atol=1e-6)
    assert np.all(bi.entropy_channel(np.zeros(1000, np.uint8)) == 0)


def test_bigram_channel():
    d = np.array([1, 2, 1, 2, 3], dtype=np.uint8)
    out = bi.bigram_channel(d)
    # pairs: (1,2) x2, (2,1) x1, (2,3) x1 ; max count 2
    expected = [0.0, np.log1p(2) / np.log1p(2), np.log1p(1) / np.log1p(2), np.log1p(2) / np.log1p(2), np.log1p(1) / np.log1p(2)]
    np.testing.assert_allclose(out, expected, rtol=1e-6)
    assert np.all(bi.bigram_channel(np.array([7], np.uint8)) == 0)


@pytest.mark.parametrize("n", [500, 5000, 90_000, 400_000])
def test_inverse_mapping_pixel_to_byte(n):
    rng = np.random.default_rng(1)
    offsets = rng.integers(0, n, size=200)
    i, j = bi.byte_to_pixel(offsets, n, 224)
    for t, ii, jj in zip(offsets, i, j):
        ranges = bi.pixel_to_byte_ranges(int(ii), int(jj), n, 224)
        assert any(s <= t < e for s, e in ranges)


def test_pixel_ranges_cover_every_byte():
    n = 3000
    covered = np.zeros(n, bool)
    for i in range(32):
        for j in range(32):
            for s, e in bi.pixel_to_byte_ranges(i, j, n, 32):
                covered[s:e] = True
    assert covered.all()


def test_project_to_bytes():
    n = 40_000
    cam = np.zeros((7, 7), np.float32)
    cam[:3] = 1.0  # top rows of the image = beginning of the file
    scores = bi.project_to_bytes(cam, n)
    assert scores.shape == (n,)
    assert scores[: n // 5].mean() > scores[-n // 5:].mean()
    const = bi.project_to_bytes(np.full((7, 7), 0.5, np.float32), n)
    np.testing.assert_allclose(const, 0.5, atol=1e-5)


def test_pe_regions_and_mass():
    rng = np.random.default_rng(0)
    data = synthetic_pe_bytes(rng, 20_000, 1, 4, overlay=1000)
    info = bi.parse_pe(data)
    assert info is not None
    assert [s.name for s in info.sections] == [".text", ".rdata", ".data"]
    assert info.overlay_start == len(data) - 1000
    rdata = info.sections[1]
    assert info.imports is not None and rdata.start <= info.imports.start < info.imports.end <= rdata.end
    codes = bi.region_labels(len(data), info)
    assert codes[0] == bi.REGION_CATEGORIES.index("header")
    assert codes[-1] == bi.REGION_CATEGORIES.index("overlay")
    assert codes[info.imports.start] == bi.REGION_CATEGORIES.index("imports")
    mass = bi.region_mass(np.ones(len(data)), info)
    assert abs(sum(mass.values()) - 1) < 1e-9 and mass["overlay"] == pytest.approx(1000 / len(data))
    assert bi.parse_pe(b"not a pe file at all" * 10) is None


def test_overlay_truncation_and_jitter():
    rng = np.random.default_rng(0)
    data = np.frombuffer(synthetic_pe_bytes(rng, 20_000, 0, 4, overlay=2000), np.uint8)
    info = bi.parse_pe(data)
    for _ in range(20):
        out = bi.truncate_overlay(data, rng, p=1.0, max_fraction=0.5)
        assert info.overlay_start + 1000 <= out.size <= data.size
        np.testing.assert_array_equal(out, data[: out.size])
    non_pe = np.zeros(5000, np.uint8)
    assert bi.truncate_overlay(non_pe, rng, p=1.0).size == 5000
    img = torch.rand(3, 8, 8)
    jit = bi.entropy_jitter(img, rng, channel=1)
    assert torch.equal(jit[0], img[0]) and torch.equal(jit[2], img[2])
    ratio = (jit[1] / img[1]).mean().item()
    assert 0.95 <= ratio <= 1.05


def test_channel_stats():
    imgs = [torch.rand(3, 16, 16) for _ in range(5)]
    stats = bi.compute_channel_stats(imgs)
    stacked = torch.stack(imgs)
    np.testing.assert_allclose(stats.mean, stacked.mean(dim=(0, 2, 3)).numpy(), rtol=1e-5)
    per_channel = stacked.permute(1, 0, 2, 3).reshape(3, -1).double()
    np.testing.assert_allclose(stats.std, per_channel.std(dim=1, unbiased=False).numpy(), rtol=1e-4)
    normed = stats.normalise(stacked[0])
    assert normed.shape == (3, 16, 16)
