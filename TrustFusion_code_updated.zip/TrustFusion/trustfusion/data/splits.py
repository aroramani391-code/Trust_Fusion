"""Split construction for all corpora and protocols (SPEC §1). Split seed 2024, identical for every method/seed.

Every function takes the processed corpus metadata (``meta.csv.gz``, see :mod:`trustfusion.data.datasets`) and
returns ``(split_df, classes, summary)`` where ``split_df`` has columns ``row, sample_id, split, window, label,
timestamp``: the released index files are sha256 lists (``sample_id``) with the first-seen timestamp of every file
(empty where the corpus has none, e.g. MalNet).

Two-stage stratified procedure (P-R, BODMAS)::

    rest, test   = train_test_split(idx,  test_size=0.15,        stratify=s[idx],  random_state=2024)
    train, vc    = train_test_split(rest, test_size=len(test),   stratify=s[rest], random_state=2024)
    val, cal     = train_test_split(vc,   test_size=0.5,         stratify=s[vc],   random_state=2024)

For 57,293 samples this yields 40,105 / 4,297 / 4,297 / 8,594 and for 48,360 samples 33,852 / 3,627 / 3,627 /
7,254 (the absolute val+cal size equals the test size). Strata with a single member (which sklearn cannot
stratify) are pooled into one ``__rare__`` stratum; this never triggers on the manuscript's label spaces.
"""
from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from ..io import read_json, write_json

SPLIT_SEED = 2024
RESIDUAL = "residual"
SPLIT_COLUMNS = ["row", "sample_id", "split", "window", "label", "timestamp"]


# --------------------------------------------------------------------------------------------- primitives
def safe_strata(strata: Sequence[Any]) -> np.ndarray:
    """Pool strata with fewer than two members so that sklearn's stratification is well defined."""
    s = pd.Series(np.asarray(strata).astype(str))
    counts = s.map(s.value_counts())
    if (counts >= 2).all():
        return s.to_numpy()
    s = s.where(counts >= 2, "__rare__")
    vc = s.value_counts()
    if vc.get("__rare__", 0) == 1:
        s = s.replace("__rare__", vc.index[0] if vc.index[0] != "__rare__" else vc.index[1])
    return s.to_numpy()


def stratified_split(idx: np.ndarray, strata: np.ndarray, test_size: float | int,
                     seed: int = SPLIT_SEED) -> tuple[np.ndarray, np.ndarray]:
    idx = np.asarray(idx)
    a, b = train_test_split(idx, test_size=test_size, stratify=safe_strata(strata[idx]), random_state=seed)
    return np.asarray(a), np.asarray(b)


def two_stage_split(strata: Sequence[Any], seed: int = SPLIT_SEED, test_size: float = 0.15,
                    valcal_size: int | None = None, idx: np.ndarray | None = None) -> dict[str, np.ndarray]:
    """Exact two-stage stratified procedure; returns index arrays for train / val / cal / test."""
    strata = np.asarray(strata).astype(str)
    idx = np.arange(len(strata)) if idx is None else np.asarray(idx)
    rest, test = stratified_split(idx, strata, test_size, seed)
    n_vc = len(test) if valcal_size is None else int(valcal_size)
    train, valcal = stratified_split(rest, strata, n_vc, seed)
    val, cal = stratified_split(valcal, strata, 0.5, seed)
    return {"train": train, "val": val, "cal": cal, "test": test}


def family_label_space(families: Sequence[Any], min_count: int, residual: str = RESIDUAL,
                       count_mask: np.ndarray | None = None) -> tuple[np.ndarray, list[str]]:
    """Families with ``>= min_count`` samples (counted where ``count_mask``) become classes; others -> residual.

    Classes are ordered alphabetically with ``residual`` last.
    """
    fam = pd.Series(np.asarray(families, dtype=object)).fillna("").astype(str)
    counted = fam if count_mask is None else fam[np.asarray(count_mask, dtype=bool)]
    vc = counted[counted != ""].value_counts()
    named = sorted(vc[vc >= min_count].index.tolist())
    classes = named + [residual]
    lookup = {f: i for i, f in enumerate(named)}
    labels = fam.map(lambda f: lookup.get(f, len(named))).to_numpy(dtype=np.int64)
    return labels, classes


def _timestamps(meta: pd.DataFrame, rows: np.ndarray) -> np.ndarray | list[str]:
    """First-seen timestamps of ``rows`` as strings ('' where the corpus has no timestamp)."""
    if "timestamp" not in meta.columns:
        return [""] * len(rows)
    return meta["timestamp"].fillna("").astype(str).to_numpy()[rows]


def _frame(rows: np.ndarray, meta: pd.DataFrame, split: str, labels: np.ndarray, window: str | np.ndarray = "") -> pd.DataFrame:
    rows = np.asarray(rows, dtype=np.int64)
    return pd.DataFrame({
        "row": rows,
        "sample_id": meta["sample_id"].to_numpy()[rows],
        "split": split,
        "window": window if isinstance(window, np.ndarray) else [window] * len(rows),
        "label": np.asarray(labels)[rows] if len(np.asarray(labels)) == len(meta) else labels,
        "timestamp": _timestamps(meta, rows),
    })


def assemble(meta: pd.DataFrame, parts: Mapping[str, np.ndarray], labels: np.ndarray,
             windows: Mapping[str, str] | None = None) -> pd.DataFrame:
    frames = [_frame(rows, meta, name, labels, (windows or {}).get(name, "")) for name, rows in parts.items()]
    df = pd.concat(frames, ignore_index=True)
    if df["row"].duplicated().any():
        raise AssertionError("a sample was assigned to more than one split")
    return df[SPLIT_COLUMNS]


def split_counts(df: pd.DataFrame, by: str = "split") -> dict[str, int]:
    return {str(k): int(v) for k, v in df[by].value_counts(sort=False).items()}


def parse_time(values: Sequence[Any]) -> pd.Series:
    s = pd.Series(values)
    if pd.api.types.is_numeric_dtype(s):
        return pd.to_datetime(s, unit="s", utc=True).dt.tz_localize(None)
    return pd.to_datetime(s, utc=True, format="mixed").dt.tz_localize(None)


def _check(expected: Mapping[str, int] | None, got: Mapping[str, int], what: str) -> None:
    if not expected:
        return
    diff = {k: (int(v), got.get(k)) for k, v in expected.items() if got.get(k) != int(v)}
    if diff:
        raise AssertionError(f"{what}: count mismatch (expected, got) = {diff}")


check_counts = _check  # public name used by scripts/make_splits.py


# --------------------------------------------------------------------------------------------- BODMAS
def bodmas_pr_family(meta: pd.DataFrame, seed: int = SPLIT_SEED, min_family_size: int = 25,
                     expected: Mapping[str, int] | None = None) -> tuple[pd.DataFrame, list[str], dict]:
    mal = np.flatnonzero(meta["is_malicious"].to_numpy() == 1)
    labels_all = np.full(len(meta), -1, dtype=np.int64)
    lab, classes = family_label_space(meta["family"].to_numpy()[mal], min_family_size)
    labels_all[mal] = lab
    parts = two_stage_split(labels_all, seed=seed, idx=mal)
    df = assemble(meta, parts, labels_all)
    counts = split_counts(df)
    _check(expected, counts, "bodmas pr_family")
    summary = {"n_samples": int(mal.size), "n_classes": len(classes), "n_named_families": len(classes) - 1,
               "n_raw_families": int(meta["family"].iloc[mal].nunique()), "min_family_size": min_family_size,
               "counts": counts,
               "residual_count": int((lab == len(classes) - 1).sum())}
    return df, classes, summary


def bodmas_pr_detection(meta: pd.DataFrame, seed: int = SPLIT_SEED, min_family_size: int = 25,
                        expected: Mapping[str, int] | None = None) -> tuple[pd.DataFrame, list[str], dict]:
    is_mal = meta["is_malicious"].to_numpy() == 1
    mal = np.flatnonzero(is_mal)
    ben = np.flatnonzero(~is_mal)
    fam_labels, _ = family_label_space(meta["family"].to_numpy()[mal], min_family_size)
    if ben.size > mal.size:
        raise ValueError("benign pool larger than the malicious pool")
    if ben.size == mal.size:
        mal_sel = mal
    else:
        mal_sel, _ = train_test_split(mal, train_size=int(ben.size), stratify=safe_strata(fam_labels), random_state=seed)
    rows = np.sort(np.concatenate([mal_sel, ben]))
    labels_all = is_mal.astype(np.int64)
    source = meta["benign_source"].fillna("").astype(str).to_numpy()
    strata = np.where(is_mal, "malicious", "benign|" + source)
    parts = two_stage_split(strata, seed=seed, idx=rows)
    df = assemble(meta, parts, labels_all)
    counts = split_counts(df)
    _check(expected, counts, "bodmas pr_detection")
    src = pd.Series(source[ben]).value_counts()
    per_split = {name: {s: int(c) for s, c in pd.Series(source[r][~is_mal[r]]).value_counts().items()}
                 for name, r in parts.items()}
    summary = {"n_malicious": int(mal_sel.size), "n_benign": int(ben.size), "counts": counts,
               "benign_sources": {str(k): int(v) for k, v in src.items()},
               "benign_sources_per_split": per_split,
               "strata": "detection label x benign source"}
    return df, ["benign", "malicious"], summary


def month_start(ts: str | pd.Timestamp, k: int) -> pd.Timestamp:
    t = pd.Timestamp(ts)
    return (t + pd.DateOffset(months=k)).normalize()


def pt_window_bounds(cfg: Mapping[str, Any]) -> dict[str, tuple[pd.Timestamp, pd.Timestamp]]:
    """Return ``{'fit', 'D1', 'W1'..'Wn'}`` half-open time intervals from the P-T config block."""
    bounds = {
        "fit": (pd.Timestamp(cfg["fit"][0]), pd.Timestamp(cfg["fit"][1])),
        "D1": (pd.Timestamp(cfg["d1"][0]), pd.Timestamp(cfg["d1"][1])),
    }
    for k in range(int(cfg["n_windows"])):
        bounds[f"W{k + 1}"] = (month_start(cfg["windows_start"], k), month_start(cfg["windows_start"], k + 1))
    return bounds


DEFAULT_PT = {
    "fit": ["2019-08-01", "2019-12-01"],
    "d1": ["2019-12-01", "2020-01-01"],
    "development": ["2019-08-01", "2020-01-01"],
    "windows_start": "2020-01-01",
    "n_windows": 7,
    "validation_fraction": 0.10,
    "min_family_size": 25,
}


def bodmas_pt(meta: pd.DataFrame, seed: int = SPLIT_SEED, pt_cfg: Mapping[str, Any] | None = None,
              expected_named_families: int | None = None) -> tuple[pd.DataFrame, list[str], dict]:
    """P-T split. ``K`` in the summary counts every class (named families + residual); the manuscript's Table 2
    reports the named families ("68 families + residual"), i.e. ``n_named_families``."""
    cfg = dict(DEFAULT_PT, **(pt_cfg or {}))
    t = parse_time(meta["timestamp"]).to_numpy()
    is_mal = meta["is_malicious"].to_numpy() == 1
    dev0, dev1 = pd.Timestamp(cfg["development"][0]), pd.Timestamp(cfg["development"][1])
    dev_mask = is_mal & (t >= dev0) & (t < dev1)
    labels, classes = family_label_space(meta["family"].to_numpy(), int(cfg["min_family_size"]), count_mask=dev_mask)
    if expected_named_families is not None and len(classes) - 1 != int(expected_named_families):
        raise AssertionError(f"bodmas pt_family: expected {expected_named_families} named families + residual, "
                             f"found {len(classes) - 1}")
    labels = np.where(is_mal, labels, -1)
    bounds = pt_window_bounds(cfg)
    assign = {name: np.flatnonzero(is_mal & (t >= lo) & (t < hi)) for name, (lo, hi) in bounds.items()}
    fit_train, fit_val = stratified_split(assign["fit"], labels, float(cfg["validation_fraction"]), seed)
    parts: dict[str, np.ndarray] = {"train": fit_train, "val": fit_val, "cal": assign["D1"]}
    frames = [_frame(fit_train, meta, "train", labels, "fit"), _frame(fit_val, meta, "val", labels, "fit"),
              _frame(assign["D1"], meta, "cal", labels, "D1")]
    for k in range(int(cfg["n_windows"])):
        name = f"W{k + 1}"
        frames.append(_frame(assign[name], meta, "test", labels, name))
        parts[name] = assign[name]
    df = pd.concat(frames, ignore_index=True)[SPLIT_COLUMNS]
    if df["row"].duplicated().any():
        raise AssertionError("overlapping P-T windows")
    used = set(df["row"].tolist())
    summary = {
        "K": len(classes), "n_named_families": len(classes) - 1, "min_family_size": int(cfg["min_family_size"]),
        "counts": split_counts(df), "windows": {name: int(len(r)) for name, r in assign.items()},
        "fit_train": int(fit_train.size), "fit_val": int(fit_val.size),
        "unused_malicious": int(is_mal.sum() - len(used)),
        "bounds": {k: [str(lo.date()), str(hi.date())] for k, (lo, hi) in bounds.items()},
    }
    return df, classes, summary


def bodmas_cross_source(detection_df: pd.DataFrame, meta: pd.DataFrame, train_sources: Sequence[str] = ("win10", "win11"),
                        test_source: str = "repo", test_benign_from: str = "all") -> tuple[pd.DataFrame, list[str], dict]:
    """Cross-source run: fit/val/cal benign files only from ``train_sources``; benign test files = ``test_source``.

    ``test_benign_from='all'`` uses every ``test_source`` benign file of the detection subset (none of them is
    used for fitting in this run); ``'test_split'`` keeps only those already in the detection test split.
    """
    src = meta["benign_source"].fillna("").astype(str).to_numpy()
    df = detection_df.copy()
    if "timestamp" not in df.columns:  # detection split read from an index file written before the column existed
        df["timestamp"] = _timestamps(meta, df["row"].to_numpy())
    row_src = src[df["row"].to_numpy()]
    benign = df["label"].to_numpy() == 0
    keep_fit = ~benign | np.isin(row_src, list(train_sources))
    fit_part = df[(df["split"] != "test") & keep_fit]
    mal_test = df[(df["split"] == "test") & ~benign]
    if test_benign_from == "all":
        ben_test = df[benign & (row_src == test_source)].assign(split="test")
    elif test_benign_from == "test_split":
        ben_test = df[(df["split"] == "test") & benign & (row_src == test_source)]
    else:
        raise ValueError(test_benign_from)
    out = pd.concat([fit_part, mal_test, ben_test], ignore_index=True)[SPLIT_COLUMNS]
    summary = {"train_sources": list(train_sources), "test_source": test_source, "test_benign_from": test_benign_from,
               "counts": split_counts(out),
               "benign_test": int(len(ben_test)), "malicious_test": int(len(mal_test))}
    return out, ["benign", "malicious"], summary


# --------------------------------------------------------------------------------------------- EMBER2024
def normalise_format(v: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(v).lower()).replace("dotnet", "net")


def ember2024_family_subset(meta: pd.DataFrame, seed: int = SPLIT_SEED, min_count: int = 10,
                            cal_window: Sequence[str] = ("2024-08-25", "2024-09-22"), val_fraction: float = 0.10,
                            expected_families: int | None = None, expected: Mapping[str, int] | None = None
                            ) -> tuple[pd.DataFrame, list[str], dict]:
    """Family subset: malicious files of the ``min_count`` families (all six formats).

    ``train_official`` (= train + val + cal) and ``test_official`` are the Table 2 sizes. Only malicious files carry a
    family, so the subset can never exceed the malicious files of the official split; both totals are recorded next
    to the subset sizes (``malicious_train_official`` / ``malicious_test_official``) and the bound is asserted.
    """
    rel = meta["released_split"].astype(str).to_numpy()
    is_mal = meta["is_malicious"].to_numpy() == 1
    fam = meta["family"].fillna("").astype(str).to_numpy()
    tr_mal = (rel == "train") & is_mal & (fam != "")
    vc = pd.Series(fam[tr_mal]).value_counts()
    families = sorted(vc[vc >= min_count].index.tolist())
    if expected_families is not None and len(families) != int(expected_families):
        raise AssertionError(f"EMBER2024 family subset: expected {expected_families} families, found {len(families)}")
    lookup = {f: i for i, f in enumerate(families)}
    in_subset = is_mal & np.isin(fam, families)
    labels = np.array([lookup.get(f, -1) for f in fam], dtype=np.int64)
    t = parse_time(meta["timestamp"]).to_numpy()
    lo, hi = pd.Timestamp(cal_window[0]), pd.Timestamp(cal_window[1])
    train_rows = np.flatnonzero(in_subset & (rel == "train"))
    cal_mask = (t[train_rows] >= lo) & (t[train_rows] < hi)
    cal = train_rows[cal_mask]
    rest = train_rows[~cal_mask]
    fit, val = stratified_split(rest, labels, val_fraction, seed)
    test = np.flatnonzero(in_subset & (rel == "test"))
    df = assemble(meta, {"train": fit, "val": val, "cal": cal, "test": test}, labels)
    got = {"train_official": int(train_rows.size), "test_official": int(test.size)}
    malicious = {"malicious_train_official": int((is_mal & (rel == "train")).sum()),
                 "malicious_test_official": int((is_mal & (rel == "test")).sum())}
    if got["train_official"] > malicious["malicious_train_official"] or got["test_official"] > malicious["malicious_test_official"]:
        raise AssertionError(f"EMBER2024 family subset larger than the malicious files it is drawn from: {got} vs {malicious}")
    _check(expected, got, "ember2024 family subset")
    fmt = meta["file_format"].astype(str).to_numpy()
    summary = {"n_families": len(families), "min_count": min_count, "counts": split_counts(df), **got, **malicious,
               "calibration_window": [str(lo.date()), str((hi - pd.Timedelta(days=1)).date())],
               "formats_per_split": {s: {str(k): int(v) for k, v in pd.Series(fmt[r]).value_counts().items()}
                                     for s, r in {"train": fit, "val": val, "cal": cal, "test": test}.items()}}
    return df, families, summary


def ember2024_detection_subset(meta: pd.DataFrame, seed: int = SPLIT_SEED,
                               formats: Sequence[str] = ("Win32", "Win64", ".NET"), val_fraction: float = 0.10,
                               expected: Mapping[str, int] | None = None) -> tuple[pd.DataFrame, list[str], dict]:
    rel = meta["released_split"].astype(str).to_numpy()
    fmt = np.array([normalise_format(v) for v in meta["file_format"].to_numpy()])
    labels = meta["is_malicious"].to_numpy().astype(np.int64)
    keep = np.isin(fmt, [normalise_format(f) for f in formats]) & (labels >= 0)  # labelled benign / malicious only
    train_rows = np.flatnonzero(keep & (rel == "train"))
    test_rows = np.flatnonzero(keep & (rel == "test"))
    fit, val = stratified_split(train_rows, labels, val_fraction, seed)
    df = assemble(meta, {"train": fit, "val": val, "test": test_rows}, labels)
    got = {"train_official": int(train_rows.size), "test_official": int(test_rows.size)}
    _check(expected, got, "ember2024 detection subset")
    summary = {"formats": list(formats), "counts": split_counts(df), **got,
               "malicious_fraction_train": float(labels[train_rows].mean()) if train_rows.size else None,
               "malicious_fraction_test": float(labels[test_rows].mean()) if test_rows.size else None}
    return df, ["benign", "malicious"], summary


# --------------------------------------------------------------------------------------------- MalNet
def malnet_tiny_type(meta: pd.DataFrame, seed: int = SPLIT_SEED, expected: Mapping[str, int] | None = None,
                     expected_types: int | None = None, expected_graph_unmatched: int | None = None
                     ) -> tuple[pd.DataFrame, list[str], dict]:
    rel = meta["released_split"].astype(str).to_numpy()
    tiny = np.flatnonzero(meta["is_malicious"].to_numpy() == 1)
    types = sorted(meta["family"].iloc[tiny].astype(str).unique().tolist())
    if expected_types is not None and len(types) != int(expected_types):
        raise AssertionError(f"MalNet-Tiny: expected {expected_types} types, found {len(types)}")
    lookup = {c: i for i, c in enumerate(types)}
    labels = np.array([lookup.get(str(f), -1) for f in meta["family"].to_numpy()], dtype=np.int64)
    tr = tiny[rel[tiny] == "train"]
    released_val = tiny[rel[tiny] == "val"]
    te = tiny[rel[tiny] == "test"]
    val, cal = stratified_split(released_val, labels, 0.5, seed)
    df = assemble(meta, {"train": tr, "val": val, "cal": cal, "test": te}, labels)
    counts = split_counts(df)
    _check(expected, counts, "malnet tiny")
    has_static = meta["has_static"].to_numpy().astype(bool)
    _check({"graph_unmatched": expected_graph_unmatched} if expected_graph_unmatched is not None else None,
           {"graph_unmatched": int((~has_static[tiny]).sum())}, "malnet tiny call-graph matching")
    summary = {"n_types": len(types), "counts": counts,
               "released": {"train": int(tr.size), "val": int(released_val.size), "test": int(te.size)},
               "graph_unmatched": int((~has_static[tiny]).sum()),
               "graph_unmatched_per_split": {s: int((~has_static[r]).sum())
                                             for s, r in {"train": tr, "val": val, "cal": cal, "test": te}.items()}}
    return df, types, summary


def malnet_tiny_detection(meta: pd.DataFrame, benign_source: str | None, seed: int = SPLIT_SEED,
                          expected_benign: int | None = None) -> tuple[pd.DataFrame, list[str], dict]:
    """Tiny malicious files (released split, val halved) + benign files from an explicit external source.

    In the manuscript the benign source is ``googleplay``: 5,000 benign Android APKs collected from the Google Play
    Store with zero VirusTotal detections, rendered as MalNet-style DEX images. Benign files are randomly partitioned
    (seed 2024) in the same proportions as the Tiny partition.
    """
    if not benign_source:
        raise ValueError("MalNet-Tiny has no benign class: pass an explicit --benign-source (manuscript: googleplay, "
                         "5,000 Google Play APKs with zero VirusTotal detections); refusing to build a detection split")
    type_df, _, type_summary = malnet_tiny_type(meta, seed)
    src = meta["benign_source"].fillna("").astype(str).to_numpy()
    ben = np.flatnonzero((meta["is_malicious"].to_numpy() == 0) & (src == benign_source))
    if ben.size == 0:
        raise ValueError(f"no benign rows with benign_source == {benign_source!r} in the processed MalNet corpus")
    _check({"benign": expected_benign} if expected_benign is not None else None, {"benign": int(ben.size)},
           f"malnet tiny detection benign source {benign_source!r}")
    counts = type_df["split"].value_counts()
    order = ["train", "val", "cal", "test"]
    frac = np.array([counts.get(s, 0) for s in order], dtype=np.float64)
    frac = frac / frac.sum()
    perm = np.random.default_rng(seed).permutation(ben)
    cuts = np.round(np.cumsum(frac) * ben.size).astype(int)
    ben_parts = dict(zip(order, np.split(perm, cuts[:-1])))
    mal = type_df.assign(label=1)
    labels = np.zeros(len(meta), dtype=np.int64)
    ben_df = assemble(meta, ben_parts, labels)
    df = pd.concat([mal, ben_df], ignore_index=True)[SPLIT_COLUMNS]
    summary = {"benign_source": benign_source, "counts": split_counts(df),
               "benign_per_split": {k: int(v.size) for k, v in ben_parts.items()},
               "graph_unmatched": type_summary["graph_unmatched"]}
    return df, ["benign", "malicious"], summary


# --------------------------------------------------------------------------------------------- files
def split_path(splits_dir: str | os.PathLike, corpus: str, protocol: str) -> Path:
    return Path(splits_dir) / f"{corpus}_{protocol}.csv"


def write_split(df: pd.DataFrame, classes: Sequence[str], splits_dir: str | os.PathLike, corpus: str,
                protocol: str) -> Path:
    path = split_path(splits_dir, corpus, protocol)
    path.parent.mkdir(parents=True, exist_ok=True)
    if "timestamp" not in df.columns:
        df = df.assign(timestamp="")
    df[SPLIT_COLUMNS].to_csv(path, index=False)
    write_json(path.with_name(f"{corpus}_{protocol}_classes.json"), list(classes))
    return path


def read_split(splits_dir: str | os.PathLike, corpus: str, protocol: str) -> tuple[pd.DataFrame, list[str]]:
    path = split_path(splits_dir, corpus, protocol)
    df = pd.read_csv(path, dtype={"sample_id": str, "split": str, "window": str, "timestamp": str}, keep_default_na=False)
    classes = read_json(path.with_name(f"{corpus}_{protocol}_classes.json"))
    return df, list(classes)


def update_summary(splits_dir: str | os.PathLike, corpus: str, protocol: str, summary: Mapping[str, Any]) -> Path:
    path = Path(splits_dir) / "summary.json"
    current = read_json(path) if path.exists() else {}
    entry = dict(summary)
    if "file" in entry:
        entry["file"] = Path(entry["file"]).name
    current.setdefault(corpus, {})[protocol] = entry
    return write_json(path, current)
