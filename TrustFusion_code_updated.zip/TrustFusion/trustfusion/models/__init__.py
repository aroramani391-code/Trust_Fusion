"""Model registry."""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np

from .base import ClassifierBase
from .trustfusion import TrustFusion

TORCH_METHODS = ("trustfusion", "byte_cnn", "mcdropout_cnn", "msvit", "feature_graph", "gin_callgraph", "cross_attention")
GBDT_METHODS = ("lgbm_static", "conformal_lgbm")
STACKER_METHODS = ("late_fusion",)
ALL_METHODS = TORCH_METHODS + GBDT_METHODS + STACKER_METHODS


def method_kind(method: str) -> str:
    base = method.split("__", 1)[0]
    if base in TORCH_METHODS:
        return "graph" if base == "gin_callgraph" else "torch"
    if base in GBDT_METHODS:
        return "gbdt"
    if base in STACKER_METHODS:
        return "stacker"
    raise KeyError(f"unknown method {method!r}")


def build_torch_model(cfg: Mapping[str, Any], num_classes: int, group_indices: Sequence[np.ndarray] | None = None,
                      static_dim: int = 0, adjacency: np.ndarray | None = None) -> ClassifierBase:
    from .baselines import ByteImageCNN, CrossAttentionFusion, FeatureGraphGCN, MultiScaleViT, StructuralGIN

    method = str(cfg["method"])
    model_cfg = dict(cfg.get("model", {}))
    image_size = int(cfg.get("data", {}).get("image", {}).get("size", 224))
    if method == "trustfusion":
        return TrustFusion(num_classes, group_indices or [], model_cfg, image_size=image_size)
    if method in ("byte_cnn", "mcdropout_cnn"):
        return ByteImageCNN(num_classes, model_cfg)
    if method == "msvit":
        return MultiScaleViT(num_classes, model_cfg)
    if method == "feature_graph":
        if adjacency is None:
            raise ValueError("feature_graph needs the training-data Pearson adjacency")
        return FeatureGraphGCN(num_classes, group_indices or [], adjacency, model_cfg, static_dim)
    if method == "gin_callgraph":
        return StructuralGIN(num_classes, model_cfg)
    if method == "cross_attention":
        return CrossAttentionFusion(num_classes, static_dim, model_cfg)
    raise KeyError(f"{method!r} is not a torch method")


__all__ = ["ClassifierBase", "TrustFusion", "build_torch_model", "method_kind", "TORCH_METHODS", "GBDT_METHODS",
           "STACKER_METHODS", "ALL_METHODS"]
