import math

import numpy as np
import pytest
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score, roc_curve

from trustfusion import metrics as M
from trustfusion.conformal import prediction_sets


def test_accuracy_and_macro_f1_match_sklearn():
    rng = np.random.default_rng(0)
    for _ in range(20):
        C = int(rng.integers(2, 12))
        y = rng.integers(0, C, 300)
        yp = np.where(rng.random(300) < 0.6, y, rng.integers(0, C + 2, 300))  # includes never-true predicted classes
        assert M.accuracy(y, yp) == pytest.approx(accuracy_score(y, yp))
        assert M.macro_f1(y, yp) == pytest.approx(f1_score(y, yp, average="macro", zero_division=0))


def test_ece_matches_reference_loop():
    rng = np.random.default_rng(1)
    p = rng.dirichlet(np.ones(4) * 0.4, size=1000)
    y = rng.integers(0, 4, 1000)
    conf, pred = p.max(1), p.argmax(1)
    ref = 0.0
    for m in range(15):
        lo, hi = m / 15, (m + 1) / 15
        idx = (conf > lo) & (conf <= hi)
        if idx.any():
            ref += idx.mean() * abs((pred[idx] == y[idx]).mean() - conf[idx].mean())
    assert M.ece(p, y, 15) == pytest.approx(ref)
    rb = M.reliability_bins(p, y, 15)
    assert rb["count"].sum() == 1000 and rb["bin_center"][0] == pytest.approx(1 / 30)


def test_roc_auc_and_tpr_at_fpr():
    rng = np.random.default_rng(2)
    y = rng.integers(0, 2, 5000)
    s = y * 1.5 + rng.normal(size=5000)
    assert M.roc_auc(y, s) == pytest.approx(roc_auc_score(y, s))
    fpr, tpr, _ = roc_curve(y, s, drop_intermediate=False)
    out = M.tpr_at_fpr(y, s, [1e-3, 1e-2])
    assert out[1e-2] == pytest.approx(np.interp(1e-2, fpr, tpr))
    assert 0 <= out[1e-3] <= out[1e-2] <= 1
    # hand-checkable interpolation: 4 negatives, 2 positives
    y2 = np.array([0, 0, 0, 0, 1, 1])
    s2 = np.array([0.1, 0.2, 0.3, 0.9, 0.8, 0.95])
    # ROC points (fpr, tpr): (0,0) (0,.5) (.25,.5) (.25,1) ... -> TPR at FPR 0.125 interpolates to 0.5
    assert M.tpr_at_fpr(y2, s2, [0.125])[0.125] == pytest.approx(0.5)
    assert math.isnan(M.roc_auc(np.ones(5), np.random.rand(5)))


def test_selective_error_and_conformal_metrics():
    p = np.array([[0.9, 0.1], [0.6, 0.4], [0.2, 0.8], [0.55, 0.45]])
    y = np.array([0, 1, 1, 1])
    assert M.selective_error(p, y, 1.0) == pytest.approx(0.5)
    assert M.selective_error(p, y, 0.5) == pytest.approx(0.0)  # two most confident: rows 0 and 2
    assert M.selective_error(p, y, 0.75) == pytest.approx(1 / 3)  # ceil(3): rows 0, 2, 1 -> one error
    sets = prediction_sets(p, 0.6)  # 1 - p <= 0.6: {0}, {0,1}, {1}, {0,1}
    cm = M.conformal_metrics(sets, y, p.argmax(1))
    assert cm["mean_set_size"] == pytest.approx(1.5) and cm["acceptance"] == pytest.approx(0.5)
    assert cm["coverage"] == pytest.approx(1.0) and cm["accepted_error"] == pytest.approx(0.0)
