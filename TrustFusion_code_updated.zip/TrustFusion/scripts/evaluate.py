#!/usr/bin/env python
"""Evaluate runs on their test split: per-sample predictions, probability matrix and metrics.

Writes ``predictions.parquet`` (``.csv.gz`` without pyarrow), ``probs.npz`` and ``metrics.json`` into the run
directory, or into ``runs/<corpus>/<protocol>/<method-name>/seed<k>/`` with ``--method-name`` (evaluation-only
variants such as the "no conformal gate" ablation or the "MC head off" factorial cells).

Examples::

    python scripts/evaluate.py --run runs/bodmas/pr_family/trustfusion
    python scripts/evaluate.py --run runs/bodmas/pr_family/trustfusion --method-name trustfusion__no_conformal --no-conformal
    python scripts/evaluate.py --run runs/bodmas/pr_family/cross_attention --calibration-name calibration_ts \
        --method-name cross_attention__ts
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from trustfusion.cli import run_dirs  # noqa: E402
from trustfusion.evaluation import evaluate_run  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("evaluate")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--run", nargs="+", required=True)
    ap.add_argument("--head", choices=["mc", "det"], default="mc")
    ap.add_argument("--method-name", default=None)
    ap.add_argument("--no-conformal", action="store_true", help="disable the conformal gate (predict on every sample)")
    ap.add_argument("--calibration-name", default="calibration")
    ap.add_argument("--split", default="test")
    ap.add_argument("--benign-source", default=None, help="MalNet-Tiny detection: explicit benign source (required)")
    args = ap.parse_args()
    for run in run_dirs(args.run):
        out = run.parent.parent / args.method_name / run.name if args.method_name else run
        m = evaluate_run(run, head=args.head, out_dir=out, method_name=args.method_name, conformal=not args.no_conformal,
                         calibration_name=args.calibration_name, split=args.split,
                         benign_source=args.benign_source)
        log.info("%s: %s", out, {k: v for k, v in m.items() if isinstance(v, float)})


if __name__ == "__main__":
    main()
