"""Byte-image encoders.

``resnet50`` (the manuscript's encoder): torchvision ResNet-50 with ImageNet ``IMAGENET1K_V2`` weights when
``pretrained: true``; the 3-channel stem takes the grey/entropy/bigram image; the layer4 maps ``A^k``
(7 x 7 x 2048 at 224 px) are kept for Grad-CAM++ and projected to ``d = 512`` tokens (49 tokens).
``convnext_tiny`` is used by the cross-attention baseline. ``tiny`` is a small CNN used ONLY by unit tests and
the CPU smoke test.
"""
from __future__ import annotations

import torch
import torch.nn as nn

BACKBONE_STRIDE = {"resnet50": 32, "resnet18": 32, "convnext_tiny": 32, "tiny": 8}


def build_backbone(name: str, pretrained: bool = False) -> tuple[nn.Module, int]:
    """Return ``(feature_extractor, out_channels)``; the extractor maps ``[B,3,H,W]`` to ``[B,C,H/s,W/s]``."""
    import torchvision

    if name == "resnet50":
        weights = torchvision.models.ResNet50_Weights.IMAGENET1K_V2 if pretrained else None
        net = torchvision.models.resnet50(weights=weights)
        return nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool, net.layer1, net.layer2, net.layer3, net.layer4), 2048
    if name == "resnet18":
        weights = torchvision.models.ResNet18_Weights.IMAGENET1K_V1 if pretrained else None
        net = torchvision.models.resnet18(weights=weights)
        return nn.Sequential(net.conv1, net.bn1, net.relu, net.maxpool, net.layer1, net.layer2, net.layer3, net.layer4), 512
    if name == "convnext_tiny":
        weights = torchvision.models.ConvNeXt_Tiny_Weights.IMAGENET1K_V1 if pretrained else None
        net = torchvision.models.convnext_tiny(weights=weights)
        return net.features, 768
    if name == "tiny":
        def block(cin: int, cout: int) -> nn.Sequential:
            return nn.Sequential(nn.Conv2d(cin, cout, 3, stride=2, padding=1, bias=False), nn.BatchNorm2d(cout), nn.ReLU(inplace=False))
        return nn.Sequential(block(3, 16), block(16, 32), block(32, 64)), 64
    raise ValueError(f"unknown backbone {name!r}")


class ImageEncoder(nn.Module):
    def __init__(self, backbone: str = "resnet50", pretrained: bool = False, d_model: int = 512):
        super().__init__()
        self.backbone_name = backbone
        self.backbone, self.out_channels = build_backbone(backbone, pretrained)
        self.proj = nn.Linear(self.out_channels, d_model)
        self.stride = BACKBONE_STRIDE[backbone]

    def n_tokens(self, image_size: int) -> int:
        side = max(1, -(-image_size // self.stride))
        return side * side

    def forward(self, x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        """Return layer-4 maps ``A [B,C,h,w]`` and projected tokens ``[B, h*w, d]``."""
        A = self.backbone(x)
        tokens = self.proj(A.flatten(2).transpose(1, 2))
        return A, tokens
