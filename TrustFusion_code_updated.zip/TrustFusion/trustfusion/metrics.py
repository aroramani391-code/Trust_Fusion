"""Evaluation metrics (SPEC §5).

* accuracy, macro-F1 over all classes occurring in ``y_true`` or ``y_pred`` (the residual class included; this is
  scikit-learn's ``f1_score(average='macro')`` label set)
* ROC-AUC; TPR at FPR in {1e-3, 1e-2} by linear interpolation of the test ROC curve
* ECE with 15 equal-width bins on the maximum probability
* selective error at coverage ``c``: error among the ``ceil(c N)`` samples with the largest max ``p_bar``
* empirical conformal coverage, mean set size, acceptance rate (fraction of singleton sets)
"""
from __future__ import annotations

import math
from typing import Any, Sequence

import numpy as np
from sklearn.metrics import roc_auc_score, roc_curve


def accuracy(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    y_true, y_pred = np.asarray(y_true), np.asarray(y_pred)
    return float((y_true == y_pred).mean()) if y_true.size else float("nan")


def macro_f1(y_true: np.ndarray, y_pred: np.ndarray, n_classes: int | None = None) -> float:
    """Fast macro-F1 (bincount), identical to ``sklearn.metrics.f1_score(average='macro')``."""
    y_true = np.asarray(y_true, dtype=np.int64)
    y_pred = np.asarray(y_pred, dtype=np.int64)
    if y_true.size == 0:
        return float("nan")
    C = int(max(y_true.max(), y_pred.max()) + 1) if n_classes is None else int(n_classes)
    tp = np.bincount(y_true[y_true == y_pred], minlength=C).astype(np.float64)
    n_true = np.bincount(y_true, minlength=C).astype(np.float64)
    n_pred = np.bincount(y_pred, minlength=C).astype(np.float64)
    present = (n_true + n_pred) > 0
    f1 = 2 * tp[present] / (n_true[present] + n_pred[present])
    return float(f1.mean())


def ece(probs: np.ndarray, y_true: np.ndarray, n_bins: int = 15) -> float:
    """Expected calibration error with equal-width bins ``((m-1)/M, m/M]`` on the maximum probability."""
    probs = np.asarray(probs, dtype=np.float64)
    conf = probs.max(axis=1)
    correct = (probs.argmax(axis=1) == np.asarray(y_true)).astype(np.float64)
    return ece_from_confidence(conf, correct, n_bins)


def ece_from_confidence(conf: np.ndarray, correct: np.ndarray, n_bins: int = 15) -> float:
    conf = np.asarray(conf, dtype=np.float64)
    n = conf.size
    if n == 0:
        return float("nan")
    bins = np.clip(np.ceil(conf * n_bins).astype(np.int64) - 1, 0, n_bins - 1)
    conf_sum = np.bincount(bins, weights=conf, minlength=n_bins)
    acc_sum = np.bincount(bins, weights=np.asarray(correct, dtype=np.float64), minlength=n_bins)
    return float(np.abs(acc_sum - conf_sum).sum() / n)


def reliability_bins(probs: np.ndarray, y_true: np.ndarray, n_bins: int = 15) -> dict[str, np.ndarray]:
    probs = np.asarray(probs, dtype=np.float64)
    conf = probs.max(axis=1)
    correct = (probs.argmax(axis=1) == np.asarray(y_true)).astype(np.float64)
    bins = np.clip(np.ceil(conf * n_bins).astype(np.int64) - 1, 0, n_bins - 1)
    count = np.bincount(bins, minlength=n_bins).astype(np.float64)
    with np.errstate(invalid="ignore", divide="ignore"):
        acc = np.bincount(bins, weights=correct, minlength=n_bins) / count
        cmean = np.bincount(bins, weights=conf, minlength=n_bins) / count
    centers = (np.arange(n_bins) + 0.5) / n_bins
    return {"bin_center": centers, "accuracy": acc, "confidence": cmean, "count": count}


def roc_auc(y_binary: np.ndarray, score: np.ndarray) -> float:
    y_binary = np.asarray(y_binary)
    if np.unique(y_binary).size < 2:
        return float("nan")
    return float(roc_auc_score(y_binary, score))


def tpr_at_fpr(y_binary: np.ndarray, score: np.ndarray, fpr_targets: Sequence[float] = (1e-3, 1e-2)) -> dict[float, float]:
    """TPR at the given FPRs by linear interpolation of the (non-thinned) ROC curve."""
    fpr, tpr, _ = roc_curve(np.asarray(y_binary), np.asarray(score), drop_intermediate=False)
    return {float(f): float(np.interp(f, fpr, tpr)) for f in fpr_targets}


def roc_on_grid(y_binary: np.ndarray, score: np.ndarray, grid: np.ndarray) -> np.ndarray:
    fpr, tpr, _ = roc_curve(np.asarray(y_binary), np.asarray(score), drop_intermediate=False)
    return np.interp(grid, fpr, tpr)


def selective_error(probs_or_conf: np.ndarray, y_true: np.ndarray, coverage: float, y_pred: np.ndarray | None = None) -> float:
    """Error among the ``ceil(coverage * N)`` most confident samples (ties broken by original order)."""
    arr = np.asarray(probs_or_conf, dtype=np.float64)
    if arr.ndim == 2:
        conf, pred = arr.max(axis=1), arr.argmax(axis=1)
    else:
        if y_pred is None:
            raise ValueError("y_pred is required when passing confidences")
        conf, pred = arr, np.asarray(y_pred)
    n = conf.size
    k = int(math.ceil(coverage * n - 1e-9))
    if k == 0:
        return float("nan")
    order = np.argsort(-conf, kind="stable")[:k]
    return float((pred[order] != np.asarray(y_true)[order]).mean())


def risk_coverage(probs: np.ndarray, y_true: np.ndarray, coverages: Sequence[float]) -> dict[float, float]:
    return {float(c): selective_error(probs, y_true, c) for c in coverages}


def conformal_metrics(sets: np.ndarray, y_true: np.ndarray, y_pred: np.ndarray) -> dict[str, float]:
    sizes = sets.sum(axis=1)
    accepted = sizes == 1
    y_true = np.asarray(y_true)
    out = {
        "coverage": float(sets[np.arange(sets.shape[0]), y_true].mean()) if sizes.size else float("nan"),
        "mean_set_size": float(sizes.mean()) if sizes.size else float("nan"),
        "acceptance": float(accepted.mean()) if sizes.size else float("nan"),
    }
    out["accepted_error"] = float((np.asarray(y_pred)[accepted] != y_true[accepted]).mean()) if accepted.any() else float("nan")
    out["accepted_macro_f1"] = macro_f1(y_true[accepted], np.asarray(y_pred)[accepted]) if accepted.any() else float("nan")
    return out


def classification_metrics(probs: np.ndarray, y_true: np.ndarray, n_bins: int = 15,
                           coverages: Sequence[float] = (1.0, 0.95, 0.9, 0.85, 0.8, 0.75, 0.7)) -> dict[str, Any]:
    probs = np.asarray(probs, dtype=np.float64)
    y_pred = probs.argmax(axis=1)
    out: dict[str, Any] = {"n": int(len(y_true)), "accuracy": accuracy(y_true, y_pred), "macro_f1": macro_f1(y_true, y_pred),
                           "ece": ece(probs, y_true, n_bins)}
    for c in coverages:
        out[f"selective_error@{c:g}"] = selective_error(probs, y_true, c)
    return out


def detection_metrics(p_malicious: np.ndarray, y_true: np.ndarray, fpr_targets: Sequence[float] = (1e-3, 1e-2)) -> dict[str, float]:
    out = {"roc_auc": roc_auc(y_true, p_malicious)}
    if np.unique(y_true).size == 2:
        for f, v in tpr_at_fpr(y_true, p_malicious, fpr_targets).items():
            out[f"tpr@fpr={f:g}"] = v
    return out
