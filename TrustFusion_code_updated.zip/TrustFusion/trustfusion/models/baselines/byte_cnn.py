"""Byte-image CNN and MC-dropout image CNN baselines (SPEC §4).

* ``byte_cnn``: ResNet-50 (ImageNet) on the grey byte image replicated to 3 channels at 224^2; cross-entropy.
* ``mcdropout_cnn``: the same network with Dropout(0.3) before the head and T = 12 head-only MC passes.
"""
from __future__ import annotations

from typing import Any, Mapping

import torch
import torch.nn as nn

from ..base import ClassifierBase
from ..image_encoder import build_backbone


class ByteImageCNN(ClassifierBase):
    def __init__(self, num_classes: int, model_cfg: Mapping[str, Any]):
        super().__init__()
        self.backbone, ch = build_backbone(str(model_cfg.get("backbone", "resnet50")), bool(model_cfg.get("pretrained", False)))
        self.pool = nn.AdaptiveAvgPool2d(1)
        self.head_dropout_p = float(model_cfg.get("head_dropout", 0.0))
        self.head = nn.Linear(ch, num_classes)

    def features(self, batch: Mapping[str, Any]) -> dict[str, torch.Tensor]:
        A = self.backbone(batch["image"])
        return {"z": self.pool(A).flatten(1), "A": A}
