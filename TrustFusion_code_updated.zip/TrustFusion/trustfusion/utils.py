"""Seeding, configuration loading and small shared helpers."""
from __future__ import annotations

import copy
import logging
import os
import random
from pathlib import Path
from typing import Any, Iterable, Mapping, MutableMapping, Sequence

import numpy as np
import yaml

REPO_ROOT = Path(__file__).resolve().parents[1]
CONFIG_ROOT = REPO_ROOT / "configs"


# --------------------------------------------------------------------------------------------- logging
def get_logger(name: str = "trustfusion", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s %(name)s: %(message)s", "%H:%M:%S"))
        logger.addHandler(handler)
        logger.setLevel(level)
        logger.propagate = False
    return logger


# --------------------------------------------------------------------------------------------- seeding
def seed_everything(seed: int, deterministic: bool = True) -> None:
    """Seed ``random``, ``numpy`` and ``torch`` and enable deterministic algorithms.

    ``torch.use_deterministic_algorithms(True, warn_only=True)`` is used so that operations without a
    deterministic implementation emit a warning instead of failing.
    """
    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch
    except ImportError:  # pragma: no cover - torch is a hard requirement of the models only
        return
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    if deterministic:
        os.environ.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
        torch.use_deterministic_algorithms(True, warn_only=True)


def worker_init_fn(worker_id: int) -> None:
    """DataLoader worker initialiser: derive numpy / random seeds from the torch worker seed."""
    import torch

    worker_seed = torch.utils.data.get_worker_info().seed % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)


def torch_generator(seed: int):
    import torch

    g = torch.Generator()
    g.manual_seed(seed)
    return g


def resolve_device(name: str | None = "auto"):
    import torch

    if name in (None, "auto"):
        return torch.device("cuda" if torch.cuda.is_available() else "cpu")
    return torch.device(name)


# --------------------------------------------------------------------------------------------- config
def deep_update(base: MutableMapping[str, Any], update: Mapping[str, Any]) -> MutableMapping[str, Any]:
    """Recursively merge ``update`` into a copy of ``base`` (``update`` wins)."""
    out = copy.deepcopy(dict(base))
    for key, value in update.items():
        if isinstance(value, Mapping) and isinstance(out.get(key), Mapping):
            out[key] = deep_update(out[key], value)
        else:
            out[key] = copy.deepcopy(value)
    return out


def _read_yaml_with_bases(path: Path, _seen: tuple[Path, ...] = ()) -> dict[str, Any]:
    path = path.resolve()
    if path in _seen:
        raise ValueError(f"cyclic _base_ chain at {path}")
    with open(path, "r", encoding="utf8") as f:
        cfg = yaml.safe_load(f) or {}
    bases = cfg.pop("_base_", [])
    if isinstance(bases, str):
        bases = [bases]
    merged: dict[str, Any] = {}
    for b in bases:
        merged = deep_update(merged, _read_yaml_with_bases((path.parent / b), _seen + (path,)))
    for key in REPLACE_KEYS & set(cfg):  # a child's search space replaces (never extends) the parent's
        merged.pop(key, None)
    return deep_update(merged, cfg)


#: config keys that a child file replaces wholesale instead of merging recursively
REPLACE_KEYS = {"search_space"}


def set_by_dotted(cfg: MutableMapping[str, Any], key: str, value: Any) -> None:
    parts = key.split(".")
    node = cfg
    for p in parts[:-1]:
        if p not in node or not isinstance(node[p], MutableMapping):
            node[p] = {}
        node = node[p]
    node[parts[-1]] = value


def get_by_dotted(cfg: Mapping[str, Any], key: str, default: Any = None) -> Any:
    node: Any = cfg
    for p in key.split("."):
        if not isinstance(node, Mapping) or p not in node:
            return default
        node = node[p]
    return node


def parse_overrides(items: Iterable[str] | None) -> dict[str, Any]:
    """Parse ``key.sub=value`` strings; values are parsed as YAML scalars/lists."""
    out: dict[str, Any] = {}
    for item in items or []:
        if "=" not in item:
            raise ValueError(f"override must look like key=value, got {item!r}")
        key, raw = item.split("=", 1)
        out[key.strip()] = yaml.safe_load(raw)
    return out


def load_config(
    path: str | os.PathLike,
    corpus: str | None = None,
    protocol: str | None = None,
    overlays: Sequence[str | os.PathLike] | None = None,
    overrides: Iterable[str] | Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Load a YAML config.

    Merge order (later wins): ``_base_`` chain of ``path`` -> ``configs/data/<corpus>.yaml`` is merged
    *underneath* the method config -> ``per_corpus[<corpus>]`` block -> overlay files -> ``key=value``
    overrides. ``corpus`` defaults to the ``corpus`` key of the file; ``protocol`` defaults to the corpus'
    ``default_protocol``.
    """
    path = Path(path)
    cfg = _read_yaml_with_bases(path)
    corpus = corpus or cfg.get("corpus")
    if corpus:
        data_cfg_path = CONFIG_ROOT / "data" / f"{corpus}.yaml"
        if data_cfg_path.exists():
            cfg = deep_update(_read_yaml_with_bases(data_cfg_path), cfg)
        cfg["corpus"] = corpus
        per_corpus = cfg.pop("per_corpus", {}) or {}
        if corpus in per_corpus:
            cfg = deep_update(cfg, per_corpus[corpus])
    else:
        cfg.pop("per_corpus", None)
    for ov in overlays or []:
        cfg = deep_update(cfg, _read_yaml_with_bases(Path(ov)))
    if isinstance(overrides, Mapping):
        ov_items = dict(overrides)
    else:
        ov_items = parse_overrides(overrides)
    for k, v in ov_items.items():
        set_by_dotted(cfg, k, v)
    if protocol:
        cfg["protocol"] = protocol
    if cfg.get("protocol") is None and cfg.get("default_protocol"):
        cfg["protocol"] = cfg["default_protocol"]
    protocols = cfg.get("protocols")
    proto = protocols.get(cfg.get("protocol"), {}) if isinstance(protocols, Mapping) else {}
    if proto:
        cfg["task"] = proto.get("task", cfg.get("task"))
        cfg["temporal"] = bool(proto.get("temporal", False))
    cfg["_config_path"] = str(path)
    return cfg


def save_config(cfg: Mapping[str, Any], path: str | os.PathLike) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf8") as f:
        yaml.safe_dump(dict(cfg), f, sort_keys=False)


def resolve_path(p: str | os.PathLike, root: str | os.PathLike | None = None) -> Path:
    """Resolve a (possibly relative) path against ``root`` (default: current dir, then repo root)."""
    p = Path(p)
    if p.is_absolute():
        return p
    if root is not None:
        return Path(root) / p
    if p.exists():
        return p.resolve()
    return REPO_ROOT / p


def sample_search_space(space: Mapping[str, Sequence[Any]], trials: int, seed: int) -> list[dict[str, Any]]:
    """Random search over a discrete grid: ``min(trials, |grid|)`` distinct draws, seeded.

    Each draw is a mapping ``dotted.key -> value``. Draws are without replacement so the 20-trial budget
    is never spent on duplicate configurations; for grids with <= ``trials`` points this visits the
    complete grid in random order.
    """
    keys = sorted(space)
    sizes = [len(space[k]) for k in keys]
    total = int(np.prod(sizes)) if keys else 1
    rng = np.random.default_rng(seed)
    n = min(trials, total)
    flat = rng.choice(total, size=n, replace=False)
    draws = []
    for code in flat:
        cfg = {}
        rem = int(code)
        for k, s in zip(reversed(keys), reversed(sizes)):
            rem, j = divmod(rem, s)
            cfg[k] = space[k][j]
        draws.append(dict(sorted(cfg.items())))
    return draws
