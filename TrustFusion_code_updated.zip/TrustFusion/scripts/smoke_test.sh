#!/usr/bin/env bash
# Tiny SYNTHETIC end-to-end run on CPU (a few minutes on 2 cores). Everything is written to a temporary directory
# that is removed on exit; runs/, results/, splits/ and paper_figures/data/ are never touched (checked at the end).
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
PY="${PYTHON:-python}"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/trustfusion_smoke.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
export PYTHONWARNINGS="ignore"

TINY="tests/configs/tiny.yaml"
PATHS=(--data-root "$TMP/data/processed" --splits "$TMP/splits" --runs "$TMP/runs" --device cpu)
figures_before="$(cat paper_figures/data/*.csv | sha256sum)"
step() { printf '\n=== %s ===\n' "$*"; }

step "1/9 synthetic corpus (random bytes / vectors / timestamps)"
$PY scripts/make_synthetic.py --out "$TMP/data" --seed 0

step "2/9 splits"
$PY scripts/make_splits.py --corpus bodmas --processed "$TMP/data/processed/bodmas" --out "$TMP/splits" --min-family-size 5

step "3/9 TrustFusion, P-R family task, 1 epoch at 32x32"
$PY scripts/train.py --config configs/trustfusion/bodmas_pr.yaml --overlay "$TINY" "${PATHS[@]}" --seeds 0

step "4/9 split-conformal calibration + evaluation"
$PY scripts/calibrate.py --run "$TMP/runs/bodmas/pr_family/trustfusion"
$PY scripts/evaluate.py --run "$TMP/runs/bodmas/pr_family/trustfusion"
test -f "$TMP/runs/bodmas/pr_family/trustfusion/seed0/probs.npz"

step "5/9 baselines: conformal-gated LightGBM, feature-graph GCN"
$PY scripts/train_gbdt.py --config configs/baselines/conformal_lgbm.yaml --corpus bodmas --overlay "$TINY" "${PATHS[@]}" --seeds 0
$PY scripts/calibrate.py --run "$TMP/runs/bodmas/pr_family/conformal_lgbm"
$PY scripts/evaluate.py --run "$TMP/runs/bodmas/pr_family/conformal_lgbm"
$PY scripts/train.py --config configs/baselines/feature_graph.yaml --corpus bodmas --overlay "$TINY" "${PATHS[@]}" --seeds 0

step "6/9 P-T protocol: frozen model + chronological deployment (static D1 and weighted sliding window)"
$PY scripts/train.py --config configs/trustfusion/bodmas_pt.yaml --overlay "$TINY" "${PATHS[@]}" --seeds 0
$PY scripts/run_temporal.py --run "$TMP/runs/bodmas/pt_family/trustfusion" --mode both
test -f "$TMP/runs/bodmas/pt_family/trustfusion/seed0/temporal_sliding.csv"

step "7/9 faithfulness (deletion / insertion AUC) on 2 synthetic byte files"
$PY scripts/run_faithfulness.py --run "$TMP/runs/bodmas/pr_family/trustfusion/seed0" --data-root "$TMP/data/processed" \
    --splits "$TMP/splits" --n-samples 2 --extractor histogram_only --out "$TMP/results/faithfulness" --device cpu

step "8/9 seed statistics on synthetic prediction files"
$PY scripts/make_synthetic.py --predictions-out "$TMP/synthetic_runs"
cat > "$TMP/comparisons.yaml" <<'EOF'
comparisons:
  - {name: synthetic_macro_f1, corpus: synthetic, protocol: pr_family, metric: macro_f1, a: synthetic_b, b: synthetic_a}
  - {name: synthetic_ece,      corpus: synthetic, protocol: pr_family, metric: ece,      a: synthetic_b, b: synthetic_a}
  - {name: synthetic_pt_loss,  corpus: synthetic, protocol: pt_family, metric: pt_loss,  a: synthetic_b, b: synthetic_a}
EOF
$PY scripts/seed_stats.py --runs "$TMP/synthetic_runs" --corpus synthetic --protocol pr_family \
    --methods synthetic_a synthetic_b --metrics accuracy macro_f1 ece coverage mean_set_size --out "$TMP/results/tables/seed_stats.csv"
$PY scripts/seed_stats.py --paired --comparisons "$TMP/comparisons.yaml" --runs "$TMP/synthetic_runs" --n-boot 200 \
    --out "$TMP/results/tables/paired.csv"
test -f "$TMP/results/tables/paired.csv"

step "9/9 aggregation into temporary directories"
$PY scripts/aggregate_results.py --runs "$TMP/runs" --results "$TMP/results" --figures-out "$TMP/figures" --skip-table5

figures_after="$(cat paper_figures/data/*.csv | sha256sum)"
if [ "$figures_before" != "$figures_after" ]; then
    echo "ERROR: paper_figures/data was modified by the smoke test" >&2
    exit 1
fi
printf '\nSMOKE TEST PASSED\n'
