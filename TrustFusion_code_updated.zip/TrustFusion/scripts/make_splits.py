#!/usr/bin/env python
"""Build every split of a corpus (split seed 2024) and record the counts in ``splits/summary.json``.

Outputs ``splits/<corpus>_<protocol>.csv`` (columns row, sample_id, split, window, label, timestamp: sha256 lists
with first-seen timestamps), ``splits/<corpus>_<protocol>_classes.json`` and the ``<corpus>`` entry of
``splits/summary.json`` (Table 2 counts, benign-source counts, P-T named families, EMBER2024 family-subset totals
next to the malicious totals they are drawn from, MalNet unmatched count and MalNet detection benign source).

``--check-counts`` asserts every count the manuscript reports (values in ``configs/data/<corpus>.yaml``): BODMAS
57,293 malicious / 24,180 benign (Windows 10 11,368, Windows 11 9,527, repositories 3,285), P-R 40,105 / 4,297 /
4,297 / 8,594 (97 classes) and 33,852 / 3,627 / 3,627 / 7,254, P-T 68 families + residual; EMBER2024 2,358 families,
family subset 1,101,898 training / 254,284 test files, detection subset 2,340,000 / 540,000; MalNet-Tiny 61,201 /
4,371 / 4,372 / 17,486 (43 types), 1,286 files without a call graph and, for detection, 5,000 ``googleplay`` benign
files.

Examples::

    python scripts/make_splits.py --corpus bodmas --check-counts
    python scripts/make_splits.py --corpus ember2024 --check-counts
    python scripts/make_splits.py --corpus malnet_tiny --check-counts [--benign-source googleplay]
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from trustfusion.data import splits as S  # noqa: E402
from trustfusion.data.datasets import load_corpus  # noqa: E402
from trustfusion.utils import CONFIG_ROOT, get_logger, load_config  # noqa: E402

log = get_logger("make_splits")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--corpus", required=True, choices=["bodmas", "ember2024", "malnet_tiny"])
    ap.add_argument("--processed", default=None, help="processed corpus dir (default: data/processed/<corpus>)")
    ap.add_argument("--out", default="splits")
    ap.add_argument("--seed", type=int, default=None, help="split seed (default: configs/base.yaml split_seed = 2024)")
    ap.add_argument("--min-family-size", type=int, default=None, help="override the family threshold (tests only)")
    ap.add_argument("--benign-source", default=None, help="MalNet detection: explicit benign source name")
    ap.add_argument("--check-counts", action="store_true", help="assert the manuscript's counts")
    args = ap.parse_args()

    base = load_config(CONFIG_ROOT / "base.yaml")
    cfg = load_config(CONFIG_ROOT / "data" / f"{args.corpus}.yaml")
    seed = int(args.seed if args.seed is not None else base["split_seed"])
    sc = cfg["splits"]
    corpus = load_corpus(args.processed or Path("data/processed") / args.corpus)
    meta = corpus.meta
    check = args.check_counts
    written = {}

    if args.corpus == "bodmas":
        mfs = int(args.min_family_size or sc["min_family_size"])
        if check:
            n_mal = int((meta["is_malicious"] == 1).sum())
            n_ben = int((meta["is_malicious"] == 0).sum())
            assert n_mal == sc["expected_malicious"] and n_ben == sc["expected_benign"], (n_mal, n_ben)
        df, classes, summ = S.bodmas_pr_family(meta, seed, mfs, sc["expected_counts"]["pr_family"] if check else None)
        if check:
            assert len(classes) == sc["expected_classes"], len(classes)
        written["pr_family"] = (df, classes, summ)
        det, dclasses, dsumm = S.bodmas_pr_detection(meta, seed, mfs, sc["expected_counts"]["pr_detection"] if check else None)
        written["pr_detection"] = (det, dclasses, dsumm)
        pt_cfg = dict(cfg["pt"])
        if args.min_family_size:
            pt_cfg["min_family_size"] = args.min_family_size
        written["pt_family"] = S.bodmas_pt(meta, seed, pt_cfg, pt_cfg.get("expected_named_families") if check else None)
        cs = sc["cross_source"]
        written["pr_crosssource"] = S.bodmas_cross_source(det, meta, cs["train_sources"], cs["test_source"], cs["test_benign_from"])
        pool = {str(k): int(v) for k, v in meta.loc[meta["is_malicious"] == 0, "benign_source"].value_counts().items()}
        if check:
            S.check_counts(sc["expected_benign_sources"], pool, "bodmas benign pool by source")
        written["benign_pool"] = (None, None, {"benign_sources": pool})
    elif args.corpus == "ember2024":
        if check:
            rel = meta["released_split"].value_counts().to_dict()
            assert rel.get("train") == sc["expected_official"]["train"] and rel.get("test") == sc["expected_official"]["test"], rel
        written["family_subset"] = S.ember2024_family_subset(
            meta, seed, int(args.min_family_size or sc["family_min_count"]), sc["calibration_window"], sc["validation_fraction"],
            sc["expected_families"] if check else None, sc["expected_family"] if check else None)
        written["detection_subset"] = S.ember2024_detection_subset(
            meta, seed, sc["detection_formats"], sc["validation_fraction"], sc["expected_detection"] if check else None)
    else:
        written["tiny_type"] = S.malnet_tiny_type(meta, seed, sc["expected_counts"] if check else None,
                                                  sc["expected_types"] if check else None,
                                                  sc["expected_graph_unmatched"] if check else None)
        if args.benign_source:
            expected_benign = sc["expected_benign"] if check and args.benign_source == sc["benign_source_name"] else None
            written["tiny_detection"] = S.malnet_tiny_detection(meta, args.benign_source, seed, expected_benign)
        else:
            written["tiny_detection"] = (None, None, {"benign_source": None,
                                                      "note": "not built: MalNet-Tiny has no benign class; pass --benign-source"})

    for protocol, (df, classes, summ) in written.items():
        summ = dict(summ, split_seed=seed)
        if df is not None:
            path = S.write_split(df, classes, args.out, args.corpus, protocol)
            summ["file"] = str(path)
        S.update_summary(args.out, args.corpus, protocol, summ)
        log.info("%s/%s: %s", args.corpus, protocol, json.dumps(summ.get("counts", summ), default=str))


if __name__ == "__main__":
    main()
