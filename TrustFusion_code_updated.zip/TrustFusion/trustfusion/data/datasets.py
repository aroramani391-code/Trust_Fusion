"""Processed-corpus format, paired-view datasets and synthetic data for tests.

Processed corpus directory (written by ``scripts/prepare_*.py``)::

    <processed>/<corpus>/
        meta.csv.gz     one row per file (columns: META_COLUMNS)
        static.npy      float32 [N, D] descriptor matrix (EMBER v2 / v3 vector or 48-d call-graph descriptor)
        corpus.json     corpus name, feature layout, view kinds, preparation counts

``image_kind`` is ``bytes`` (raw binary rendered on the fly: BODMAS), ``png`` (pre-rendered image: MalNet-Image)
or empty (no image view: EMBER2024, whose image view is permanently masked). ``has_static`` is 0 for MalNet
samples without a MalNet-Graph match (graph view masked).
"""
from __future__ import annotations

import hashlib
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset

from ..io import read_json, write_json
from .byte_image import ChannelStats, entropy_jitter, load_png_image, render_byte_image, truncate_overlay
from .static_features import FeatureLayout, StaticTransform, load_layout

META_COLUMNS = ["sample_id", "sha256", "family", "is_malicious", "timestamp", "benign_source", "file_format",
                "released_split", "image_path", "image_kind", "has_static", "graph_path"]
_STR_COLUMNS = ["sample_id", "sha256", "family", "timestamp", "benign_source", "file_format", "released_split",
                "image_path", "image_kind", "graph_path"]


# --------------------------------------------------------------------------------------------- corpus files
@dataclass
class CorpusData:
    root: Path
    meta: pd.DataFrame
    static: np.ndarray | None
    info: dict = field(default_factory=dict)

    def resolve(self, rel: str) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else self.root / p

    @property
    def layout(self) -> FeatureLayout | None:
        return load_layout(self.info["layout"]) if self.info.get("layout") else None


def write_corpus(out_dir: str | os.PathLike, meta: pd.DataFrame, static: np.ndarray | None, info: Mapping[str, Any]) -> Path:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    meta = meta.copy()
    for col in META_COLUMNS:
        if col not in meta.columns:
            meta[col] = "" if col in _STR_COLUMNS else 0
    meta = meta[META_COLUMNS]
    if meta["sample_id"].duplicated().any():
        raise ValueError("sample_id must be unique")
    meta.to_csv(out / "meta.csv.gz", index=False, compression="gzip")
    if static is not None:
        if static.shape[0] != len(meta):
            raise ValueError("static matrix and metadata have different row counts")
        np.save(out / "static.npy", np.asarray(static, dtype=np.float32))
    write_json(out / "corpus.json", dict(info))
    return out


def load_corpus(corpus_dir: str | os.PathLike) -> CorpusData:
    root = Path(corpus_dir)
    meta = pd.read_csv(root / "meta.csv.gz", dtype={c: str for c in _STR_COLUMNS}, keep_default_na=False)
    static_path = root / "static.npy"
    static = np.load(static_path, mmap_mode="r") if static_path.exists() else None
    info = read_json(root / "corpus.json") if (root / "corpus.json").exists() else {}
    return CorpusData(root=root, meta=meta, static=static, info=info)


# --------------------------------------------------------------------------------------------- paired views
class PairedViewDataset(Dataset):
    """Returns ``image``, ``static``, ``has_image``, ``has_static``, ``label`` and ``index`` for a split.

    ``views.image`` in the data config selects ``bytes`` / ``png`` / ``none``. When the image view is ``none`` (or
    disabled) ``image`` is an empty tensor and ``has_image`` is False, so models skip the image encoder.
    Augmentation (training only): overlay truncation on PE bytes (p=0.3, U(0, 0.5) of the overlay) and entropy
    jitter x U(0.95, 1.05); no flips or crops.
    """

    def __init__(self, corpus: CorpusData, split_df: pd.DataFrame, data_cfg: Mapping[str, Any], train: bool = False,
                 static_transform: StaticTransform | None = None, image_stats: ChannelStats | None = None,
                 use_image: bool = True, use_static: bool = True):
        self.corpus = corpus
        self.rows = split_df["row"].to_numpy(dtype=np.int64)
        self.labels = split_df["label"].to_numpy(dtype=np.int64)
        self.sample_ids = split_df["sample_id"].astype(str).to_numpy()
        img = dict(data_cfg.get("image", {}))
        views = dict(data_cfg.get("views", {}))
        self.image_view = views.get("image", "bytes") if use_image else "none"
        self.static_view = views.get("static", "vector") if use_static else "none"
        self.size = int(img.get("size", 224))
        self.channels = list(img.get("channels", ["grey", "entropy", "bigram"]))
        self.window = int(img.get("entropy_window", 256))
        self.stride = int(img.get("entropy_stride", 128))
        self.antialias = bool(img.get("antialias", True))
        self.augment = dict(img.get("augment", {}) or {}) if train else {}
        self.static_transform = static_transform
        self.image_stats = image_stats
        cache = img.get("cache_dir")
        tag = f"{self.size}_{'-'.join(self.channels)}_{self.window}_{self.stride}_{int(self.antialias)}"
        self.cache_dir = Path(cache) / tag if cache else None
        meta = corpus.meta
        self._image_path = meta["image_path"].to_numpy()
        self._image_kind = meta["image_kind"].to_numpy()
        self._has_static = meta["has_static"].to_numpy().astype(bool)
        n_ch = 3 if self.channels == ["grey3"] else len(self.channels)
        self._n_channels = n_ch

    def __len__(self) -> int:
        return int(self.rows.size)

    def read_bytes(self, row: int) -> np.ndarray:
        with open(self.corpus.resolve(self._image_path[row]), "rb") as f:
            return np.frombuffer(f.read(), dtype=np.uint8)

    def _cache_path(self, key: str) -> Path | None:
        return self.cache_dir / key[:2] / f"{key}.npy" if self.cache_dir is not None and key else None

    def render(self, data: np.ndarray, rng: np.random.Generator | None = None, cache_key: str | None = None) -> torch.Tensor:
        """Render (and optionally augment) raw bytes; normalisation is applied by :meth:`normalise`.

        With ``data.image.cache_dir`` the un-augmented float32 rendering of the *original* file is cached per sha256;
        files whose overlay was truncated by the augmentation are always re-rendered, so results are identical with
        and without the cache.
        """
        aug = self.augment if rng is not None else {}
        n_original = data.size
        ot = aug.get("overlay_truncation")
        if ot:
            data = truncate_overlay(data, rng, p=float(ot.get("p", 0.3)), max_fraction=float(ot.get("max_fraction", 0.5)))
        path = self._cache_path(cache_key) if data.size == n_original else None
        img = None
        if path is not None and path.exists():
            img = torch.from_numpy(np.load(path))
        if img is None:
            img = render_byte_image(data, self.size, self.channels, self.window, self.stride, self.antialias)
            if path is not None:
                path.parent.mkdir(parents=True, exist_ok=True)
                tmp = path.with_suffix(f".{os.getpid()}.tmp.npy")
                np.save(tmp, img.numpy().astype(np.float32))
                os.replace(tmp, path)
        jit = aug.get("entropy_jitter")
        if jit and "entropy" in self.channels:
            img = entropy_jitter(img, rng, channel=self.channels.index("entropy"), low=float(jit[0]), high=float(jit[1]))
        return img

    def normalise(self, img: torch.Tensor) -> torch.Tensor:
        return self.image_stats.normalise(img) if self.image_stats is not None else img

    def load_image(self, row: int, rng: np.random.Generator | None = None, normalise: bool = True) -> tuple[torch.Tensor, bool]:
        if self.image_view == "none":
            return torch.zeros(0), False
        kind, path = self._image_kind[row], self._image_path[row]
        empty = torch.zeros(self._n_channels, self.size, self.size)
        if not path or not kind:
            return empty, False
        if kind == "bytes":
            img = self.render(self.read_bytes(row), rng, cache_key=str(self.corpus.meta["sample_id"].iat[row]))
        elif kind == "png":
            img = load_png_image(str(self.corpus.resolve(path)), self.size, self.antialias)
        else:
            raise ValueError(f"unknown image_kind {kind!r}")
        return (self.normalise(img) if normalise else img), True

    def load_static(self, row: int) -> tuple[torch.Tensor, bool]:
        if self.static_view == "none" or self.corpus.static is None:
            return torch.zeros(0), False
        vec = np.array(self.corpus.static[row], dtype=np.float32)  # copy: memory-mapped rows are read-only
        if self.static_transform is not None:
            vec = self.static_transform.transform(vec)
        return torch.from_numpy(np.ascontiguousarray(vec, dtype=np.float32)), bool(self._has_static[row])

    def __getitem__(self, i: int) -> dict[str, Any]:
        row = int(self.rows[i])
        rng = np.random.default_rng(int(torch.randint(0, 2**31 - 1, (1,)).item())) if self.augment else None
        image, has_image = self.load_image(row, rng)
        static, has_static = self.load_static(row)
        if not has_static and static.numel():
            static = torch.zeros_like(static)
        return {"image": image, "static": static, "has_image": has_image, "has_static": has_static,
                "label": int(self.labels[i]), "index": i}


def default_data_cfg(corpus: str) -> dict[str, Any]:
    """``data`` block of ``configs/data/<corpus>.yaml``."""
    from ..utils import CONFIG_ROOT, load_config

    return dict(load_config(CONFIG_ROOT / "data" / f"{corpus}.yaml")["data"])


class BODMASDataset(PairedViewDataset):
    """BODMAS: byte image rendered from the (disarmed) binary + 2,381-d EMBER v2 vector.

    Files without an available binary keep the static view and use the image mask token.
    """

    corpus_name = "bodmas"

    def __init__(self, corpus: CorpusData, split_df: pd.DataFrame, data_cfg: Mapping[str, Any] | None = None, **kw: Any):
        super().__init__(corpus, split_df, data_cfg or default_data_cfg(self.corpus_name), **kw)


class EMBER2024Dataset(PairedViewDataset):
    """EMBER2024: 2,568-d vector only; the image view is permanently masked (single-stream mode)."""

    corpus_name = "ember2024"

    def __init__(self, corpus: CorpusData, split_df: pd.DataFrame, data_cfg: Mapping[str, Any] | None = None, **kw: Any):
        kw["use_image"] = False
        super().__init__(corpus, split_df, data_cfg or default_data_cfg(self.corpus_name), **kw)


class MalNetTinyDataset(PairedViewDataset):
    """MalNet-Image Tiny: released DEX image + 48-d call-graph descriptor (graph view masked when unmatched)."""

    corpus_name = "malnet_tiny"

    def __init__(self, corpus: CorpusData, split_df: pd.DataFrame, data_cfg: Mapping[str, Any] | None = None, **kw: Any):
        super().__init__(corpus, split_df, data_cfg or default_data_cfg(self.corpus_name), **kw)


DATASETS: dict[str, type[PairedViewDataset]] = {"bodmas": BODMASDataset, "ember2024": EMBER2024Dataset,
                                                "malnet_tiny": MalNetTinyDataset}


class RawImageDataset(Dataset):
    """Un-normalised, un-augmented images of a :class:`PairedViewDataset` (training-split channel statistics)."""

    def __init__(self, ds: PairedViewDataset, max_samples: int | None = None):
        self.ds = ds
        self.n = len(ds) if max_samples is None else min(len(ds), int(max_samples))

    def __len__(self) -> int:
        return self.n

    def __getitem__(self, i: int) -> dict[str, Any]:
        img, has = self.ds.load_image(int(self.ds.rows[i]), rng=None, normalise=False)
        return {"image": img, "has_image": has, "index": i}


def image_stats_images(ds: PairedViewDataset, max_samples: int | None = None):
    """Yield un-normalised, un-augmented training images for :func:`compute_channel_stats` (single process)."""
    raw = RawImageDataset(ds, max_samples)
    for i in range(len(raw)):
        item = raw[i]
        if item["has_image"]:
            yield item["image"]


# --------------------------------------------------------------------------------------------- call graphs
def read_edge_index(path: str | os.PathLike) -> tuple[np.ndarray, int]:
    """Read a MalNet-Graph edge list into an integer ``[2, E]`` array (node ids factorised)."""
    df = pd.read_csv(path, sep=r"\s+", comment="#", header=None, usecols=[0, 1], dtype=str, engine="python")
    if df.empty:
        return np.zeros((2, 0), dtype=np.int64), 1
    codes, uniques = pd.factorize(pd.concat([df[0], df[1]], ignore_index=True))
    e = codes.reshape(2, -1).astype(np.int64)
    return e, int(len(uniques))


def local_degree_profile(edge_index: np.ndarray, n: int) -> np.ndarray:
    """LDP node features (Cai & Wang, 2018): degree and min/max/mean/std of neighbour degrees (log1p)."""
    if edge_index.shape[1] == 0:
        return np.zeros((n, 5), dtype=np.float32)
    und = np.concatenate([edge_index, edge_index[::-1]], axis=1)
    und = und[:, und[0] != und[1]]
    deg = np.bincount(und[0], minlength=n).astype(np.float64)
    nd = deg[und[1]]
    s = np.bincount(und[0], weights=nd, minlength=n)
    s2 = np.bincount(und[0], weights=nd ** 2, minlength=n)
    mn = np.full(n, np.inf)
    mx = np.zeros(n)
    np.minimum.at(mn, und[0], nd)
    np.maximum.at(mx, und[0], nd)
    mn[~np.isfinite(mn)] = 0
    with np.errstate(invalid="ignore", divide="ignore"):
        mean = np.where(deg > 0, s / np.maximum(deg, 1), 0)
        std = np.sqrt(np.clip(np.where(deg > 0, s2 / np.maximum(deg, 1), 0) - mean ** 2, 0, None))
    feats = np.stack([deg, mn, mx, mean, std], axis=1)
    return np.log1p(feats).astype(np.float32)


class CallGraphDataset(Dataset):
    """Call graphs (MalNet-Graph edge lists) with local-degree-profile node features for the structural GIN."""

    def __init__(self, corpus: CorpusData, split_df: pd.DataFrame):
        self.corpus = corpus
        self.rows = split_df["row"].to_numpy(dtype=np.int64)
        self.labels = split_df["label"].to_numpy(dtype=np.int64)
        self._paths = corpus.meta["graph_path"].to_numpy()

    def __len__(self) -> int:
        return int(self.rows.size)

    def __getitem__(self, i: int) -> dict[str, Any]:
        path = self._paths[int(self.rows[i])]
        if path:
            e, n = read_edge_index(self.corpus.resolve(path))
            has = True
        else:
            e, n, has = np.zeros((2, 0), dtype=np.int64), 1, False
        return {"x": torch.from_numpy(local_degree_profile(e, n)), "edge_index": torch.from_numpy(e),
                "label": int(self.labels[i]), "index": i, "has_graph": has}


def collate_graphs(batch: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    xs, eis, bvec = [], [], []
    offset = 0
    for g, item in enumerate(batch):
        n = item["x"].shape[0]
        xs.append(item["x"])
        eis.append(item["edge_index"] + offset)
        bvec.append(torch.full((n,), g, dtype=torch.long))
        offset += n
    return {"x": torch.cat(xs), "edge_index": torch.cat(eis, dim=1), "batch": torch.cat(bvec),
            "num_graphs": len(batch), "label": torch.tensor([b["label"] for b in batch]),
            "index": torch.tensor([b["index"] for b in batch])}


# --------------------------------------------------------------------------------------------- synthetic data
def synthetic_pe_bytes(rng: np.random.Generator, n_bytes: int, cls: int, n_classes: int, overlay: int = 0) -> bytes:
    """SYNTHETIC minimal PE32 file with .text/.rdata/.data sections, an import directory and an overlay.

    Section content follows a class-dependent byte distribution so that tiny models can learn something.
    """
    import struct

    n_bytes = max(n_bytes, 0x800 + overlay)
    header = bytearray(0x400)
    header[0:2] = b"MZ"
    struct.pack_into("<I", header, 0x3C, 0x80)
    header[0x80:0x84] = b"PE\x00\x00"
    body = n_bytes - 0x400 - overlay
    sizes = [body // 2, body // 4, body - body // 2 - body // 4]
    names = [b".text", b".rdata", b".data"]
    struct.pack_into("<HHIIIHH", header, 0x84, 0x14C, 3, 0, 0, 0, 224, 0x102)
    opt = 0x84 + 20
    struct.pack_into("<H", header, opt, 0x10B)
    struct.pack_into("<I", header, opt + 60, 0x400)  # SizeOfHeaders
    struct.pack_into("<I", header, opt + 92, 16)  # NumberOfRvaAndSizes
    raw_ptr = 0x400
    va = 0x1000
    sec_table = opt + 224
    rdata_va = 0
    for k, (name, size) in enumerate(zip(names, sizes)):
        off = sec_table + 40 * k
        header[off:off + 8] = name.ljust(8, b"\x00")
        struct.pack_into("<IIII", header, off + 8, size, va, size, raw_ptr)
        if name == b".rdata":
            rdata_va = va
        raw_ptr += size
        va += ((size + 0xFFF) // 0x1000) * 0x1000
    struct.pack_into("<II", header, opt + 96 + 8, rdata_va + 16, min(256, sizes[1] - 16))  # import directory
    probs = np.random.default_rng(1000 + cls).dirichlet(np.full(256, 0.3))
    content = rng.choice(256, size=body, p=probs).astype(np.uint8)
    marker = np.frombuffer(bytes([(cls * 37 + j * 11) % 256 for j in range(16)]), dtype=np.uint8)
    for pos in range(0, body - 16, max(64, body // (8 + cls))):
        content[pos:pos + 16] = marker
    tail = rng.integers(0, 256, size=overlay, dtype=np.uint8)
    return bytes(header) + content.tobytes() + tail.tobytes()


def make_synthetic_corpus(out_dir: str | os.PathLike, seed: int = 0, n_families: int = 6,
                          per_family: tuple[int, int] = (34, 44), n_rare_families: int = 10,
                          n_benign_per_source: int = 30, layout: str = "ember_v2",
                          start: str = "2019-08-01", end: str = "2020-10-01", size_range: tuple[int, int] = (2500, 40000)
                          ) -> Path:
    """Write a tiny SYNTHETIC BODMAS-like processed corpus (binaries, EMBER-layout vectors, timestamps, sources).

    All values are random and exist only to exercise the pipeline in tests / smoke tests.
    """
    rng = np.random.default_rng(seed)
    out = Path(out_dir)
    (out / "binaries").mkdir(parents=True, exist_ok=True)
    lay = load_layout(layout)
    t0, t1 = pd.Timestamp(start).value, pd.Timestamp(end).value
    rows = []
    fams: list[tuple[str, int]] = []
    for f in range(n_families):
        fams += [(f"synfam{f:02d}", f)] * int(rng.integers(per_family[0], per_family[1] + 1))
    for r in range(n_rare_families):
        fams += [(f"synrare{r:02d}", n_families)] * int(rng.integers(1, 4))
    n_cls = n_families + 2
    static = []
    means = np.random.default_rng(seed + 99).normal(0, 1, size=(n_cls, lay.dim)).astype(np.float32)
    for i, (fam, cls) in enumerate(fams):
        rows.append(dict(family=fam, is_malicious=1, benign_source="", cls=cls))
    for src in ("win10", "win11", "repo"):
        for _ in range(n_benign_per_source):
            rows.append(dict(family="", is_malicious=0, benign_source=src, cls=n_cls - 1))
    for i, r in enumerate(rows):
        sid = hashlib.sha256(f"synthetic-{seed}-{i}".encode()).hexdigest()
        size = int(rng.integers(*size_range))
        data = synthetic_pe_bytes(rng, size, r["cls"], n_cls, overlay=int(rng.integers(0, 600)))
        (out / "binaries" / sid).write_bytes(data)
        vec = means[r["cls"]] + rng.normal(0, 1.5, size=lay.dim).astype(np.float32)
        vec[lay.group_indices()[0]] = np.abs(vec[lay.group_indices()[0]])
        static.append(vec)
        r.update(sample_id=sid, sha256=sid, image_path=f"binaries/{sid}", image_kind="bytes", has_static=1,
                 timestamp=str(pd.Timestamp(int(rng.integers(t0, t1))).floor("s")), file_format="Win32",
                 released_split="", graph_path="")
    meta = pd.DataFrame(rows).drop(columns=["cls"])
    info = {"corpus": "bodmas", "synthetic": True, "layout": layout, "views": {"image": "bytes", "static": "vector"},
            "note": "SYNTHETIC data generated by trustfusion.data.datasets.make_synthetic_corpus"}
    write_corpus(out, meta, np.stack(static), info)
    return out


def make_synthetic_predictions(runs_root: str | os.PathLike, methods: Sequence[str] = ("synthetic_a", "synthetic_b"),
                               seeds: Sequence[int] = (0, 1, 2), n: int = 400, n_classes: int = 5, seed: int = 0,
                               corpus: str = "synthetic", protocols: Sequence[str] = ("pr_family", "pt_family")) -> Path:
    """Write SYNTHETIC per-sample prediction files (random numbers) for exercising seed statistics."""
    from ..conformal import prediction_sets, split_conformal_quantile
    from ..io import prediction_frame, run_dir, write_predictions, write_probs

    root = Path(runs_root)
    base = np.random.default_rng(seed)
    y = base.integers(0, n_classes, size=n)
    windows = np.array([f"W{k}" for k in base.integers(1, 8, size=n)])
    for protocol in protocols:
        for mi, method in enumerate(methods):
            for s in seeds:
                rng = np.random.default_rng(1000 * (mi + 1) + s)
                logits = rng.normal(0, 1, size=(n, n_classes))
                logits[np.arange(n), y] += 1.5 + 0.3 * mi
                if protocol == "pt_family":
                    logits[np.arange(n), y] -= 0.2 * np.char.lstrip(windows, "W").astype(int)
                p = np.exp(logits) / np.exp(logits).sum(1, keepdims=True)
                qhat = split_conformal_quantile(1 - p[np.arange(n), y][: n // 2], 0.05)
                sets = prediction_sets(p, qhat)
                sizes = sets.sum(1)
                df = prediction_frame(
                    n, sample_id=[f"syn{i:05d}" for i in range(n)], corpus=corpus, task="family", protocol=protocol,
                    split="test", window=windows if protocol == "pt_family" else "", seed=s, method=method,
                    y_true=y, y_pred=p.argmax(1), p_max=p.max(1), p_true=p[np.arange(n), y],
                    entropy=-(p * np.log(p)).sum(1), mutual_info=np.zeros(n), gate=np.full(n, np.nan),
                    set_size=sizes, in_set=sets[np.arange(n), y], accepted=sizes == 1, benign_source="", timestamp="")
                d = run_dir(root, corpus, protocol, method, s)
                write_predictions(df, d)
                write_probs(d, p, df["sample_id"].to_numpy())
    return root
