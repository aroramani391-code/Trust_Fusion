import numpy as np
import pandas as pd
import pytest

from trustfusion.data.splits import DEFAULT_PT, pt_window_bounds
from trustfusion.temporal import calibration_pool, run_deployment

BOUNDS = pt_window_bounds(DEFAULT_PT)


def synthetic_stream(seed: int = 0, per_window: int = 400, C: int = 6):
    rng = np.random.default_rng(seed)
    ts, labels = [], []
    for name in ["D1"] + [f"W{k}" for k in range(1, 8)]:
        lo, hi = BOUNDS[name]
        ts += list(pd.to_datetime(rng.integers(lo.value, hi.value, size=per_window)))
        labels += [name] * per_window
    n = len(ts)
    p = rng.dirichlet(np.ones(C) * 0.5, size=n)
    y = np.array([rng.choice(C, p=row) for row in p])
    return p, y, pd.Series(ts).astype(str).to_numpy(), np.array(labels)


def test_sliding_never_uses_current_window_for_calibration():
    p, y, ts, labels = synthetic_stream()
    res = run_deployment(p, y, ts, labels, BOUNDS, mode="sliding")
    tsd = pd.to_datetime(pd.Series(ts)).to_numpy()
    for k in range(1, 8):
        wk = f"W{k}"
        cal = res.calibration_indices[wk]
        cur = np.flatnonzero(labels == wk)
        assert np.intersect1d(cal, cur).size == 0
        assert (tsd[cal] < np.datetime64(BOUNDS[wk][0])).all()
        assert set(labels[cal]) == {"D1" if k == 1 else f"W{k - 1}"}
        assert res.samples.loc[res.samples["window"] == wk, "qhat"].nunique() == 1  # frozen during W_k
    assert (res.windows["n_eff"] < res.windows["n_cal"]).all()


def test_label_delay_and_static_mode():
    p, y, ts, labels = synthetic_stream(1)
    res = run_deployment(p, y, ts, labels, BOUNDS, mode="sliding", label_delay_months=1)
    assert [calibration_pool(k, 1) for k in range(1, 8)] == ["D1", "D1", "W1", "W2", "W3", "W4", "W5"]
    for k in range(1, 8):
        assert set(labels[res.calibration_indices[f"W{k}"]]) == {calibration_pool(k, 1)}
    st = run_deployment(p, y, ts, labels, BOUNDS, mode="static")
    assert st.windows["qhat"].nunique() == 1 and set(st.windows["calibration_pool"]) == {"D1"}
    assert st.windows["coverage"].mean() == pytest.approx(0.95, abs=0.03)


def test_leakage_assertions_fire():
    p, y, ts, labels = synthetic_stream(2, per_window=50)
    bad = labels.copy()
    w2 = np.flatnonzero(labels == "W2")[0]
    bad[w2] = "W1"  # a W2 sample mislabelled as W1 would reach W2's calibration pool
    with pytest.raises(AssertionError, match="tau_k"):
        run_deployment(p, y, ts, bad, BOUNDS, mode="sliding")
    excluded = labels == "D1"
    with pytest.raises(AssertionError, match="fit/validation"):
        run_deployment(p, y, ts, labels, BOUNDS, mode="sliding", excluded_mask=excluded)
