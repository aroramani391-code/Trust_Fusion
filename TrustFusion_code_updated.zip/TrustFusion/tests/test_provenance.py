import numpy as np
import pandas as pd
import pytest

from trustfusion import provenance as P


def synthetic_detection(seed: int = 0, n_mal: int = 3000, n_ben: int = 3000):
    rng = np.random.default_rng(seed)
    sources = rng.choice(["win10", "win11", "repo"], size=n_ben, p=[0.4, 0.4, 0.2])
    shift = np.select([sources == "repo", sources == "win11"], [1.0, 0.3], 0.0)
    ben = rng.normal(0, 1, n_ben) + shift
    mal = rng.normal(3, 1, n_mal)
    scores = np.concatenate([mal, ben])
    y = np.concatenate([np.ones(n_mal, int), np.zeros(n_ben, int)])
    src = np.concatenate([[""] * n_mal, sources])
    return scores, y, src


def test_global_threshold_controls_fpr():
    rng = np.random.default_rng(0)
    b = rng.normal(size=10_000)
    thr = P.global_threshold(b, 0.01)
    assert (b > thr).mean() <= 0.01 and (b >= thr).mean() > 0.0099


def test_per_source_fpr_and_tpr():
    s, y, src = synthetic_detection()
    fpr = P.per_source_fpr(s, y, src, 0.01)
    assert list(fpr["source"]) == ["all", "repo", "win10", "win11"]
    assert fpr.loc[fpr["source"] == "all", "fpr"].item() <= 0.01
    assert fpr.loc[fpr["source"] == "repo", "fpr"].item() > fpr.loc[fpr["source"] == "win10", "fpr"].item()
    tpr = P.per_source_tpr(s, y, src, 0.01)
    assert set(tpr["source"]) == {"all", "repo", "win10", "win11"}
    assert tpr["tpr@fpr=0.01"].between(0, 1).all() and tpr["roc_auc"].between(0.5, 1).all()


def test_per_source_tpr_consistent_with_global_fpr():
    """A source below 1% FPR at the global threshold reaches at least the global-threshold TPR at its own 1% FPR,
    a source above 1% at most that TPR (exact, including tied scores)."""
    for seed in range(30):
        s, y, src = synthetic_detection(seed, n_mal=1500, n_ben=2000)
        if seed % 2:
            s = np.round(s, 1)
        fpr = P.per_source_fpr(s, y, src, 0.01)
        assert fpr["tpr_at_threshold"].nunique() == 1  # same malicious files for every source
        cons = P.provenance_consistency(fpr, P.per_source_tpr(s, y, src, 0.01), 0.01)
        assert cons["consistent"].all(), cons
    below = cons.loc[cons["expected_vs_global"] == ">=", "tpr@fpr=0.01"]
    above = cons.loc[cons["expected_vs_global"] == "<=", "tpr@fpr=0.01"]
    assert below.empty or above.empty or below.min() >= above.max()


def test_provenance_consistency_flags_contradictory_pairs():
    fpr = pd.DataFrame({"source": ["all", "a", "b"], "fpr": [0.01, 0.008, 0.012], "tpr_at_threshold": [0.96] * 3})
    ok = pd.DataFrame({"source": ["all", "a", "b"], "tpr@fpr=0.01": [0.96, 0.97, 0.95]})
    assert P.provenance_consistency(fpr, ok)["consistent"].all()
    # lower FPR at the global threshold but lower TPR at 1% FPR than a source above 1%: impossible
    swapped = pd.DataFrame({"source": ["all", "a", "b"], "tpr@fpr=0.01": [0.96, 0.95, 0.97]})
    res = P.provenance_consistency(fpr, swapped).set_index("source")
    assert not res.loc["a", "consistent"] and not res.loc["b", "consistent"] and res.loc["all", "consistent"]


def test_source_probe_and_cross_source():
    rng = np.random.default_rng(0)
    src = rng.choice(["win10", "win11", "repo"], size=600)
    X = rng.normal(size=(600, 10))
    X[:, 0] += (src == "repo") * 3
    X[:, 1] += (src == "win11") * 3
    res = P.source_probe(X, src, n_splits=5, seed=2024, params={"n_estimators": 30, "num_leaves": 7})
    assert len(res["fold_auc"]) == 5 and res["mean_auc"] > 0.9
    s, y, _ = synthetic_detection()
    cs = P.cross_source_metrics(s, y)
    assert set(cs) == {"roc_auc", "tpr@fpr=0.001", "tpr@fpr=0.01"} and cs["roc_auc"] == pytest.approx(cs["roc_auc"])
