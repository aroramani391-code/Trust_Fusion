#!/usr/bin/env python
"""Prepare the processed BODMAS corpus from local files (no download).

Where to obtain the data
  * BODMAS (Yang et al., 2021): https://whyisyoung.github.io/BODMAS/ -- ``bodmas.npz`` (2,381-d EMBER v2 vectors and
    labels) and ``bodmas_metadata.csv`` (sha, timestamp, family) are public; the disarmed malware binaries are
    available on request from the dataset authors.
  * Benign pool (24,180 Windows PE files: win10 11,368 / win11 9,527 / repo 3,285): collected by the authors with
    ``--benign-manifest`` listing ``sha256,source,path``; the files themselves are not redistributed (see
    docs/RELEASE.md), only their sha256 index.

Output: ``<out>/meta.csv.gz``, ``<out>/static.npy``, ``<out>/corpus.json``, ``<out>/sha256_index.csv``.

Example::

    python scripts/prepare_bodmas.py --bodmas-npz raw/bodmas/bodmas.npz --bodmas-metadata raw/bodmas/bodmas_metadata.csv \
        --binaries-dir raw/bodmas/binaries --benign-manifest raw/benign/manifest.csv \
        --benign-features raw/benign/ember_v2.npy --out data/processed/bodmas --check-counts
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from trustfusion.data.datasets import write_corpus  # noqa: E402
from trustfusion.data.splits import parse_time  # noqa: E402
from trustfusion.data.static_features import EmberFeatureExtractor  # noqa: E402
from trustfusion.utils import get_logger  # noqa: E402

log = get_logger("prepare_bodmas")


def find_binary(binaries_dir: Path | None, sha: str) -> str:
    if binaries_dir is None:
        return ""
    for name in (sha, f"{sha}.exe", f"{sha}.bin", sha.upper()):
        p = binaries_dir / name
        if p.exists():
            return str(p.resolve())
    return ""


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bodmas-npz", required=True)
    ap.add_argument("--bodmas-metadata", required=True)
    ap.add_argument("--binaries-dir", default=None, help="disarmed binaries named <sha256>[.exe]")
    ap.add_argument("--benign-manifest", required=True, help="CSV with columns sha256,source,path")
    ap.add_argument("--benign-features", default=None, help=".npy EMBER v2 vectors aligned with the manifest")
    ap.add_argument("--extract-benign", action="store_true", help="extract EMBER v2 vectors (needs `ember` + `lief`)")
    ap.add_argument("--out", default="data/processed/bodmas")
    ap.add_argument("--check-counts", action="store_true",
                    help="assert 57,293 malicious and 24,180 benign files (win10 11,368, win11 9,527, repo 3,285)")
    args = ap.parse_args()

    npz = np.load(args.bodmas_npz)
    X, y = npz["X"].astype(np.float32), npz["y"].astype(np.int64)
    meta_raw = pd.read_csv(args.bodmas_metadata)
    if len(meta_raw) != len(y):
        raise SystemExit("bodmas_metadata.csv and bodmas.npz are not row-aligned")
    sha_col = "sha" if "sha" in meta_raw.columns else "sha256"
    mal = np.flatnonzero(y == 1)
    binaries = Path(args.binaries_dir) if args.binaries_dir else None
    mal_meta = pd.DataFrame({
        "sample_id": meta_raw[sha_col].astype(str).str.lower().to_numpy()[mal],
        "family": meta_raw["family"].fillna("").astype(str).to_numpy()[mal],
        "is_malicious": 1,
        "timestamp": parse_time(meta_raw["timestamp"].astype(str)).astype(str).to_numpy()[mal],
        "benign_source": "",
        "file_format": "PE",
    })
    mal_meta["sha256"] = mal_meta["sample_id"]
    mal_meta["image_path"] = [find_binary(binaries, s) for s in mal_meta["sample_id"]]

    ben = pd.read_csv(args.benign_manifest)
    missing_cols = {"sha256", "source", "path"} - set(ben.columns)
    if missing_cols:
        raise SystemExit(f"benign manifest lacks columns {sorted(missing_cols)}")
    if args.benign_features:
        Xb = np.load(args.benign_features).astype(np.float32)
        if Xb.shape != (len(ben), X.shape[1]):
            raise SystemExit(f"benign features have shape {Xb.shape}, expected {(len(ben), X.shape[1])}")
    elif args.extract_benign:
        extractor = EmberFeatureExtractor("ember_v2")
        Xb = np.zeros((len(ben), X.shape[1]), dtype=np.float32)
        for i, p in enumerate(ben["path"]):
            vec = extractor(Path(p).read_bytes())
            if vec is None:
                raise SystemExit(f"EMBER v2 extraction failed for {p}")
            Xb[i] = vec
    else:
        raise SystemExit("pass --benign-features or --extract-benign")
    ben_meta = pd.DataFrame({
        "sample_id": ben["sha256"].astype(str).str.lower(), "sha256": ben["sha256"].astype(str).str.lower(),
        "family": "", "is_malicious": 0, "timestamp": ben["timestamp"].astype(str) if "timestamp" in ben else "",
        "benign_source": ben["source"].astype(str), "file_format": "PE",
        "image_path": [str(Path(p).resolve()) if Path(p).exists() else "" for p in ben["path"]],
    })
    meta = pd.concat([mal_meta, ben_meta], ignore_index=True)
    meta["image_kind"] = np.where(meta["image_path"] != "", "bytes", "")
    meta["has_static"] = 1
    meta["released_split"] = ""
    meta["graph_path"] = ""
    static = np.concatenate([X[mal], Xb])
    counts = {"malicious": int(len(mal_meta)), "benign": int(len(ben_meta)),
              "benign_sources": {str(k): int(v) for k, v in ben_meta["benign_source"].value_counts().items()},
              "malicious_without_binary": int((mal_meta["image_path"] == "").sum()),
              "benign_without_binary": int((ben_meta["image_path"] == "").sum()),
              "n_families_raw": int(mal_meta["family"].nunique())}
    if args.check_counts:
        assert counts["malicious"] == 57293, counts
        assert counts["benign"] == 24180, counts
        assert counts["benign_sources"] == {"win10": 11368, "win11": 9527, "repo": 3285}, counts["benign_sources"]
    write_corpus(args.out, meta, static, {"corpus": "bodmas", "layout": "configs/feature_layouts/bodmas_ember_v2.yaml",
                                          "views": {"image": "bytes", "static": "vector"}, "counts": counts})
    meta[["sha256", "is_malicious", "family", "benign_source", "timestamp"]].to_csv(Path(args.out) / "sha256_index.csv", index=False)
    log.info("wrote %s: %s", args.out, counts)


if __name__ == "__main__":
    main()
