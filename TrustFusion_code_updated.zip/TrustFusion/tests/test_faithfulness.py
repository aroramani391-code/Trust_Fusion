import numpy as np
import pytest

from trustfusion.data.byte_image import ChannelStats, render_byte_image
from trustfusion.data.datasets import synthetic_pe_bytes
from trustfusion.data.static_features import StaticTransform
from trustfusion.faithfulness import (FRACTIONS, FaithfulnessInputs, ProbabilityOracle, evaluate_faithfulness,
                                      normalised_auc, perturb)


def test_perturbation_endpoints():
    data = np.arange(1, 101, dtype=np.uint8)
    ranking = np.arange(100)[::-1]
    x, m = perturb(data, ranking, 0.0, "deletion")
    assert np.array_equal(x, data) and not m.any()
    x, m = perturb(data, ranking, 1.0, "deletion")
    assert not x.any() and m.all()
    x, m = perturb(data, ranking, 0.0, "insertion")
    assert not x.any() and m.all()
    x, m = perturb(data, ranking, 0.3, "insertion")
    assert np.array_equal(x[70:], data[70:]) and not x[:70].any() and m[:70].all() and not m[70:].any()
    assert len(FRACTIONS) == 21 and FRACTIONS[1] == pytest.approx(0.05)


def test_normalised_auc_bounds():
    assert normalised_auc(FRACTIONS, np.full(21, 0.3)) == pytest.approx(0.3)
    assert 0 <= normalised_auc(FRACTIONS, np.linspace(1, 0, 21)) <= 1


def _inputs(layout):
    rng = np.random.default_rng(0)
    out = []
    for i in range(2):
        data = np.frombuffer(synthetic_pe_bytes(rng, 6000 + 3000 * i, i, 5, overlay=300), np.uint8)
        out.append(FaithfulnessInputs(f"syn{i}", data, rng.normal(size=layout.dim).astype(np.float32)))
    return out


def test_deletion_insertion_auc_in_unit_interval(tiny_model, layout):
    render = lambda b: ChannelStats.identity().normalise(render_byte_image(b, size=32))  # noqa: E731
    st = StaticTransform("none")
    calls = []

    def extractor(b):
        calls.append(1)
        return None if (b == 0).mean() > 0.9 else np.random.default_rng(0).normal(size=layout.dim).astype(np.float32)

    oracle = ProbabilityOracle(tiny_model.eval(), render, st, "cpu", extractor=extractor)
    rows = evaluate_faithfulness(tiny_model, _inputs(layout), oracle, image_size=32)
    assert len(rows) == 2 * 4 * 2
    for r in rows:
        assert 0.0 <= r["deletion_auc"] <= 1.0 and 0.0 <= r["insertion_auc"] <= 1.0
    assert {r["protocol"] for r in rows} == {"image_view", "coupled"} and calls


def test_graph_callback_receives_sample_id(tiny_model, layout):
    render = lambda b: render_byte_image(b, size=32)  # noqa: E731
    seen = set()

    def graph_fn(sample_id, data, masked):
        seen.add(sample_id)
        assert masked.shape == data.shape
        return np.zeros(layout.dim, np.float32)

    oracle = ProbabilityOracle(tiny_model.eval(), render, StaticTransform("none"), graph_fn=graph_fn)
    evaluate_faithfulness(tiny_model, _inputs(layout)[:1], oracle, variants=["gradcampp_fusion"], protocols=["coupled"],
                          image_size=32)
    assert seen == {"syn0"}
