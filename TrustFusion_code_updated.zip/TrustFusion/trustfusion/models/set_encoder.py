"""Static-feature set encoder: one token per field group (SPEC §2).

Each group ``g`` -> ``Linear(dim_g, 512)`` token + learned group-type embedding, followed by a residual trunk of
two blocks ``x + Linear(GELU(Linear(LayerNorm(x))))`` of width 512 applied to every token.
"""
from __future__ import annotations

from typing import Sequence

import numpy as np
import torch
import torch.nn as nn


class ResidualBlock(nn.Module):
    def __init__(self, d: int):
        super().__init__()
        self.norm = nn.LayerNorm(d)
        self.fc1 = nn.Linear(d, d)
        self.act = nn.GELU()
        self.fc2 = nn.Linear(d, d)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.fc2(self.act(self.fc1(self.norm(x))))


class SetEncoder(nn.Module):
    def __init__(self, group_indices: Sequence[np.ndarray], d_model: int = 512, n_blocks: int = 2):
        super().__init__()
        self.n_groups = len(group_indices)
        for g, idx in enumerate(group_indices):
            self.register_buffer(f"idx_{g}", torch.as_tensor(np.asarray(idx), dtype=torch.long), persistent=False)
        self.proj = nn.ModuleList([nn.Linear(len(idx), d_model) for idx in group_indices])
        self.group_type = nn.Parameter(torch.zeros(self.n_groups, d_model))
        nn.init.trunc_normal_(self.group_type, std=0.02)
        self.blocks = nn.Sequential(*[ResidualBlock(d_model) for _ in range(n_blocks)])

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """``x [B, D]`` -> tokens ``[B, G, d]``."""
        tokens = torch.stack([proj(x.index_select(1, getattr(self, f"idx_{g}"))) for g, proj in enumerate(self.proj)], dim=1)
        return self.blocks(tokens + self.group_type)
