import numpy as np
import torch
import torch.nn.functional as F

from trustfusion.losses import (ClassBalancedFocalLoss, TrustFusionLoss, alignment_loss, calibration_loss,
                                class_balanced_weights)
from trustfusion.metrics import ece


def test_class_balanced_weights_formula():
    counts = np.array([1000, 100, 10, 1])
    w = class_balanced_weights(counts, 0.999).numpy()
    raw = (1 - 0.999) / (1 - 0.999 ** counts)
    np.testing.assert_allclose(w, raw / raw.sum() * 4, rtol=1e-5)
    assert w.sum() == np.float32(4) or abs(w.sum() - 4) < 1e-5
    assert np.all(np.diff(w) > 0)


def test_focal_reduces_to_ce_with_gamma0_and_equal_counts():
    logits = torch.randn(32, 6)
    y = torch.randint(0, 6, (32,))
    fl = ClassBalancedFocalLoss(np.full(6, 50), beta=0.999, gamma=0.0)
    torch.testing.assert_close(fl(logits, y), F.cross_entropy(logits, y))


def test_losses_finite_and_differentiable():
    logits = torch.randn(64, 7, requires_grad=True)
    y = torch.randint(0, 7, (64,))
    zv = torch.randn(64, 16, requires_grad=True)
    zs = torch.randn(64, 16, requires_grad=True)
    crit = TrustFusionLoss(np.arange(1, 8) * 10, {"lambda_cal": 0.35, "lambda_align": 0.10})
    total, logs = crit(logits, y, z_v=zv, z_s=zs, pair_mask=torch.ones(64, dtype=torch.bool))
    total.backward()
    assert torch.isfinite(total)
    for t in (logits, zv, zs):
        assert t.grad is not None and torch.isfinite(t.grad).all() and t.grad.abs().sum() > 0
    expected = logs["cls"] + 0.35 * logs["cal"] + 0.10 * logs["align"]
    assert abs(logs["loss"] - expected) < 1e-5


def test_calibration_loss_matches_ece_and_detaches_accuracy():
    torch.manual_seed(0)
    logits = torch.randn(500, 5) * 2
    y = torch.randint(0, 5, (500,))
    val = calibration_loss(logits, y, 15)
    assert abs(val.item() - ece(F.softmax(logits, -1).numpy(), y.numpy(), 15)) < 1e-5
    # gradient equals the gradient of sum_m |acc_sum - conf_sum| / n with accuracy treated as a constant
    x = logits.clone().requires_grad_(True)
    calibration_loss(x, y, 15).backward()
    x2 = logits.clone().requires_grad_(True)
    p = F.softmax(x2, -1)
    conf, pred = p.max(-1)
    acc = (pred == y).float()
    bins = torch.clamp(torch.ceil(conf.detach() * 15).long() - 1, 0, 14)
    manual = sum((acc[bins == m].sum() - conf[bins == m].sum()).abs() for m in range(15)) / 500
    manual.backward()
    torch.testing.assert_close(x.grad, x2.grad)


def test_alignment_loss():
    z = torch.randn(10, 8, requires_grad=True)
    assert alignment_loss(z, z.detach().clone()).item() < 1e-6
    empty = alignment_loss(z, z, torch.zeros(10, dtype=torch.bool))
    empty.backward()
    assert empty.item() == 0 and z.grad is not None
