# Release of artefacts and data-licensing notes

The Git repository contains code, configurations and documentation only. Large artefacts are attached to a GitHub
Release and archived on Zenodo.

| artefact | content | location |
|---|---|---|
| source code | this repository at the release tag | `https://github.com/mani-arora/TrustFusion/releases/tag/v1.0.0`, DOI `10.5281/zenodo.17106842` |
| split indices | `splits/<corpus>_<protocol>.csv` (sha256 lists with first-seen timestamps), `*_classes.json`, `summary.json`; no file content | release asset `trustfusion-splits-v1.0.0.tar.gz` |
| checkpoints | `runs/**/best.pt`, `model.txt`, `stacker.pkl`, `config.yaml`, `train_info.json` for every method, corpus, protocol and seed | release assets `trustfusion-checkpoints-<corpus>-v1.0.0.tar.gz`, DOI `10.5281/zenodo.17106842` |
| per-sample predictions | `runs/**/predictions.parquet`, `probs.npz`, `metrics.json`, `temporal_*.csv` | release asset `trustfusion-predictions-v1.0.0.tar.gz`, DOI `10.5281/zenodo.17106842` |
| control analyses | `results/faithfulness/`, `results/ablation/`, `results/provenance/` | release asset `trustfusion-results-v1.0.0.tar.gz` |
| sha256 index files | BODMAS malicious files used (`sha256_index.csv` from `prepare_bodmas.py`), the Windows benign pool (`sha256`, `source`: 11,368 `win10`, 9,527 `win11`, 3,285 `repo`) and the 5,000 Google Play APKs of the MalNet detection benign source (`sha256`, `source` = `googleplay`) | release asset `trustfusion-sha256-index-v1.0.0.tar.gz` |
| benign collection script | `scripts/collect_benign.py` (manifest of PE files from local Windows 10 / Windows 11 installations and software repositories) | in the repository |

The DOI `10.5281/zenodo.17106842` is the one quoted in the manuscript's response to reviewers. Zenodo assigns a DOI
only when the archive is published, so confirm that `https://doi.org/10.5281/zenodo.17106842` resolves to this
release after publishing it, and replace the identifier in `README.md`, `SPEC.md`, `CITATION.cff` and this file if
Zenodo issued a different one.

## Creating a release

```bash
tar czf trustfusion-splits-v1.0.0.tar.gz splits/
tar czf trustfusion-predictions-v1.0.0.tar.gz $(find runs -name predictions*.parquet -o -name probs*.npz -o -name metrics.json -o -name 'temporal_*.csv')
tar czf trustfusion-checkpoints-bodmas-v1.0.0.tar.gz $(find runs/bodmas \( -name best.pt -o -name model.txt -o -name model_meta.json -o -name stacker.pkl -o -name config.yaml -o -name train_info.json \))
tar czf trustfusion-results-v1.0.0.tar.gz results/
gh release create v1.0.0 trustfusion-*.tar.gz --title "TrustFusion v1.0.0" --notes "Code, splits, checkpoints and per-sample predictions"
sha256sum trustfusion-*.tar.gz > SHA256SUMS && gh release upload v1.0.0 SHA256SUMS
```

Connect the GitHub repository to Zenodo (GitHub integration) before tagging so that the release receives a DOI, or
upload the archives to a Zenodo record manually. Every table can be recomputed from the prediction archive alone:

```bash
tar xzf trustfusion-predictions-v1.0.0.tar.gz && python scripts/aggregate_results.py
```

## Data licensing

* **BODMAS**: the feature vectors and metadata are distributed by the dataset authors
  (https://whyisyoung.github.io/BODMAS/); the disarmed malware binaries are shared by the authors on request and are
  **not redistributed** here. Released artefacts reference files only by sha256.
* **Windows benign files** (sources `win10`, `win11`, `repo`): copyrighted software, **not redistributed**. We release
  only the sha256 index with the source of every file and the collection script, so that the pool can be rebuilt from
  the same Windows versions and repositories.
* **Google Play benign APKs** (MalNet detection, source `googleplay`): third-party applications, **not
  redistributed**; the release lists their sha256 values (zero VirusTotal detections at collection time).
* **EMBER2024** (https://github.com/FutureComputing4AI/EMBER2024) and **MalNet** (https://mal-net.org) are
  obtained from their maintainers under their own licences; splits reference files by sha256 only.
* Checkpoints are trained on the data above; they contain no raw file content.
