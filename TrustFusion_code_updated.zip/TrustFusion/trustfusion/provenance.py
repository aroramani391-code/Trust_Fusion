"""Benign-provenance control analyses (SPEC §6, manuscript Section 5.2).

* per-source FPR at the global threshold that gives 1% FPR on all benign test files (with the TPR of that threshold)
* TPR at 1% FPR with the benign test files restricted to each source
* consistency check between the two: every source's ROC passes through (FPR of the source at the global threshold,
  TPR at the global threshold), because the malicious test files are the same for every source. ROC curves are
  monotone, so a source whose FPR at the global threshold is below 1% must reach a TPR at 1% FPR of at least the
  global-threshold TPR, and a source above 1% at most that TPR. A source with a lower FPR can therefore never be
  reported with a lower TPR at 1% FPR than a source with a higher FPR when the two FPRs lie on opposite sides of 1%
* source probe: LightGBM predicting the benign source from the static descriptor, 5-fold stratified CV,
  macro one-vs-rest ROC-AUC
* cross-source run: model trained with benign sources {win10, win11}; benign test files = repo
  (split built by :func:`trustfusion.data.splits.bodmas_cross_source`)
"""
from __future__ import annotations

from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedKFold

from .metrics import roc_auc, tpr_at_fpr


def global_threshold(benign_scores: np.ndarray, fpr: float = 0.01) -> float:
    """Smallest threshold ``t`` such that at most ``floor(fpr * n)`` benign scores are ``> t``."""
    s = np.sort(np.asarray(benign_scores, dtype=np.float64))
    n = s.size
    if n == 0:
        return float("nan")
    k = int(np.floor(fpr * n + 1e-9))
    return float(s[n - k - 1]) if k < n else float("-inf")


def per_source_fpr(scores: np.ndarray, y: np.ndarray, sources: Sequence[str], fpr: float = 0.01) -> pd.DataFrame:
    scores, y = np.asarray(scores, dtype=np.float64), np.asarray(y)
    sources = np.asarray(sources).astype(str)
    ben = y == 0
    thr = global_threshold(scores[ben], fpr)
    mal = y == 1
    tpr_thr = float((scores[mal] > thr).mean()) if mal.any() else float("nan")
    rows = [{"source": "all", "n_benign": int(ben.sum()), "fpr": float((scores[ben] > thr).mean()), "threshold": thr,
             "tpr_at_threshold": tpr_thr}]
    for src in sorted(set(sources[ben])):
        m = ben & (sources == src)
        rows.append({"source": src, "n_benign": int(m.sum()), "fpr": float((scores[m] > thr).mean()), "threshold": thr,
                     "tpr_at_threshold": tpr_thr})
    return pd.DataFrame(rows)


def per_source_tpr(scores: np.ndarray, y: np.ndarray, sources: Sequence[str], fpr: float = 0.01) -> pd.DataFrame:
    scores, y = np.asarray(scores, dtype=np.float64), np.asarray(y)
    sources = np.asarray(sources).astype(str)
    mal = y == 1
    rows = []
    for src in ["all"] + sorted(set(sources[y == 0])):
        ben = (y == 0) if src == "all" else ((y == 0) & (sources == src))
        m = mal | ben
        rows.append({"source": src, "n_benign": int(ben.sum()), "n_malicious": int(mal.sum()),
                     f"tpr@fpr={fpr:g}": tpr_at_fpr(y[m], scores[m], [fpr])[float(fpr)],
                     "roc_auc": roc_auc(y[m], scores[m])})
    return pd.DataFrame(rows)


def provenance_consistency(fpr_table: pd.DataFrame, tpr_table: pd.DataFrame, fpr: float = 0.01,
                           tol: float = 1e-9) -> pd.DataFrame:
    """Check per-source TPR at ``fpr`` against the per-source FPR at the global threshold (one seed).

    For each source: FPR(global) < ``fpr`` requires TPR@``fpr`` >= TPR(global threshold); FPR(global) > ``fpr``
    requires TPR@``fpr`` <= TPR(global threshold). ``consistent`` is False when a reported pair violates this.
    """
    col = f"tpr@fpr={fpr:g}"
    merged = fpr_table.merge(tpr_table[["source", col]], on="source", how="inner")
    rows = []
    for _, r in merged.iterrows():
        f, tpr, ref = float(r["fpr"]), float(r[col]), float(r["tpr_at_threshold"])
        if f < fpr - tol:
            expected, ok = ">=", tpr >= ref - tol
        elif f > fpr + tol:
            expected, ok = "<=", tpr <= ref + tol
        else:
            expected, ok = "any", True
        rows.append({"source": r["source"], "fpr_at_global_threshold": f, "tpr_at_global_threshold": ref, col: tpr,
                     "expected_vs_global": expected, "consistent": bool(ok)})
    return pd.DataFrame(rows)


def source_probe(X: np.ndarray, sources: Sequence[str], n_splits: int = 5, seed: int = 2024,
                 params: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """5-fold CV macro one-vs-rest AUC of a LightGBM classifier predicting the benign source."""
    import lightgbm as lgb

    X = np.asarray(X, dtype=np.float32)
    classes, y = np.unique(np.asarray(sources).astype(str), return_inverse=True)
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    aucs = []
    for tr, te in skf.split(X, y):
        clf = lgb.LGBMClassifier(random_state=seed, verbose=-1, **dict(params or {}))
        clf.fit(X[tr], y[tr])
        proba = clf.predict_proba(X[te])
        if classes.size == 2:
            aucs.append(float(roc_auc_score(y[te], proba[:, 1])))
        else:
            aucs.append(float(roc_auc_score(y[te], proba, multi_class="ovr", average="macro", labels=np.arange(classes.size))))
    return {"classes": classes.tolist(), "fold_auc": aucs, "mean_auc": float(np.mean(aucs)),
            "sd_auc": float(np.std(aucs, ddof=1)) if len(aucs) > 1 else 0.0, "n": int(len(y)), "n_splits": n_splits}


def cross_source_metrics(scores: np.ndarray, y: np.ndarray, fpr_targets: Sequence[float] = (1e-3, 1e-2)) -> dict[str, float]:
    out = {"roc_auc": roc_auc(y, scores)}
    out.update({f"tpr@fpr={f:g}": v for f, v in tpr_at_fpr(y, scores, fpr_targets).items()})
    return out
