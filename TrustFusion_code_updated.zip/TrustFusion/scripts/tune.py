#!/usr/bin/env python
"""Random hyper-parameter search (SPEC §4): 20 trials per corpus, seed 0, scored by validation macro-F1.

Draws come from the config's ``search_space`` (dotted keys). Each trial trains with seed 0 into
``runs/tuning/<corpus>/<protocol>/<method>/trial<k>/``; results go to ``trials.csv`` and the best draw to
``best_overrides.yaml`` (usable with ``--overlay``). EMBER2024 trials train on a stratified 10% training subsample.
The late-fusion stacker is fitted on the validation split, so its trials are scored by 5-fold stratified
cross-validated macro-F1 on the validation split. The configs already contain the selected values reported in the
manuscript, so tuning is only needed to re-derive them.

Example::

    python scripts/tune.py --config configs/baselines/cross_attention.yaml --corpus bodmas
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from trustfusion.cli import add_config_args, add_path_args, load_cfg  # noqa: E402
from trustfusion.io import run_dir, write_json  # noqa: E402
from trustfusion.metrics import macro_f1  # noqa: E402
from trustfusion.models import method_kind  # noqa: E402
from trustfusion.models.baselines import LateFusionStacker, LightGBMModel  # noqa: E402
from trustfusion.training import build_context, load_inference, subsample_train, take_rows, train_torch  # noqa: E402
from trustfusion.utils import deep_update, get_logger, sample_search_space, save_config, set_by_dotted  # noqa: E402

log = get_logger("tune")


def score_trial(cfg: dict, args: argparse.Namespace, trial_dir: Path, subsample: float | None) -> float:
    seed = int(cfg.get("tuning", {}).get("seed", 0))
    kind = method_kind(cfg["method"])
    ctx = build_context(cfg, args.data_root, args.splits, args.runs, seed, device=args.device)
    ctx.run_dir = trial_dir
    trial_dir.mkdir(parents=True, exist_ok=True)
    if subsample:
        subsample_train(ctx, subsample)
    if kind in ("torch", "graph"):
        return float(train_torch(ctx)["best_val_macro_f1"])
    if kind == "gbdt":
        tr, va = ctx.rows("train"), ctx.rows("val")
        cw = cfg["model"].get("class_weight_family") if cfg.get("task") == "family" else None
        m = LightGBMModel(ctx.num_classes, cfg["model"], seed=seed, class_weight=cw).fit(
            take_rows(ctx.corpus.static, tr["row"].to_numpy()), tr["label"].to_numpy(),
            take_rows(ctx.corpus.static, va["row"].to_numpy()), va["label"].to_numpy())
        return macro_f1(va["label"].to_numpy(), m.predict_proba(take_rows(ctx.corpus.static, va["row"].to_numpy())).argmax(1))
    from sklearn.model_selection import StratifiedKFold

    val = {b: load_inference(run_dir(args.runs, cfg["corpus"], cfg["protocol"], b, seed), "val") for b in cfg["base_methods"]}
    y = val[cfg["base_methods"][0]]["label"]
    X = [val[b]["p_bar"] for b in cfg["base_methods"]]
    pred = np.zeros_like(y)
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=seed)
    for tr_idx, te_idx in skf.split(np.zeros(len(y)), y):
        st = LateFusionStacker(ctx.num_classes, C=float(cfg["model"]["C"]), seed=seed).fit([x[tr_idx] for x in X], y[tr_idx])
        pred[te_idx] = st.predict_proba([x[te_idx] for x in X]).argmax(1)
    return macro_f1(y, pred)


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    add_config_args(ap)
    add_path_args(ap)
    ap.add_argument("--trials", type=int, default=None, help="default: configs/base.yaml tuning.trials (20)")
    ap.add_argument("--keep-checkpoints", action="store_true")
    args = ap.parse_args()
    cfg = load_cfg(args)
    space = cfg.get("search_space") or {}
    if not space:
        raise SystemExit(f"{args.config} has no search_space")
    tcfg = cfg.get("tuning", {})
    trials = int(args.trials or tcfg.get("trials", 20))
    draws = sample_search_space(space, trials, int(tcfg.get("seed", 0)))
    root = Path(args.runs) / "tuning" / cfg["corpus"] / cfg["protocol"] / cfg["method"]
    subsample = tcfg.get("train_subsample")
    rows = []
    for k, draw in enumerate(draws):
        trial_cfg = deep_update(cfg, {})
        for key, value in draw.items():
            set_by_dotted(trial_cfg, key, value)
        trial_dir = root / f"trial{k:02d}"
        save_config(trial_cfg, trial_dir / "config.yaml")
        score = score_trial(trial_cfg, args, trial_dir, float(subsample) if subsample else None)
        rows.append({"trial": k, **draw, "val_macro_f1": score})
        log.info("trial %d %s -> val macro-F1 %.4f", k, draw, score)
        if not args.keep_checkpoints and (trial_dir / "best.pt").exists():
            (trial_dir / "best.pt").unlink()
    df = pd.DataFrame(rows)
    df.to_csv(root / "trials.csv", index=False)
    best = df.sort_values(["val_macro_f1", "trial"], ascending=[False, True]).iloc[0]
    nested: dict = {}
    for key in space:
        v = best[key]
        set_by_dotted(nested, key, v.item() if hasattr(v, "item") else v)
    save_config(nested, root / "best_overrides.yaml")
    write_json(root / "best.json", {"trial": int(best["trial"]), "val_macro_f1": float(best["val_macro_f1"]), "overrides": nested})
    log.info("best: %s", nested)


if __name__ == "__main__":
    main()
