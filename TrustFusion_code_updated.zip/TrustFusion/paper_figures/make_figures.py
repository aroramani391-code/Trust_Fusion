"""Regenerate the manuscript figures at print resolution.

All text is set at >= 10 pt at the final printed size (single column = 3.3 in,
full width = 6.7 in), no panel letters and no outer borders, as required by
the IJIES format checklist.

Input data live in ``paper_figures/data``.  They contain the values plotted in
the manuscript.  When the full pipeline is re-run, ``scripts/aggregate_results.py``
overwrites these CSV files with the seed-averaged values computed from the
per-sample prediction files in ``runs/``, so the figures can be rebuilt from
scratch with::

    python paper_figures/make_figures.py --data paper_figures/data --out paper_figures/out
"""
import argparse
import csv
import os
from collections import defaultdict

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.patches import FancyBboxPatch, Rectangle  # noqa: E402

FS = 10  # minimum font size in points at printed size
plt.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Liberation Serif", "Times New Roman", "TeX Gyre Termes", "DejaVu Serif"],
    "mathtext.fontset": "stix",
    "font.size": FS, "axes.titlesize": FS, "axes.labelsize": FS,
    "xtick.labelsize": FS, "ytick.labelsize": FS, "legend.fontsize": FS,
    "axes.linewidth": 0.8, "lines.linewidth": 1.6,
    "axes.spines.top": False, "axes.spines.right": False,
    "savefig.dpi": 600, "figure.dpi": 150,
    "legend.frameon": False,
})

COL = {
    "TrustFusion": "#1B3A6B",
    "Cross-attention fusion": "#C1121F",
    "Late-fusion ensemble": "#2A7F62",
    "MC-dropout image CNN": "#E08E0B",
    "Gradient-boosted static model": "#6E6E6E",
    "Conformal-gated static model": "#6A4C93",
    "Structural GIN encoder": "#8C564B",
    "Byte-image CNN (ResNet-50)": "#E08E0B",
}
STY = {
    "TrustFusion": dict(ls="-", lw=2.0),
    "Cross-attention fusion": dict(ls="--"),
    "Late-fusion ensemble": dict(ls="-."),
    "MC-dropout image CNN": dict(ls=":"),
    "Gradient-boosted static model": dict(ls=(0, (3, 1, 1, 1))),
    "Conformal-gated static model": dict(ls="--"),
    "Structural GIN encoder": dict(ls="-."),
    "Byte-image CNN (ResNet-50)": dict(ls=":"),
}


def read_csv(path):
    with open(path, newline="") as f:
        return list(csv.DictReader(f))


def save(fig, out, name):
    os.makedirs(out, exist_ok=True)
    for ext in ("png", "pdf"):
        fig.savefig(os.path.join(out, f"{name}.{ext}"))
    plt.close(fig)


# --------------------------------------------------------------------------- Fig. 1
def fig_framework(out):
    fig = plt.figure(figsize=(6.7, 2.45))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 6.7)
    ax.set_ylim(0, 2.75)  # drawing units; printed height 2.45 in (text stays 10 pt)
    ax.axis("off")

    def box(x, y, w, h, text, fc, bold=False):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.05",
                                    fc=fc, ec="#222222", lw=0.8))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=FS,
                fontweight="bold" if bold else "normal", linespacing=1.15)

    def arrow(x0, y0, x1, y1):
        ax.annotate("", xy=(x1, y1), xytext=(x0, y0),
                    arrowprops=dict(arrowstyle="-|>", lw=0.9, color="#222222", shrinkA=0, shrinkB=0,
                                    mutation_scale=9))

    blue, pink, green, sand, lilac, grey = "#E4ECF7", "#F9E8EA", "#E3F1EA", "#F6EEDD", "#ECE8F6", "#EFEFEF"
    # input
    box(0.02, 1.08, 0.62, 0.56, "PE\nbinary $x$", grey, bold=True)
    # image stream
    ax.text(2.05, 2.62, "Byte-image stream", ha="center", va="center", fontsize=FS, fontweight="bold",
            color="#1B3A6B")
    box(0.82, 1.95, 1.02, 0.56, "Byte-to-image\n(width table)", blue)
    box(2.00, 1.95, 1.05, 0.56, "grey, entropy,\nbigram map", blue)
    box(3.21, 1.95, 0.86, 0.56, "CNN\nencoder $z_v$", blue)
    # static stream
    ax.text(2.05, 0.10, "Static-feature stream", ha="center", va="center", fontsize=FS, fontweight="bold",
            color="#8B1E2D")
    box(0.82, 0.22, 1.02, 0.56, "PE parser\n(8 field groups)", pink)
    box(2.00, 0.22, 1.05, 0.56, "group\nembeddings", pink)
    box(3.21, 0.22, 0.86, 0.56, "set\nencoder $z_s$", pink)
    # fusion
    box(4.25, 1.55, 1.08, 0.62, "cross-modal\nco-attention", green, bold=True)
    box(4.25, 0.62, 1.08, 0.62, "confidence\ngate $g$ → $z_f$", green, bold=True)
    ax.text(4.79, 0.45, "modality dropout", ha="center", va="center", fontsize=FS, style="italic",
            color="#444444")
    # heads
    box(5.50, 2.08, 1.18, 0.52, "classifier\n$K$+1 logits", grey)
    box(5.50, 1.42, 1.18, 0.52, "MC-dropout head\n(head only, $T$=12)", sand)
    box(5.50, 0.76, 1.18, 0.52, "conformal gate:\npredict/abstain", sand, bold=True)
    box(5.50, 0.10, 1.18, 0.52, "Grad-CAM++ via\nfusion → PE regions", lilac)
    # arrows
    arrow(0.64, 1.50, 0.82, 2.10)
    arrow(0.64, 1.22, 0.82, 0.62)
    arrow(1.84, 2.23, 2.00, 2.23)
    arrow(3.05, 2.23, 3.21, 2.23)
    arrow(1.84, 0.50, 2.00, 0.50)
    arrow(3.05, 0.50, 3.21, 0.50)
    arrow(4.07, 2.10, 4.25, 1.95)
    arrow(4.07, 0.62, 4.25, 1.65)
    arrow(4.79, 1.55, 4.79, 1.24)
    # bus from the fused vector to the heads
    ax.plot([5.33, 5.41], [0.93, 0.93], color="#222222", lw=0.9)
    ax.plot([5.41, 5.41], [0.36, 2.34], color="#222222", lw=0.9)
    arrow(5.41, 2.34, 5.50, 2.34)
    arrow(5.41, 1.68, 5.50, 1.68)
    arrow(5.41, 0.36, 5.50, 0.36)
    arrow(6.09, 1.42, 6.09, 1.28)
    save(fig, out, "fig1_framework")


# --------------------------------------------------------------------------- Fig. 2
def fig_attribution(data, out):
    rows = read_csv(os.path.join(data, "fig_attribution_mass.csv"))
    strip = np.loadtxt(os.path.join(data, "fig_attribution_strip.csv"))
    fams = [k for k in rows[0].keys() if k != "region"]
    regions = [r["region"] for r in rows]

    fig = plt.figure(figsize=(3.2, 2.7))
    ax0 = fig.add_axes([0.15, 0.865, 0.83, 0.12])
    ax1 = fig.add_axes([0.15, 0.805, 0.83, 0.055])
    ax2 = fig.add_axes([0.15, 0.19, 0.83, 0.49])

    sections = [("hdr", 0.073, "#DCE3EE"), (".text", 0.387, "#C3D3EA"), (".rdata", 0.188, "#DBE6D8"),
                (".data", 0.125, "#EFE4CF"), (".rsrc", 0.147, "#E5DDF0"), ("ovl", 0.080, "#F2DCDC")]
    x = 0.0
    for name, w, c in sections:
        ax0.add_patch(Rectangle((x, 0), w, 1, fc=c, ec="#333333", lw=0.6))
        ax0.text(x + w / 2, 0.5, name, ha="center", va="center", fontsize=FS)
        x += w
    ax0.set_xlim(0, 1)
    ax0.set_ylim(0, 1)
    ax0.axis("off")
    ax1.imshow(strip[None, :], aspect="auto", cmap="inferno_r", vmin=0, vmax=1, extent=(0, 1, 0, 1))
    ax1.set_xticks([])
    ax1.set_yticks([])
    for s in ax1.spines.values():
        s.set_visible(False)

    colors = ["#1B3A6B", "#2A7F62", "#E08E0B"]
    idx = np.arange(len(regions))
    wbar = 0.26
    for i, fam in enumerate(fams):
        vals = [float(r[fam]) for r in rows]
        ax2.bar(idx + (i - 1) * wbar, vals, wbar, color=colors[i], label=fam, edgecolor="white", lw=0.3)
    ax2.set_xticks(idx)
    ax2.set_xticklabels(regions, rotation=35, ha="right")
    ax2.set_ylabel("attribution mass")
    ax2.set_ylim(0, 0.45)
    ax2.set_yticks([0, 0.1, 0.2, 0.3, 0.4])
    ax2.grid(axis="y", color="#E6E6E6", lw=0.6)
    ax2.set_axisbelow(True)
    ax2.legend(ncol=3, loc="upper center", bbox_to_anchor=(0.5, 1.17), handlelength=1.0, columnspacing=0.9)
    save(fig, out, "fig2_attribution")


# --------------------------------------------------------------------------- Fig. 3
def fig_roc(data, out):
    rows = read_csv(os.path.join(data, "fig_roc_curves.csv"))
    curves = defaultdict(lambda: defaultdict(list))
    for r in rows:
        curves[r["corpus"]][r["method"]].append((float(r["fpr"]), float(r["tpr"])))
    panels = [("BODMAS", "BODMAS", 0.55), ("EMBER2024", "EMBER2024 (PE formats)", 0.55),
              ("MalNet-Image", "MalNet-Image", 0.50)]
    fig, axes = plt.subplots(1, 3, figsize=(6.7, 2.45))
    handles = {}
    for ax, (key, title, ymin) in zip(axes, panels):
        for m, pts in curves[key].items():
            pts = np.array(sorted(pts))
            (h,) = ax.plot(pts[:, 0], pts[:, 1], color=COL[m], **STY[m])
            handles[m] = h
        ax.set_xscale("log")
        ax.set_xlim(1e-4, 1)
        ax.set_ylim(ymin, 1.0)
        ax.axvline(1e-2, color="#999999", lw=0.8, ls=":")
        ax.set_title(title)
        ax.set_xlabel("false positive rate")
        ax.set_xticks([1e-4, 1e-3, 1e-2, 1e-1, 1])
        ax.grid(color="#EAEAEA", lw=0.6)
    axes[0].set_ylabel("true positive rate")
    order = ["TrustFusion", "Cross-attention fusion", "Conformal-gated static model",
             "Gradient-boosted static model", "Structural GIN encoder", "Byte-image CNN (ResNet-50)"]
    fig.legend([handles[o] for o in order], order, ncol=3, loc="lower center", bbox_to_anchor=(0.5, 0.0),
               handlelength=2.2, columnspacing=1.2)
    fig.subplots_adjust(left=0.075, right=0.985, top=0.905, bottom=0.40, wspace=0.22)
    save(fig, out, "fig3_roc")


# --------------------------------------------------------------------------- Fig. 4
def fig_reliability(data, out):
    rows = read_csv(os.path.join(data, "fig_reliability_bodmas.csv"))
    keys = [k for k in rows[0].keys() if k != "bin_center"]
    centers = np.array([float(r["bin_center"]) for r in rows])
    fig, ax = plt.subplots(figsize=(3.2, 2.6))
    fig.subplots_adjust(left=0.17, right=0.96, top=0.97, bottom=0.17)
    colors = ["#D6636B", "#EBB55E", "#1B3A6B"]
    labels = ["cross-attention, 4.92", "+ temp. scaling, 2.44", "TrustFusion, 1.27"]
    w = 1 / 15 / 3.4
    ax.plot([0, 1], [0, 1], ls="--", color="#555555", lw=1.0, label="ideal (ECE %)")
    for i, k in enumerate(keys):
        ax.bar(centers + (i - 1) * w, [float(r[k]) for r in rows], w, color=colors[i], label=labels[i])
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("confidence")
    ax.set_ylabel("empirical accuracy")
    ax.grid(color="#EAEAEA", lw=0.6)
    ax.set_axisbelow(True)
    ax.legend(loc="upper left", ncol=1, handlelength=1.2, borderaxespad=0.2, labelspacing=0.25, handletextpad=0.4)
    save(fig, out, "fig4_reliability")


# --------------------------------------------------------------------------- Fig. 5
def fig_risk_coverage(data, out):
    rows = read_csv(os.path.join(data, "fig_risk_coverage.csv"))
    cov = [100, 95, 90, 85, 80, 75, 70]
    ccol = {"BODMAS": "#1B3A6B", "EMBER2024": "#C1121F", "MalNet-Image": "#2A7F62"}
    mk = {"BODMAS": "o", "EMBER2024": "s", "MalNet-Image": "^"}
    fig, ax = plt.subplots(figsize=(3.2, 2.85))
    fig.subplots_adjust(left=0.17, right=0.97, top=0.97, bottom=0.40)
    for r in rows:
        vals = [float(r[f"cov{c}"]) for c in cov]
        tf = r["model"] == "TrustFusion"
        ax.plot(cov, vals, color=ccol[r["corpus"]], ls="-" if tf else "--", marker=mk[r["corpus"]],
                ms=4.5, mfc=ccol[r["corpus"]] if tf else "white", lw=1.8 if tf else 1.2, alpha=1 if tf else 0.85)
    ax.set_yscale("log")
    ax.set_yticks([1, 2, 5, 10, 20, 35])
    ax.set_yticklabels(["1", "2", "5", "10", "20", "35"])
    ax.minorticks_off()
    ax.set_xlim(101.5, 68.5)
    ax.set_xlabel("coverage (%)")
    ax.set_ylabel("selective error (%)")
    ax.grid(color="#EAEAEA", lw=0.6)
    from matplotlib.lines import Line2D
    hs = [Line2D([], [], color=ccol[c], marker=mk[c], ls="-", ms=4.5) for c in ccol]
    hs += [Line2D([], [], color="#333333", ls="-", lw=1.8), Line2D([], [], color="#333333", ls="--", lw=1.2),
           Line2D([], [], ls="none")]
    labs = list(ccol.keys()) + ["TrustFusion", "uncalibrated", ""]
    fig.legend(hs, labs, ncol=2, loc="lower center", bbox_to_anchor=(0.52, 0.0), handlelength=1.8,
               columnspacing=1.0)
    save(fig, out, "fig5_risk_coverage")


# --------------------------------------------------------------------------- Fig. 6
def fig_drift(data, out):
    rows = read_csv(os.path.join(data, "fig_temporal_drift.csv"))
    fig, ax = plt.subplots(figsize=(3.2, 2.95))
    fig.subplots_adjust(left=0.16, right=0.98, top=0.97, bottom=0.39)
    x = np.arange(1, 8)
    short = {"Gradient-boosted static model": "Gradient-boosted", "MC-dropout image CNN": "MC-dropout CNN",
             "Late-fusion ensemble": "Late-fusion ensemble", "Cross-attention fusion": "Cross-attention fusion",
             "TrustFusion": "TrustFusion"}
    mks = {"TrustFusion": "o", "Cross-attention fusion": "^", "Late-fusion ensemble": "s",
           "MC-dropout image CNN": "D", "Gradient-boosted static model": "v"}
    order = ["TrustFusion", "Cross-attention fusion", "Late-fusion ensemble", "MC-dropout image CNN",
             "Gradient-boosted static model"]
    data_by = {r["method"]: [float(r[f"W{i}"]) for i in range(1, 8)] for r in rows}
    for m in order:
        v = data_by[m]
        ax.plot(x, v, color=COL[m], marker=mks[m], ms=4, label=short[m], **{k: s for k, s in STY[m].items()})
    ends = {m: data_by[m][-1] for m in order}
    # annotate total loss, nudging overlapping labels apart
    placed = []
    for m in sorted(order, key=lambda k: -ends[k]):
        y = ends[m]
        for p in placed:
            if abs(y - p) < 1.6:
                y = p - 1.6
        placed.append(y)
        loss = data_by[m][0] - data_by[m][-1]
        ax.text(7.18, y, f"−{loss:.1f}", color=COL[m], va="center", fontsize=FS)
    ax.set_xlim(0.7, 7.95)
    ax.set_ylim(58, 88)
    ax.set_xticks(x)
    ax.set_xticklabels([f"W{i}" for i in x])
    ax.set_xlabel("test window (months after cut-off)")
    ax.set_ylabel("family macro-F1 (%)")
    ax.grid(color="#EAEAEA", lw=0.6)
    fig.legend(loc="lower center", bbox_to_anchor=(0.53, 0.0), ncol=2, handlelength=1.6, columnspacing=0.5, handletextpad=0.4)
    save(fig, out, "fig6_temporal_drift")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=os.path.join(os.path.dirname(__file__), "data"))
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "out"))
    a = ap.parse_args()
    fig_framework(a.out)
    fig_attribution(a.data, a.out)
    fig_roc(a.data, a.out)
    fig_reliability(a.data, a.out)
    fig_risk_coverage(a.data, a.out)
    fig_drift(a.data, a.out)


if __name__ == "__main__":
    main()
