#!/usr/bin/env python
"""Benign-provenance controls (manuscript Section 5.2).

From the BODMAS detection-subset predictions of ``--method`` (default TrustFusion):
* per-source FPR at the global threshold giving 1% FPR on all benign test files  -> ``per_source_fpr.csv``
* TPR at 1% FPR with benign test files restricted to each source                 -> ``per_source_tpr.csv``
* per-seed check that every source's TPR at 1% FPR is on the side of the global-threshold TPR implied by its FPR
  (FPR < 1% -> TPR >= global-threshold TPR; FPR > 1% -> TPR <= it)             -> ``consistency.csv``
* source probe: LightGBM predicting the benign source from the descriptor, 5-fold CV macro OvR AUC -> ``source_probe.json``
* cross-source run (``pr_crosssource`` protocol; train benign {win10, win11}, test benign = repo) -> ``cross_source.csv``
``summary.csv`` holds mean +- SD over seeds.

The cross-source model is trained beforehand with::

    python scripts/train.py --config configs/trustfusion/bodmas_pr.yaml --protocol pr_crosssource
    python scripts/evaluate.py --run runs/bodmas/pr_crosssource/trustfusion --no-conformal

Example::

    python scripts/run_provenance.py --runs runs --out results/provenance
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from trustfusion.aggregate import load_columns  # noqa: E402
from trustfusion.data.datasets import load_corpus  # noqa: E402
from trustfusion.data.splits import read_split  # noqa: E402
from trustfusion.io import run_dir, write_json  # noqa: E402
from trustfusion.provenance import (cross_source_metrics, per_source_fpr, per_source_tpr, provenance_consistency,  # noqa: E402
                                    source_probe)
from trustfusion.stats import mean_sd  # noqa: E402
from trustfusion.training import take_rows  # noqa: E402
from trustfusion.utils import get_logger, load_config  # noqa: E402

log = get_logger("run_provenance")


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--config", default="configs/provenance.yaml")
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--data-root", default="data/processed")
    ap.add_argument("--splits", default="splits")
    ap.add_argument("--method", default=None)
    ap.add_argument("--seeds", type=int, nargs="+", default=[0, 1, 2, 3, 4])
    ap.add_argument("--out", default="results/provenance")
    ap.add_argument("--skip-probe", action="store_true")
    args = ap.parse_args()
    cfg = load_config(args.config)
    corpus, method, fpr = cfg["corpus"], args.method or cfg["method"], float(cfg["fpr"])
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    fpr_rows, tpr_rows, cross_rows, consistency_rows = [], [], [], []
    for s in args.seeds:
        cols = load_columns(run_dir(args.runs, corpus, cfg["protocol"], method, s))
        if cols is None or "score" not in cols:
            log.warning("missing detection predictions for seed %d", s)
        else:
            f_tab = per_source_fpr(cols["score"], cols["y_true"], cols["benign_source"], fpr)
            t_tab = per_source_tpr(cols["score"], cols["y_true"], cols["benign_source"], fpr)
            fpr_rows.append(f_tab.assign(seed=s))
            tpr_rows.append(t_tab.assign(seed=s))
            consistency_rows.append(provenance_consistency(f_tab, t_tab, fpr).assign(seed=s))
        cc = load_columns(run_dir(args.runs, corpus, cfg["cross_source"]["protocol"], method, s))
        if cc is None or "score" not in cc:
            log.warning("missing cross-source predictions for seed %d", s)
        else:
            cross_rows.append({"seed": s, **cross_source_metrics(cc["score"], cc["y_true"]),
                               "n_benign_test": int((cc["y_true"] == 0).sum()), "n_malicious_test": int((cc["y_true"] == 1).sum())})
    summary = []
    if consistency_rows:
        cons = pd.concat(consistency_rows, ignore_index=True)
        cons.to_csv(out / "consistency.csv", index=False)
        bad = cons[~cons["consistent"]]
        if not bad.empty:
            log.warning("per-source TPR at %g FPR contradicts the per-source FPR at the global threshold:\n%s",
                        fpr, bad.to_string(index=False))
    for name, frames, keys, value_cols in (("per_source_fpr", fpr_rows, ["source"], ["fpr", "tpr_at_threshold"]),
                                           ("per_source_tpr", tpr_rows, ["source"], [f"tpr@fpr={fpr:g}", "roc_auc"])):
        if frames:
            df = pd.concat(frames, ignore_index=True)
            df.to_csv(out / f"{name}.csv", index=False)
            for key, g in df.groupby(keys):
                for v in value_cols:
                    m, sd = mean_sd(100 * g[v].to_numpy())
                    summary.append({"analysis": name, "source": key[0] if isinstance(key, tuple) else key, "metric": v,
                                    "n_seeds": len(g), "mean": m, "sd": sd})
    if cross_rows:
        df = pd.DataFrame(cross_rows)
        df.to_csv(out / "cross_source.csv", index=False)
        for v in [c for c in df.columns if c.startswith(("roc_auc", "tpr@"))]:
            m, sd = mean_sd(100 * df[v].to_numpy())
            summary.append({"analysis": "cross_source", "source": cfg["cross_source"]["test_source"], "metric": v,
                            "n_seeds": len(df), "mean": m, "sd": sd})
    if not args.skip_probe:
        cd = load_corpus(Path(args.data_root) / corpus)
        split_df, _ = read_split(args.splits, corpus, cfg["protocol"])
        ben = split_df[split_df["label"] == 0]
        rows = ben["row"].to_numpy()
        X = take_rows(cd.static, rows)
        src = cd.meta["benign_source"].to_numpy()[rows]
        pc = cfg["source_probe"]
        probe = source_probe(X, src, int(pc["n_splits"]), int(pc["seed"]), pc.get("lightgbm") or {})
        write_json(out / "source_probe.json", probe)
        summary.append({"analysis": "source_probe", "source": "all", "metric": "macro_ovr_auc", "n_seeds": 1,
                        "mean": 100 * probe["mean_auc"], "sd": 100 * probe["sd_auc"]})
    pd.DataFrame(summary).to_csv(out / "summary.csv", index=False)
    log.info("wrote %s\n%s", out, pd.DataFrame(summary).to_string(index=False))


if __name__ == "__main__":
    main()
