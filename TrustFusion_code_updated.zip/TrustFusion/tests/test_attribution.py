import numpy as np
import torch

from conftest import make_batch
from trustfusion.attribution import VARIANTS, attribution_region_mass, cam_to_byte_scores, compute_cam, gradcampp_weights
from trustfusion.data.byte_image import parse_pe
from trustfusion.data.datasets import synthetic_pe_bytes
from trustfusion.losses import TrustFusionLoss


def _briefly_trained(model, steps: int = 15):
    batch = make_batch(B=16)
    opt = torch.optim.AdamW(model.parameters(), lr=3e-3)
    crit = TrustFusionLoss(np.ones(5), {})
    model.train()
    for _ in range(steps):
        out = model(batch)
        loss, _ = model.compute_loss(batch, out, crit)
        opt.zero_grad()
        loss.backward()
        opt.step()
    return model.eval()


def test_gradcampp_weights_match_reference_loop():
    torch.manual_seed(0)
    A = torch.rand(2, 3, 4, 4)
    G = torch.randn(2, 3, 4, 4)
    w = gradcampp_weights(A, G)
    ref = torch.zeros(2, 3)
    for b in range(2):
        for k in range(3):
            s = A[b, k].sum()
            for i in range(4):
                for j in range(4):
                    g = G[b, k, i, j]
                    den = 2 * g ** 2 + s * g ** 3
                    alpha = g ** 2 / den if den != 0 else 0.0
                    ref[b, k] += alpha * torch.relu(g)
    torch.testing.assert_close(w, ref)


def test_gradcampp_through_fusion_is_nondegenerate_and_differs_from_detached(tiny_model):
    model = _briefly_trained(tiny_model)
    batch = make_batch(B=8)
    target = model.mc_predict(batch, T=1, mc=False)["p_det"].argmax(1)
    maps = {v: compute_cam(model, batch, v, target=target, normalise=False) for v in VARIANTS}
    fusion, detached = maps["gradcampp_fusion"], maps["gradcampp_detached"]
    assert fusion.shape == (8, 4, 4)
    flat = fusion.flatten(1)
    nondegenerate = (flat.max(1).values > 0) & (flat.std(1) > 0)
    assert nondegenerate.float().mean() >= 0.75, "Grad-CAM++ through fusion collapsed to constant maps"
    assert (fusion - detached).abs().max() > 1e-6, "through-fusion and detached-fusion maps must differ"
    assert not torch.allclose(maps["gradcampp_image"], fusion)
    for v in VARIANTS:
        assert torch.isfinite(maps[v]).all() and (maps[v] >= 0).all()


def test_detached_variant_keeps_fused_logit_value(tiny_model):
    model = tiny_model.eval()
    batch = make_batch(B=4)
    with torch.no_grad():
        enc = model.encode(batch)
        fused = model.fuse(enc)
        z = fused["z_f"]
        g = fused["gate"]
        z_det = z.detach() + g.detach() * (enc["z_v"] - enc["z_v"].detach())
    torch.testing.assert_close(model.head(z), model.head(z_det))


def test_projection_to_bytes_and_regions(tiny_model):
    rng = np.random.default_rng(0)
    data = synthetic_pe_bytes(rng, 12_000, 2, 5, overlay=500)
    cam = compute_cam(tiny_model, make_batch(B=1), "gradcampp_fusion")[0]
    scores = cam_to_byte_scores(cam, len(data), 32)
    assert scores.shape == (len(data),) and np.all(scores >= 0)
    mass = attribution_region_mass(cam, len(data), parse_pe(data), 32)
    assert abs(sum(mass.values()) - 1) < 1e-6 or sum(mass.values()) == 0
