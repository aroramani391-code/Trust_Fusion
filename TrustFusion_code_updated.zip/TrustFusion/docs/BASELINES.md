# Baselines

All baselines use the same splits, seeds {0, 1, 2, 3, 4} and tuning budget as TrustFusion.

**Shared protocol.** 20 random-search trials per corpus with seed 0, scored by validation macro-F1 (EMBER2024: models
trained on a stratified 10% subsample of the training split); the best-validation-macro-F1 checkpoint, early stopping
patience 12, at most 80 epochs; no test-time augmentation, no snapshot ensembles and no per-class thresholds.
The configs in `configs/baselines/` contain the selected values below and the search spaces (`search_space`, dotted
keys); `scripts/tune.py` re-runs the search.

| Baseline | config | Selected configuration | Search space | Corpora |
|---|---|---|---|---|
| Byte-image CNN | `byte_cnn.yaml` | ResNet-50 (ImageNet), grey image × 3 channels, 224²; AdamW lr 3e-4, wd 0.05, batch 128, cross-entropy | lr {1e-4, 3e-4, 1e-3}, wd {0.01, 0.05} | BODMAS, MalNet |
| Multi-scale ViT | `msvit.yaml` | ViT-S/16 (ImageNet-21k) at 112 and 224 px + scale attention; AdamW lr 1e-4, wd 0.05, batch 64; consistency 0.1 | lr {5e-5, 1e-4, 3e-4}, consistency {0.05, 0.1, 0.2} | BODMAS, MalNet |
| Gradient-boosted static | `lgbm_static.yaml` | LightGBM, 1,024 leaves, lr 0.05, feature_fraction 0.5, bagging_fraction 0.5 (freq 1), <= 4,000 rounds, early stop 100 on validation loss, balanced class weights for families | leaves {256, 512, 1024, 2048}, lr {0.03, 0.05, 0.1} | all |
| Feature-graph network | `feature_graph.yaml` | 9 nodes (8 groups + global), edges where \|Pearson r\| >= 0.3 on training data, 3-layer GCN width 256, mean–max readout; AdamW lr 1e-3, wd 1e-4, batch 256 | width {128, 256}, lr {3e-4, 1e-3} | all |
| Structural GIN | `gin_callgraph.yaml` | 5 GIN layers width 128, sum readout, local-degree-profile node features; Adam lr 1e-3, batch 64 | width {64, 128}, lr {3e-4, 1e-3} | MalNet |
| Late-fusion ensemble | `late_fusion.yaml` | byte-image CNN + LightGBM (MalNet: + GIN) probabilities, multinomial logistic stacker C = 1 fitted on validation | C {0.1, 1, 10} | BODMAS, MalNet |
| Cross-attention fusion | `cross_attention.yaml` | ConvNeXt-T (ImageNet-1k) + 2×512 MLP, 1 cross-attention layer (image→static), 4 heads, concat head; AdamW lr 1e-4, wd 0.05, batch 64 | lr {5e-5, 1e-4, 3e-4} | BODMAS, MalNet |
| MC-dropout image CNN | `mcdropout_cnn.yaml` | byte-image CNN, dropout 0.3 before the head, T = 12 | dropout {0.1, 0.2, 0.3, 0.5} | BODMAS, MalNet |
| Conformal-gated static | `conformal_lgbm.yaml` | LightGBM as above + split conformal (α = 0.05) on the calibration split; predict on singleton sets | as LightGBM | all |

EMBER2024 has no binaries, so the image-based baselines (byte-image CNN, multi-scale ViT, late fusion, cross-attention,
MC-dropout CNN) are not applicable there; `scripts/train.py` refuses corpora outside a config's `corpora` list.

## Implementation notes (`trustfusion/models/baselines/`)

* **byte_cnn.py** — torchvision ResNet-50 (`IMAGENET1K_V2`), global average pooling, optional dropout before the
  linear head. The MC-dropout CNN is the same class with `head_dropout: 0.3` and `inference.mc: true`; like TrustFusion,
  only the head dropout is stochastic at test time (features computed once, 12 head passes).
* **msvit.py** — `timm` `vit_small_patch16_224.augreg_in21k` with `dynamic_img_size=True` when `timm` is installed;
  otherwise a ViT-S/16 built from torchvision `EncoderBlock`s (depth 12, width 384, 6 heads, MLP ratio 4, bicubically resized position
  embeddings) with random initialisation and a warning. Both scales share weights; the scale-attention weights are
  `softmax_s(v^T tanh(W f_s))`. Loss: cross-entropy on the fused logits + consistency × symmetric KL divergence between
  the two per-scale predictive distributions (same classifier head).
* **gbdt.py** — `lightgbm.train` with the multiclass (`multi_logloss`) or binary (`binary_logloss`) objective,
  `deterministic=True`, seed = model seed, early stopping on the validation split; balanced sample weights
  (`sklearn.utils.class_weight.compute_sample_weight('balanced')`) for family tasks only. Trained on the raw vectors.
* **graph.py** — feature graph: one input projection per field group and one for the global node (full vector);
  node summaries for the correlation graph are the means of each group's preprocessed features (global node: mean of
  all features), computed on the training split; GCN propagation `ReLU(D^-1/2 (A + I) D^-1/2 H W)`; readout
  `[mean_nodes; max_nodes]`. Structural GIN: `h' = MLP((1 + ε) h + Σ_neighbours h)` on the symmetrised call graph
  (MLP = Linear–BatchNorm–ReLU–Linear–ReLU), LDP node features `log1p([deg, min, max, mean, std of neighbour degrees])`,
  sum readout of the last layer. Plain PyTorch (`index_add_`), no torch_geometric.
* **fusion.py** — late fusion: `sklearn.linear_model.LogisticRegression(C, lbfgs)` on the concatenated validation
  probabilities of the base runs of the same seed (base runs must exist; their inference files are checked to be
  aligned). During tuning, the stacker's C is scored by 5-fold stratified cross-validated macro-F1 on the validation
  split, because the stacker itself is fitted on that split. Cross-attention fusion: ConvNeXt-T stage-4 tokens
  projected to 512; the static vector passes a 2-layer 512-wide MLP; the static token queries the image tokens
  (image → static information flow) with residual + LayerNorm; the head sees `[mean image token; attended static
  token]`.

Temperature scaling (Fig. 4, "+ temperature scaling") is fitted on the calibration split of the cross-attention run
(`calibrate.py --temperature --name calibration_ts`, evaluated as method `cross_attention__ts`).
